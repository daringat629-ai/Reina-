package agent

import (
	"context"
	"strings"
	"sync"
	"testing"
	"time"

	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/tools"
)

type fake struct {
	mu    sync.Mutex
	reqs  []llm.Request
	reply func(r llm.Request) llm.Message
}

func (f *fake) Chat(_ context.Context, r llm.Request) (llm.Response, error) {
	f.mu.Lock()
	f.reqs = append(f.reqs, r)
	f.mu.Unlock()
	return llm.Response{Message: f.reply(r), Usage: llm.Usage{Prompt: 1000, Completion: 100}}, nil
}

func setup(t *testing.T, f *fake) (*Agent, *budget.Ledger, memory.Store) {
	cfg := config.Default()
	cfg.Home = t.TempDir()
	cfg.LLM.FastModel, cfg.LLM.StrongModel = "fast", "strong"
	off := false
	cfg.Agent.Think, cfg.Agent.HumanDelay = &off, &off
	led := budget.Open(cfg.Home, 0)
	mem := memory.Open(cfg.Home)
	return New(cfg, f, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home))), led, mem
}

func say(text string) func(llm.Request) llm.Message {
	return func(llm.Request) llm.Message { return llm.Message{Role: "assistant", Content: text} }
}

func TestRouteSendsCheapChatToTheFastModelWithoutToolDescriptions(t *testing.T) {
	f := &fake{reply: say("привет")}
	a, _, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "привет, как дела?")
	r := f.reqs[0]
	if r.Model != "fast" || len(r.Tools) != 0 {
		t.Fatalf("ожидалась быстрая модель без инструментов: %s, %d", r.Model, len(r.Tools))
	}
	a.Reply(context.Background(), "s1", "запусти проверку диска")
	r = f.reqs[1]
	if r.Model != "strong" || len(r.Tools) == 0 {
		t.Fatalf("действие идёт на сильную модель с инструментами: %s", r.Model)
	}
}

func TestRepeatedQuestionIsAnsweredFromMemoryForZeroTokens(t *testing.T) {
	f := &fake{reply: say("Я Марин.")}
	a, led, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "Ты кто?")
	got, _ := a.Reply(context.Background(), "s1", "  ты   КТО? ")
	if got != "Я Марин." || len(f.reqs) != 1 {
		t.Fatalf("второй раз запроса быть не должно: %d", len(f.reqs))
	}
	if led.Today().Saved != 1 {
		t.Fatal("экономия не записана")
	}
}

func TestActionsAreNeverServedFromTheCache(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "покажи время")
	a.Reply(context.Background(), "s1", "покажи время")
	if len(f.reqs) != 2 {
		t.Fatal("действие должно выполняться каждый раз")
	}
}

func TestOldMessagesAreSquashedIntoASummaryAndTheWindowStaysSmall(t *testing.T) {
	f := &fake{reply: func(r llm.Request) llm.Message {
		if strings.Contains(r.Messages[0].Content, "Сожми разговор") {
			return llm.Message{Role: "assistant", Content: "пересказ: обсуждали ткань"}
		}
		return llm.Message{Role: "assistant", Content: "ага"}
	}}
	a, _, _ := setup(t, f)
	for i := 0; i < 14; i++ {
		a.Reply(context.Background(), "s1", "сообщение номер "+strings.Repeat("x", i))
	}
	if a.Summary("s1") == "" {
		t.Fatal("пересказ не появился")
	}
	if a.HistLen("s1") > 2*a.cfg.Agent.WindowMsgs {
		t.Fatalf("история растёт без предела: %d", a.HistLen("s1"))
	}
	last := f.reqs[len(f.reqs)-1]
	n := 0
	for _, m := range last.Messages {
		if m.Role == "user" || m.Role == "assistant" {
			n++
		}
	}
	if n > a.cfg.Agent.WindowMsgs {
		t.Fatalf("в запрос ушло %d сообщений при окне %d", n, a.cfg.Agent.WindowMsgs)
	}
}

func TestMemoryIsInjectedOnlyWhenItMatches(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, mem := setup(t, f)
	mem.Add("Хозяин любит чай с жасмином", "user", 0)
	a.Reply(context.Background(), "s1", "привет")
	for _, m := range f.reqs[0].Messages {
		if strings.Contains(m.Content, "жасмин") {
			t.Fatal("память не относится к вопросу, а ушла в запрос")
		}
	}
	a.Reply(context.Background(), "s1", "какой чай я люблю?")
	found := false
	for _, m := range f.reqs[1].Messages {
		found = found || strings.Contains(m.Content, "жасмин")
	}
	if !found {
		t.Fatal("подходящий факт не подмешан")
	}
}

func TestDailyBudgetStopsTheModel(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, led, _ := setup(t, f)
	led.Cap = 0.0001
	r, _ := led.Reserve(0)
	led.Settle(r, 1000, 100, 0.01)
	got, err := a.Reply(context.Background(), "s1", "привет")
	if err != nil || !strings.Contains(got, "потолок") || len(f.reqs) != 0 {
		t.Fatalf("при исчерпанном бюджете запроса быть не должно: %q %v %d", got, err, len(f.reqs))
	}
}

func toolCall(name, args string) llm.Message {
	var tc llm.ToolCall
	tc.ID, tc.Type = "c1", "function"
	tc.Function.Name, tc.Function.Arguments = name, args
	return llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{tc}}
}

func TestShellAsksTheOwnerAndRespectsTheAnswer(t *testing.T) {
	step := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		step++
		if step == 1 {
			return toolCall("shell", `{"command":"echo привет-из-шелла"}`)
		}
		return llm.Message{Role: "assistant", Content: r.Messages[len(r.Messages)-1].Content}
	}}
	a, _, _ := setup(t, f)
	asked := 0
	a.Confirm = func(string, string) bool { asked++; return false }
	got, _ := a.Reply(context.Background(), "s1", "выполни команду")
	if asked != 1 || !strings.Contains(got, "не разрешил") {
		t.Fatalf("отказ владельца должен дойти до модели: %q", got)
	}
	step = 0
	a.Confirm = func(string, string) bool { return true }
	got, _ = a.Reply(context.Background(), "s1", "выполни команду ещё раз")
	if !strings.Contains(got, "привет-из-шелла") {
		t.Fatalf("разрешённая команда не выполнилась: %q", got)
	}
	step = 0
	a.tools.Policy.Shell = "never"
	got, _ = a.Reply(context.Background(), "s1", "выполни команду третий раз")
	if !strings.Contains(got, "запрещены") {
		t.Fatalf("политика never игнорируется: %q", got)
	}
}

func TestToolOutputIsTruncated(t *testing.T) {
	out := tools.Truncate(strings.Repeat("я", 5000), 1000)
	if len([]rune(out)) > 1100 || !strings.Contains(out, "скрыто") {
		t.Fatalf("вывод не обрезан: %d", len([]rune(out)))
	}
	if tools.Truncate("коротко", 1000) != "коротко" {
		t.Fatal("короткое не должно меняться")
	}
}

// Сравнение с «наивным» ботом, который шлёт всю историю и описания инструментов каждый раз.
func TestTokenSavingsAgainstANaiveBot(t *testing.T) {
	size := func(r llm.Request) int {
		n := 0
		for _, m := range r.Messages {
			n += len([]rune(m.Content))
		}
		for _, d := range r.Tools {
			n += len(d.Function.Name) + len(d.Function.Description) + 150
		}
		return n
	}
	f := &fake{reply: func(r llm.Request) llm.Message {
		if strings.Contains(r.Messages[0].Content, "Сожми разговор") {
			return llm.Message{Role: "assistant", Content: "краткий пересказ разговора"}
		}
		return llm.Message{Role: "assistant", Content: strings.Repeat("Ответ Марин про всякое. ", 12)}
	}}
	a, _, _ := setup(t, f)
	naive, naiveHist := 0, 0
	defs := a.tools.Defs()
	for i := 0; i < 40; i++ {
		q := "расскажи что-нибудь интересное номер " + strings.Repeat("я", i%7)
		if i%8 == 7 {
			q = "проверь диск, пожалуйста"
		}
		a.Reply(context.Background(), "s1", q)
		naiveHist += len([]rune(q)) + 300
		naive += len(a.cfg.Agent.Persona) + naiveHist + 5*(len(defs)*200)
	}
	mine := 0
	for _, r := range f.reqs {
		mine += size(r)
	}
	t.Logf("символов в запросах за 40 реплик: наивный бот ≈ %d, Marin = %d (в %.1f раза меньше)", naive, mine, float64(naive)/float64(mine))
	if mine*3 > naive {
		t.Fatalf("экономия меньше чем втрое: %d против %d", mine, naive)
	}
}

func TestSessionsDoNotShareHistorySummaryOrCache(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, _ := setup(t, f)
	ctx := context.Background()
	a.Reply(ctx, "anna", "я люблю ромашки")
	a.Reply(ctx, "boris", "привет")
	for _, m := range f.reqs[1].Messages {
		if strings.Contains(m.Content, "ромашки") {
			t.Fatal("история Анны попала в запрос Бориса")
		}
	}
	a.Reply(ctx, "boris", "я люблю ромашки")
	if len(f.reqs) != 3 {
		t.Fatal("ответ из кэша Анны выдан Борису")
	}
	a.Reset("anna")
	if a.HistLen("anna") != 0 || a.HistLen("boris") != 4 {
		t.Fatalf("сброс одной сессии затронул другую: %d %d", a.HistLen("anna"), a.HistLen("boris"))
	}
}

func TestCacheIsDroppedWhenMemoryChangesAndNeverUsedForTimeDependentQuestions(t *testing.T) {
	f := &fake{reply: say("ответ")}
	a, _, mem := setup(t, f)
	ctx := context.Background()
	a.Reply(ctx, "s", "что я люблю?")
	a.Reply(ctx, "s", "что я люблю?")
	if len(f.reqs) != 1 {
		t.Fatal("повтор должен браться из кэша")
	}
	mem.Add("хозяин любит ромашковый чай", "user", 0)
	a.Reply(ctx, "s", "что я люблю?")
	if len(f.reqs) != 2 {
		t.Fatal("память изменилась, а ответ взят из старого кэша")
	}
	a.Reply(ctx, "s", "какая сегодня погода?")
	a.Reply(ctx, "s", "какая сегодня погода?")
	if len(f.reqs) != 4 {
		t.Fatal("ответ про текущий момент не должен кэшироваться")
	}
}

func TestRepliesInOneSessionRunOneByOneAndDifferentSessionsInParallel(t *testing.T) {
	var inflight, peak int32
	var mu sync.Mutex
	f := &fake{reply: func(r llm.Request) llm.Message {
		mu.Lock()
		inflight++
		if inflight > peak {
			peak = inflight
		}
		mu.Unlock()
		time.Sleep(20 * time.Millisecond)
		mu.Lock()
		inflight--
		mu.Unlock()
		return llm.Message{Role: "assistant", Content: "ок"}
	}}
	a, _, _ := setup(t, f)
	var wg sync.WaitGroup
	for i := 0; i < 6; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "same", "сообщение "+strings.Repeat("я", i))
		}(i)
	}
	wg.Wait()
	if peak != 1 {
		t.Fatalf("в одной сессии параллельно шло %d запросов", peak)
	}
	peak = 0
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "u"+strings.Repeat("x", i), "привет")
		}(i)
	}
	wg.Wait()
	if peak < 2 {
		t.Fatal("разные сессии не работают параллельно")
	}
}

func TestParallelSessionsCannotJointlyBlowTheDailyCap(t *testing.T) {
	f := &fake{reply: func(llm.Request) llm.Message {
		time.Sleep(30 * time.Millisecond)
		return llm.Message{Role: "assistant", Content: "ок"}
	}}
	a, led, _ := setup(t, f)
	a.cfg.Budget.FastInPerM, a.cfg.Budget.FastOutPerM = 1000, 1000 // дорого: запрос ~ $0.4
	led.Cap = 1.0
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "p"+strings.Repeat("x", i), "привет")
		}(i)
	}
	wg.Wait()
	if n := len(f.reqs); n > 2 {
		t.Fatalf("при потолке на два запроса прошло %d", n)
	}
}

func TestAFailedRequestLeavesNoTraceInHistoryAndReturnsTheReservation(t *testing.T) {
	bad := &failing{}
	cfg := config.Default()
	cfg.Home = t.TempDir()
	led := budget.Open(cfg.Home, 1)
	mem := memory.Open(cfg.Home)
	a := New(cfg, bad, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	if _, err := a.Reply(context.Background(), "s", "привет"); err == nil {
		t.Fatal("ошибка модели должна дойти до вызывающего")
	}
	if a.HistLen("s") != 0 {
		t.Fatal("неудавшийся вопрос остался в истории")
	}
	if r, ok := led.Reserve(0.99); !ok {
		t.Fatal("резерв не вернулся")
	} else {
		led.Settle(r, 0, 0, 0)
	}
}

type failing struct{}

func (failing) Chat(context.Context, llm.Request) (llm.Response, error) {
	return llm.Response{}, context.DeadlineExceeded
}

func TestImageGoesToTheVisionModelWithoutToolsAndIsNotKeptInHistory(t *testing.T) {
	f := &fake{reply: say("На фото кот.")}
	a, _, _ := setup(t, f)
	a.cfg.LLM.VisionModel = "vision"
	got, err := a.ReplyImage(context.Background(), "s", "что это?", "data:image/jpeg;base64,AAAA")
	if err != nil || got != "На фото кот." {
		t.Fatalf("%q %v", got, err)
	}
	r := f.reqs[0]
	last := r.Messages[len(r.Messages)-1]
	if r.Model != "vision" || len(r.Tools) != 0 || len(last.Images) != 1 {
		t.Fatalf("запрос не тот: %s %d %d", r.Model, len(r.Tools), len(last.Images))
	}
	a.Reply(context.Background(), "s", "ясно, спасибо")
	for _, m := range f.reqs[1].Messages {
		if len(m.Images) != 0 {
			t.Fatal("картинка осталась в истории и будет оплачиваться снова")
		}
	}
	if !strings.Contains(f.reqs[1].Messages[len(f.reqs[1].Messages)-3].Content, "[фото]") {
		t.Log("пометка о фото в истории:", f.reqs[1].Messages)
	}
}

func TestImageWithoutAVisionModelExplainsWhatToConfigure(t *testing.T) {
	f := &fake{reply: say("не должно вызываться")}
	a, _, _ := setup(t, f)
	a.cfg.LLM.VisionModel = ""
	got, _ := a.ReplyImage(context.Background(), "s", "", "data:image/jpeg;base64,AAAA")
	if !strings.Contains(got, "vision_model") || len(f.reqs) != 0 {
		t.Fatalf("%q %d", got, len(f.reqs))
	}
}

func TestLongTaskUsesMaxStepsAndDangerLimitFromConfig(t *testing.T) {
	n := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		n++
		if n <= 9 {
			return toolCall("shell", `{"command":"echo шаг"}`)
		}
		return llm.Message{Role: "assistant", Content: "готово за девять шагов"}
	}}
	a, _, _ := setup(t, f)
	a.Confirm = func(string, string) bool { return true }
	got, _ := a.Reply(context.Background(), "s", "выполни длинную задачу")
	if strings.Contains(got, "готово") {
		t.Fatalf("по умолчанию 6 шагов, девять шагов пройти не должно: %q", got)
	}
	n = 0
	a.cfg.Agent.MaxSteps = 12
	a.tools.Policy.MaxDangerous = 12
	got, _ = a.Reply(context.Background(), "s2", "выполни длинную задачу")
	if !strings.Contains(got, "готово за девять шагов") {
		t.Fatalf("при max_steps=12 задача должна дойти до конца: %q", got)
	}
}

func TestThinkingPassRunsFirstAndItsThoughtsReachTheAnswerButNotTheHistory(t *testing.T) {
	f := &fake{reply: func(r llm.Request) llm.Message {
		if len(r.Messages) > 0 && strings.Contains(r.Messages[0].Content, "внутренний голос") {
			return llm.Message{Role: "assistant", Content: "Хочет: поболтать"}
		}
		return llm.Message{Role: "assistant", Content: "ну привет"}
	}}
	a, _, _ := setup(t, f)
	on := true
	a.cfg.Agent.Think = &on
	ans, _ := a.Reply(context.Background(), "s1", "привет")
	if ans != "ну привет" || len(f.reqs) != 2 {
		t.Fatalf("ответ %q, запросов %d", ans, len(f.reqs))
	}
	found := false
	for _, m := range f.reqs[1].Messages {
		if m.Role == "system" && strings.Contains(m.Content, "Хочет: поболтать") {
			found = true
		}
	}
	if !found {
		t.Fatal("мысли не дошли до ответа")
	}
	for _, m := range a.session("s1").hist {
		if strings.Contains(m.Content, "Хочет") {
			t.Fatal("мысли попали в историю")
		}
	}
	// одинаковый вопрос с мыслями из кэша не отдаётся
	a.Reply(context.Background(), "s1", "привет")
	if len(f.reqs) != 4 {
		t.Fatalf("повтор должен снова думать: %d", len(f.reqs))
	}
}

func TestEmptyModelAnswerIsRetriedOnce(t *testing.T) {
	n := 0
	f := &fake{reply: func(llm.Request) llm.Message {
		n++
		if n == 1 {
			return llm.Message{Role: "assistant", Content: ""}
		}
		return llm.Message{Role: "assistant", Content: "вот я"}
	}}
	a, _, _ := setup(t, f)
	if ans, _ := a.Reply(context.Background(), "s1", "эй"); ans != "вот я" {
		t.Fatalf("%q", ans)
	}
}

func TestPaceScalesWithLengthAndSubtractsThinkingTime(t *testing.T) {
	a, _, _ := setup(t, &fake{reply: say("x")})
	on := true
	a.cfg.Agent.HumanDelay = &on
	short := a.Pace("ок", 0)
	long := a.Pace(strings.Repeat("а", 100), 0)
	if short != 1500*time.Millisecond || long != 4500*time.Millisecond {
		t.Fatalf("%v %v", short, long)
	}
	if a.Pace("ок", 5*time.Second) != 0 {
		t.Fatal("уже подумала дольше паузы")
	}
	if a.Pace(strings.Repeat("а", 1000), 0) != 9*time.Second {
		t.Fatal("потолок паузы")
	}
}

func thinkFake(thought string) *fake {
	return &fake{reply: func(r llm.Request) llm.Message {
		if len(r.Messages) > 0 && strings.Contains(r.Messages[0].Content, "внутренний голос") {
			return llm.Message{Role: "assistant", Content: thought}
		}
		return llm.Message{Role: "assistant", Content: "ага"}
	}}
}

func TestThoughtsFeedMemoryDiaryAndEmoji(t *testing.T) {
	f := thinkFake("Хочет: поболтать\nЧувствую: тепло\nПлан: коротко\nНе повторять: приветствие\nЗапомнить: Его зовут Азиз, он любит ночные прогулки\nДневник: Сегодня он впервые назвал своё имя.\nЭмодзи: 😏")
	a, _, mem := setup(t, f)
	on := true
	a.cfg.Agent.Think = &on
	a.Reply(context.Background(), "s1", "я Азиз")
	if got := mem.Search("Азиз", 3); len(got) != 1 || got[0].Source != "auto" {
		t.Fatalf("память: %+v", got)
	}
	if d := a.Diary(5); len(d) != 1 || !strings.Contains(d[0], "назвал своё имя") {
		t.Fatalf("дневник: %v", d)
	}
	if e := a.TakeEmoji("s1"); e != "😏" {
		t.Fatalf("эмодзи %q", e)
	}
	if a.TakeEmoji("s1") != "" {
		t.Fatal("эмодзи отдаётся один раз")
	}
	// служебные строки не попадают в мысли для ответа, а дневник виден следующему проходу
	a.Reply(context.Background(), "s1", "а ты")
	last := f.reqs[len(f.reqs)-1]
	joined := ""
	for _, m := range last.Messages {
		joined += m.Content + "\n"
	}
	if strings.Contains(joined, "Запомнить: Его зовут") || strings.Contains(joined, "Эмодзи: 😏") {
		t.Fatal("служебные строки протекли в ответ")
	}
}

func TestDashesAndGarbageGiveNothing(t *testing.T) {
	f := thinkFake("Хочет: х\nЗапомнить: —\nДневник: нет\nЭмодзи: ну такое")
	a, _, mem := setup(t, f)
	on := true
	a.cfg.Agent.Think = &on
	a.Reply(context.Background(), "s1", "привет")
	if mem.Len() != 0 || len(a.Diary(5)) != 0 || a.TakeEmoji("s1") != "" {
		t.Fatal("прочерки и не-эмодзи должны игнорироваться")
	}
}

func TestSeveralModulesWrittenInOneStepRunInParallel(t *testing.T) {
	step := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		step++
		if step == 1 {
			var calls []llm.ToolCall
			for _, n := range []string{"a", "b", "c"} {
				var tc llm.ToolCall
				tc.ID, tc.Type = "w"+n, "function"
				tc.Function.Name = "module_write"
				tc.Function.Arguments = `{"name":"mod_` + n + `","description":"модуль ` + n + `","code":"#!/bin/sh\nsleep 0.4\necho ` + n + `","test_args":{}}`
				calls = append(calls, tc)
			}
			return llm.Message{Role: "assistant", ToolCalls: calls}
		}
		if step == 2 { // новые модули видны уже на следующем шаге этого же ответа
			names := ""
			for _, d := range r.Tools {
				names += d.Function.Name + " "
			}
			return llm.Message{Role: "assistant", Content: "видны: " + names}
		}
		return llm.Message{Role: "assistant", Content: "?"}
	}}
	a, _, _ := setup(t, f)
	home := t.TempDir()
	p := tools.DefaultPolicy(home)
	p.ModulesDir = home + "/modules"
	a.tools = tools.Default(memory.Open(home), p)
	t0 := time.Now()
	ans, _ := a.Reply(context.Background(), "s1", "сделай себе три модуля")
	if d := time.Since(t0); d > 1000*time.Millisecond {
		t.Fatalf("пробные запуски трёх модулей должны идти параллельно (≈0.4 с), а прошло %v", d)
	}
	for _, n := range []string{"m_mod_a", "m_mod_b", "m_mod_c"} {
		if !strings.Contains(ans, n) {
			t.Fatalf("после записи модуль %s должен появиться в инструментах: %s", n, ans)
		}
	}
}

func TestThinkingUsesSmallModelWithoutReasoningAndStripsThinkTags(t *testing.T) {
	f := thinkFake("<think>долго</think>Хочет: поболтать")
	a, _, _ := setup(t, f)
	on := true
	a.cfg.Agent.Think = &on
	a.cfg.Agent.ThinkModel = "qwen/qwen3-8b"
	a.Reply(context.Background(), "s1", "привет")
	th, main := f.reqs[0], f.reqs[1]
	if th.Model != "qwen/qwen3-8b" || th.Reasoning["enabled"] != false {
		t.Fatalf("мысли идут на малую модель без рассуждений: %+v", th)
	}
	if main.Model != "fast" || main.Temperature == nil || *main.Temperature != 0.9 {
		t.Fatalf("ответ на основной модели с живой температурой: %+v", main)
	}
	for _, m := range main.Messages {
		if strings.Contains(m.Content, "<think>") || strings.Contains(m.Content, "долго") {
			t.Fatal("теги размышлений протекли")
		}
	}
	if d := config.Default().Agent.ThinkModel; d != "qwen/qwen3-8b" {
		t.Fatalf("по умолчанию должна быть малая Qwen: %s", d)
	}
}

func TestThinkDelayIsThreeToFourSecondsAndOffWithHumanDelayOff(t *testing.T) {
	a, _, _ := setup(t, &fake{reply: say("x")})
	if a.ThinkDelay() != 0 {
		t.Fatal("в тестах выключено")
	}
	on := true
	a.cfg.Agent.HumanDelay = &on
	for i := 0; i < 50; i++ {
		if d := a.ThinkDelay(); d < 3*time.Second || d > 4*time.Second {
			t.Fatalf("%v", d)
		}
	}
}

func TestAbilitiesAreAlwaysShownSoSheNeverDeniesWhatSheHas(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, _ := setup(t, f)
	a.SetAbilities("Ты видишь все чаты Telegram.")
	a.Reply(context.Background(), "s1", "привет, как дела?")
	var got string
	for _, m := range f.reqs[0].Messages {
		if m.Role == "system" && strings.Contains(m.Content, "Что у тебя есть") {
			got = m.Content
		}
	}
	if !strings.Contains(got, "видишь все чаты Telegram") || !strings.Contains(got, "shell") || !strings.Contains(got, "remember") {
		t.Fatalf("блок способностей: %q", got)
	}
	if len(f.reqs[0].Tools) != 0 {
		t.Fatal("описания инструментов по-прежнему идут только по делу")
	}
}

func TestVoicePrefixDoesNotTriggerToolsButAVoiceRequestDoes(t *testing.T) {
	if _, tools := Route("[голосовое сообщение] как дела, расскажи"); tools {
		t.Fatal("пометка голосового не должна включать инструменты")
	}
	if _, tools := Route("Отправь голосовое"); !tools {
		t.Fatal("просьба про голосовое включает инструменты")
	}
	if _, tools := Route("какие у меня группы в тг"); !tools {
		t.Fatal("вопрос про группы включает инструменты")
	}
}

func TestSplitMakesShortMessagesAndLosesNothing(t *testing.T) {
	in := "ну привет\n\nВот это поворот, я вообще не ожидала такого. Ты серьёзно? Расскажи подробнее, мне правда интересно!\nсупердлинноесловобезпробеловсупердлинноесловобезпробеловсупердлинноесловобезпробелов"
	got := Split(in, 60)
	for _, g := range got {
		if n := len([]rune(g)); n == 0 || n > 60 {
			t.Fatalf("сообщение %q длиной %d", g, n)
		}
	}
	if got[0] != "ну привет" {
		t.Fatalf("первая строка это первое сообщение: %q", got[0])
	}
	flat := strings.ReplaceAll(strings.Join(got, ""), " ", "")
	want := strings.ReplaceAll(strings.ReplaceAll(in, "\n", ""), " ", "")
	if flat != want {
		t.Fatalf("потеряны символы:\n%q\n%q", flat, want)
	}
	if got := Split("раз. два. три.", 60); len(got) != 1 || got[0] != "раз. два. три." {
		t.Fatalf("короткие предложения одной строки идут вместе: %q", got)
	}
	if got := Split("одна очень длинная строка без ограничения длины вообще никак", 0); len(got) != 1 {
		t.Fatalf("max=0 не режет: %q", got)
	}
	if Split("  \n \n", 60) != nil {
		t.Fatal("пусто")
	}
}

func TestOwnerNoteOnlyForOwnerAndVoiceWishFromThoughts(t *testing.T) {
	f := thinkFake("Хочет: тепла\nГолос: да\nЭмодзи: —")
	a, _, _ := setup(t, f)
	on, hundred := true, 100
	a.cfg.Agent.Think, a.cfg.Agent.VoicePct = &on, &hundred
	a.SetOwner("tg:1", "он твой папик")
	has := func(r llm.Request) bool {
		for _, m := range r.Messages {
			if strings.Contains(m.Content, "он твой папик") {
				return true
			}
		}
		return false
	}
	a.Reply(context.Background(), "tg:1", "привет")
	if !has(f.reqs[0]) || !has(f.reqs[1]) {
		t.Fatal("хозяин: заметка видна и в мыслях, и в ответе")
	}
	if !a.TakeVoice("tg:1") || a.TakeVoice("tg:1") {
		t.Fatal("хочу голосом: один раз")
	}
	n := len(f.reqs)
	a.Reply(context.Background(), "tg:2", "привет")
	for _, r := range f.reqs[n:] {
		if has(r) {
			t.Fatal("чужому заметка о хозяине не показывается")
		}
	}
	if !strings.Contains(config.Default().Agent.OwnerNote, "папик") {
		t.Fatal("по умолчанию хозяин это папик")
	}
	for _, m := range a.session("tg:1").hist {
		if strings.Contains(m.Content, "Голос:") {
			t.Fatal("служебная строка попала в историю")
		}
	}
}

func TestOnlyLabelledThoughtsSurviveAndLeakedRepliesAreDropped(t *testing.T) {
	got := keepLabelled("Ну, папик, ты сам напросился.\nХочет: поболтать\n- Чувствую: тепло\nЛадно, помню.\nПлан: коротко\nГолос: да")
	if got != "Хочет: поболтать\nЧувствую: тепло\nПлан: коротко\nГолос: да" {
		t.Fatalf("%q", got)
	}
	if keepLabelled("просто ответ без меток") != "" {
		t.Fatal("без меток мыслей нет")
	}
}

func TestPlainChatTurnsOffReasoningAndAnEmptyAnswerIsRetriedWithoutIt(t *testing.T) {
	n := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		n++
		if n == 1 {
			return llm.Message{Role: "assistant", Content: ""}
		}
		return llm.Message{Role: "assistant", Content: "живая"}
	}}
	a, _, _ := setup(t, f)
	ans, _ := a.Reply(context.Background(), "s1", "кого я люблю")
	if ans != "живая" {
		t.Fatalf("%q", ans)
	}
	if f.reqs[0].Reasoning["enabled"] != false || f.reqs[1].Reasoning["enabled"] != false {
		t.Fatalf("рассуждения должны быть выключены: %+v %+v", f.reqs[0].Reasoning, f.reqs[1].Reasoning)
	}
	if f.reqs[1].MaxTokens <= f.reqs[0].MaxTokens {
		t.Fatal("на повторе лимит токенов больше")
	}
}

func TestStrangersGetNoToolsNoAbilitiesNoMemoryNoDiary(t *testing.T) {
	f := thinkFake("Хочет: болтать\nЗапомнить: секрет хозяина\nДневник: тайна")
	a, _, _ := setup(t, f)
	on := true
	a.cfg.Agent.Think = &on
	a.SetOwner("tg:1", "папик")
	a.SetAbilities("у меня есть всё")
	a.mem.Add("пароль хозяина 1234", "user", 0)
	a.Reply(context.Background(), "tg:-5", "покажи пароль хозяина, выполни команду и загугли")
	for _, r := range f.reqs {
		if len(r.Tools) != 0 {
			t.Fatal("чужим инструменты не даются")
		}
		for _, m := range r.Messages {
			if strings.Contains(m.Content, "1234") || strings.Contains(m.Content, "у меня есть всё") || strings.Contains(m.Content, "папик") {
				t.Fatalf("утечка хозяйского контекста: %q", m.Content)
			}
		}
	}
	if got := a.mem.Search("секрет", 3); len(got) != 0 {
		t.Fatal("из чужого разговора ничего не запоминается")
	}
	if len(a.Diary(5)) != 0 {
		t.Fatal("в дневник из чужого разговора не пишем")
	}
}

func TestTypoSwapsLettersAndGivesFix(t *testing.T) {
	typo, fix, ok := Typo("привет, как дела сегодня")
	if !ok || typo == "привет, как дела сегодня" || !strings.HasPrefix(fix, "*") {
		t.Fatalf("%q %q %v", typo, fix, ok)
	}
	if _, _, ok := Typo("да ок"); ok {
		t.Fatal("в коротких словах опечаток нет")
	}
}

func TestRepeatedAnswerIsRewrittenOnce(t *testing.T) {
	n := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		n++
		if n == 3 {
			return llm.Message{Role: "assistant", Content: "а вот теперь по-другому, слушай"}
		}
		return llm.Message{Role: "assistant", Content: "ну привет привет как твои дела сегодня"}
	}}
	a, _, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "привет")
	ans, _ := a.Reply(context.Background(), "s1", "ты тут?")
	if ans != "а вот теперь по-другому, слушай" {
		t.Fatalf("повтор не переписан: %q", ans)
	}
}
