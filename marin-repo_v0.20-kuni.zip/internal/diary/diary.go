// Package diary: дневник в формате Куни. Одна страница это один markdown-файл <unix>.md с блоком метаданных
// (JSON между строками ---) и телом: время, источник, итоги, участники, ключевые реплики, теги, важность, эмоции, связи,
// поисковые подсказки, сходства, противоречия. Поиск по подсказкам, тегам и тексту; чаще используемые и важные страницы выше.
package diary

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Meta struct {
	Score      float64 `json:"score"`      // важность 0..1
	Confidence float64 `json:"confidence"` // -1 ложь, 0 версия, 1 твёрдый факт
	LastUsed   string  `json:"lastUsed"`
	UsageCount int     `json:"usageCount"`
}

type Page struct {
	ID   string
	Meta Meta
	Body string
}

type Store struct {
	Dir string
	Now func() time.Time
	mu  sync.Mutex
}

func Open(dir string) *Store { return &Store{Dir: dir, Now: time.Now} }

var impRe = regexp.MustCompile(`(?i)(?:importance score|важность)[^0-9]{0,12}([01](?:[.,]\d+)?)`)

// Importance достаёт оценку важности из тела страницы (0.5, если не найдена).
func Importance(body string) float64 {
	if m := impRe.FindStringSubmatch(body); m != nil {
		if v, err := strconv.ParseFloat(strings.Replace(m[1], ",", ".", 1), 64); err == nil && v >= 0 && v <= 1 {
			return v
		}
	}
	return 0.5
}

var wordRe = regexp.MustCompile(`[\p{L}\p{N}]{3,}`)

func words(s string) map[string]bool {
	m := map[string]bool{}
	for _, w := range wordRe.FindAllString(strings.ToLower(s), -1) {
		m[stem(w)] = true
	}
	return m
}

// stem: грубая обрезка окончаний, чтобы «собака» и «собаки» совпадали.
func stem(w string) string {
	r := []rune(w)
	if len(r) > 6 {
		return string(r[:len(r)-2])
	}
	if len(r) > 4 {
		return string(r[:len(r)-1])
	}
	return w
}

func jaccard(a, b map[string]bool) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	n := 0
	for w := range a {
		if b[w] {
			n++
		}
	}
	return float64(n) / float64(len(a)+len(b)-n)
}

// Add сохраняет страницу. Слишком похожую на недавние (плагиат, порог 0.8) не пишет: возвращает false.
func (s *Store) Add(body string) (bool, error) {
	body = strings.TrimSpace(body)
	if len([]rune(body)) < 20 {
		return false, nil
	}
	nb := words(body)
	for _, p := range s.Recent(6) {
		if jaccard(nb, words(p.Body)) >= 0.8 {
			return false, nil
		}
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := os.MkdirAll(s.Dir, 0o700); err != nil {
		return false, err
	}
	id := s.Now().Unix()
	var path string
	for { // два страницы за одну секунду не затирают друг друга
		path = filepath.Join(s.Dir, fmt.Sprintf("%d.md", id))
		if _, err := os.Stat(path); err != nil {
			break
		}
		id++
	}
	meta, _ := json.Marshal(Meta{Score: Importance(body), LastUsed: "never"})
	return true, os.WriteFile(path, []byte("---\n"+string(meta)+"\n---\n\n"+body+"\n"), 0o600)
}

func parse(id, raw string) Page {
	p := Page{ID: id, Body: strings.TrimSpace(raw)}
	if strings.HasPrefix(raw, "---\n") {
		if i := strings.Index(raw[4:], "\n---"); i >= 0 {
			_ = json.Unmarshal([]byte(raw[4:4+i]), &p.Meta)
			p.Body = strings.TrimSpace(raw[4+i+4:])
		}
	}
	return p
}

func (s *Store) all() []Page {
	s.mu.Lock()
	defer s.mu.Unlock()
	fs, _ := filepath.Glob(filepath.Join(s.Dir, "*.md"))
	sort.Strings(fs)
	var out []Page
	for _, f := range fs {
		if b, err := os.ReadFile(f); err == nil {
			out = append(out, parse(strings.TrimSuffix(filepath.Base(f), ".md"), string(b)))
		}
	}
	return out
}

// Recent: последние n страниц, старые сверху.
func (s *Store) Recent(n int) []Page {
	a := s.all()
	if len(a) > n {
		a = a[len(a)-n:]
	}
	return a
}

func (s *Store) Count() int { return len(s.all()) }

// Search: k самых подходящих страниц под запрос; учитывает совпадение слов, важность и частоту использования.
// У найденных растёт usageCount и обновляется lastUsed.
func (s *Store) Search(q string, k int) []Page {
	qw := words(q)
	if len(qw) == 0 {
		return nil
	}
	type sc struct {
		p Page
		s float64
	}
	var all []sc
	for _, p := range s.all() {
		pw := words(p.Body)
		n := 0
		for w := range qw {
			if pw[w] {
				n++
			}
		}
		if n == 0 {
			continue
		}
		rel := float64(n) / float64(len(qw))
		all = append(all, sc{p, rel*2 + p.Meta.Score + p.Meta.Confidence*0.3 + float64(min(p.Meta.UsageCount, 10))*0.03})
	}
	sort.Slice(all, func(i, j int) bool { return all[i].s > all[j].s })
	var out []Page
	for i := 0; i < len(all) && i < k; i++ {
		out = append(out, all[i].p)
		s.touch(all[i].p)
	}
	return out
}

func (s *Store) touch(p Page) {
	s.mu.Lock()
	defer s.mu.Unlock()
	p.Meta.UsageCount++
	p.Meta.LastUsed = s.Now().Format("2006-01-02 15:04:05")
	m, _ := json.Marshal(p.Meta)
	_ = os.WriteFile(filepath.Join(s.Dir, p.ID+".md"), []byte("---\n"+string(m)+"\n---\n\n"+p.Body+"\n"), 0o600)
}

// Split разбивает ответ модели на страницы по строкам ---.
func Split(t string) []string {
	var out []string
	for _, part := range regexp.MustCompile(`(?m)^\s*---+\s*$`).Split(t, -1) {
		if p := strings.TrimSpace(part); len([]rune(p)) >= 20 {
			out = append(out, p)
		}
	}
	return out
}
