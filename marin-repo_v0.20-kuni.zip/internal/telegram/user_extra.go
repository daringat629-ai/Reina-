//go:build tguser

package telegram

import (
	"context"
	"fmt"
	mrand "math/rand"
	mime "mime"
	"path/filepath"
	"strings"
	"time"

	"github.com/gotd/td/telegram/uploader"
	"github.com/gotd/td/tg"
)

// Идентификаторы как в Bot API: человек это его id, обычная группа -id, супергруппа и канал -1000000000000-id.
const channelBase = -1000000000000

type chatRow struct {
	ID       int64
	Kind     string // лс, группа, супергруппа, канал
	Name     string
	Username string
	Members  int
	Unread   int
}

// absorb разбирает ответ со списком диалогов: запоминает адреса (людей, групп, каналов) и собирает строки для tg_chats.
func (u *User) absorb(res tg.MessagesDialogsClass) ([]*tg.User, []chatRow) {
	var dialogs []tg.DialogClass
	var chats []tg.ChatClass
	var users []tg.UserClass
	switch d := res.(type) {
	case *tg.MessagesDialogs:
		dialogs, chats, users = d.Dialogs, d.Chats, d.Users
	case *tg.MessagesDialogsSlice:
		dialogs, chats, users = d.Dialogs, d.Chats, d.Users
	}
	byUser := map[int64]*tg.User{}
	var out []*tg.User
	u.mu.Lock()
	for _, c := range users {
		if x, ok := c.(*tg.User); ok {
			u.peers[x.ID] = x.AsInputPeer()
			byUser[x.ID] = x
			out = append(out, x)
		}
	}
	basic := map[int64]*tg.Chat{}
	chans := map[int64]*tg.Channel{}
	for _, c := range chats {
		switch x := c.(type) {
		case *tg.Chat:
			basic[x.ID] = x
			u.peers[-x.ID] = &tg.InputPeerChat{ChatID: x.ID}
		case *tg.Channel:
			chans[x.ID] = x
			u.peers[channelBase-x.ID] = &tg.InputPeerChannel{ChannelID: x.ID, AccessHash: x.AccessHash}
		}
	}
	u.mu.Unlock()
	var rows []chatRow
	for _, dc := range dialogs {
		d, ok := dc.(*tg.Dialog)
		if !ok {
			continue
		}
		switch p := d.Peer.(type) {
		case *tg.PeerUser:
			if x := byUser[p.UserID]; x != nil && !x.Self && !x.Bot {
				rows = append(rows, chatRow{ID: x.ID, Kind: "лс", Name: userName(x), Username: x.Username, Unread: d.UnreadCount})
			}
		case *tg.PeerChat:
			if x := basic[p.ChatID]; x != nil {
				rows = append(rows, chatRow{ID: -x.ID, Kind: "группа", Name: x.Title, Members: x.ParticipantsCount, Unread: d.UnreadCount})
			}
		case *tg.PeerChannel:
			if x := chans[p.ChannelID]; x != nil {
				k := "канал"
				if x.Megagroup {
					k = "супергруппа"
				}
				rows = append(rows, chatRow{ID: channelBase - x.ID, Kind: k, Name: x.Title, Username: x.Username, Members: x.ParticipantsCount, Unread: d.UnreadCount})
			}
		}
	}
	return out, rows
}

// Chats: «id | тип | название | @username | участников | непрочитано» по подстроке (без query: последние).
func (u *User) Chats(ctx context.Context, query string, limit int) (string, error) {
	if _, err := u.dialogUsers(ctx); err != nil {
		return "", err
	}
	u.mu.Lock()
	rows := append([]chatRow(nil), u.rows...)
	u.mu.Unlock()
	q := strings.ToLower(strings.TrimPrefix(strings.TrimSpace(query), "@"))
	var sb strings.Builder
	n := 0
	for _, r := range rows {
		if q != "" && !strings.Contains(strings.ToLower(r.Name), q) && !strings.Contains(strings.ToLower(r.Username), q) {
			continue
		}
		un := ""
		if r.Username != "" {
			un = "@" + r.Username
		}
		mem := ""
		if r.Members > 0 {
			mem = fmt.Sprintf(" | участников: %d", r.Members)
		}
		fmt.Fprintf(&sb, "%d | %s | %s | %s%s | непрочитано: %d\n", r.ID, r.Kind, r.Name, un, mem, r.Unread)
		if n++; n >= limit {
			break
		}
	}
	return sb.String(), nil
}

// History: последние сообщения чата, старые сверху.
func (u *User) History(ctx context.Context, chat int64, limit int) (string, error) {
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return "", err
	}
	api, _ := u.apiCtx()
	if api == nil {
		return "", fmt.Errorf("Telegram ещё не подключён")
	}
	res, err := api.MessagesGetHistory(ctx, &tg.MessagesGetHistoryRequest{Peer: p, Limit: limit})
	if err != nil {
		return "", err
	}
	box, ok := res.(interface {
		GetMessages() []tg.MessageClass
		GetUsers() []tg.UserClass
	})
	if !ok {
		return "", fmt.Errorf("пустой ответ Telegram")
	}
	names := map[int64]string{}
	for _, c := range box.GetUsers() {
		if x, ok := c.(*tg.User); ok {
			names[x.ID] = userName(x)
		}
	}
	msgs := box.GetMessages()
	var sb strings.Builder
	for i := len(msgs) - 1; i >= 0; i-- {
		m, ok := msgs[i].(*tg.Message)
		if !ok {
			continue
		}
		who := "я"
		if !m.Out {
			who = "собеседник"
			if f, ok := m.FromID.(*tg.PeerUser); ok && names[f.UserID] != "" {
				who = names[f.UserID]
			}
		}
		txt := strings.TrimSpace(m.Message)
		switch md := m.Media.(type) {
		case *tg.MessageMediaPhoto:
			txt = strings.TrimSpace("[фото] " + txt)
		case *tg.MessageMediaDocument:
			kind := "[файл]"
			if d, ok := md.Document.(*tg.Document); ok {
				for _, at := range d.Attributes {
					switch x := at.(type) {
					case *tg.DocumentAttributeSticker:
						kind = "[стикер " + x.Alt + "]"
					case *tg.DocumentAttributeAudio:
						if x.Voice {
							kind = "[голосовое]"
						} else {
							kind = "[аудио]"
						}
					case *tg.DocumentAttributeVideo:
						kind = "[видео]"
					}
				}
			}
			txt = strings.TrimSpace(kind + " " + txt)
		}
		if r := []rune(txt); len(r) > 300 {
			txt = string(r[:300]) + "…"
		}
		fmt.Fprintf(&sb, "%d | %s | %s | %s\n", m.ID, time.Unix(int64(m.Date), 0).Format("02.01 15:04"), who, strings.ReplaceAll(txt, "\n", " "))
	}
	if sb.Len() == 0 {
		return "сообщений нет", nil
	}
	return sb.String(), nil
}

// Edit правит своё сообщение.
func (u *User) Edit(ctx context.Context, chat int64, msgID int, text string) error {
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return err
	}
	api, _ := u.apiCtx()
	_, err = api.MessagesEditMessage(ctx, &tg.MessagesEditMessageRequest{Peer: p, ID: msgID, Message: text})
	return err
}

// Delete удаляет своё сообщение у всех.
func (u *User) Delete(ctx context.Context, chat int64, msgID int) error {
	if _, err := u.peerFor(ctx, chat); err != nil {
		return err
	}
	api, _ := u.apiCtx()
	_, err := api.MessagesDeleteMessages(ctx, &tg.MessagesDeleteMessagesRequest{Revoke: true, ID: []int{msgID}})
	return err
}

// SendFile отправляет файл или картинку с подписью.
func (u *User) SendFile(ctx context.Context, chat int64, path, caption string) error {
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return err
	}
	api, _ := u.apiCtx()
	f, err := uploader.NewUploader(api).FromPath(ctx, path)
	if err != nil {
		return fmt.Errorf("загрузка файла: %w", err)
	}
	ext := strings.ToLower(filepath.Ext(path))
	var media tg.InputMediaClass
	if ext == ".jpg" || ext == ".jpeg" || ext == ".png" {
		media = &tg.InputMediaUploadedPhoto{File: f}
	} else {
		mt := mime.TypeByExtension(ext)
		if mt == "" {
			mt = "application/octet-stream"
		}
		media = &tg.InputMediaUploadedDocument{File: f, MimeType: mt, Attributes: []tg.DocumentAttributeClass{&tg.DocumentAttributeFilename{FileName: filepath.Base(path)}}}
	}
	_, err = api.MessagesSendMedia(ctx, &tg.MessagesSendMediaRequest{Peer: p, Media: media, Message: caption, RandomID: mrand.Int63()})
	return err
}
