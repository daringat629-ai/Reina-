// Package telegram: общение с хозяином. Логика (кому отвечать, подтверждения, «занята», /usage, /reset) не зависит от способа входа:
// Transport бывает «бот» (Bot API, токен от BotFather) и «аккаунт» (обычный пользовательский аккаунт по номеру телефона, как у прежней версии на TDLib).
package telegram

import (
	"context"
	"encoding/base64"
	"fmt"
	"log"
	"math/rand"
	"strings"
	"sync"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/tools"
	"reina/internal/voice"
)

// Transport доставляет входящие сообщения и отправляет ответы.
type Incoming struct {
	Chat      int64
	Text      string // текст или подпись к картинке
	Image     []byte // jpeg/png, если пришло фото
	Mime      string
	Voice     []byte // голосовое сообщение (ogg/opus), если пришло
	VoiceMime string
	MsgID     int    // номер сообщения (для «прочитано» и реакций), 0 если неизвестен
	Group     bool   // сообщение из группы
	From      string // имя автора в группе
	Mentioned bool   // в группе: её упомянули или ответили ей
}

// Reader умеют не все транспорты: «прочитано» (две галочки) и «печатает…».
type Reader interface {
	MarkRead(chat int64, msgID int)
	Typing(chat int64)
}

// VoiceSender умеют не все транспорты: отправить голосовое сообщение.
type VoiceSender interface {
	SendVoice(ctx context.Context, chat int64, audio []byte, mime string, seconds int) error
}

type Transport interface {
	// Run работает до отмены ctx и вызывает in для каждого входящего личного сообщения (не своего).
	Run(ctx context.Context, in func(Incoming)) error
	Send(chat int64, text string) error
	Health() error
}

type Bot struct {
	tr      Transport
	allowed map[int64]bool // кому вообще отвечаем; остальным молчим
	OwnerID int64          // кому задаём вопросы про опасные действия
	Agent   *agent.Agent
	Ledger  *budget.Ledger

	mu      sync.Mutex
	pending chan bool // ждём «да/нет» на опасное действие
	busy    map[int64]bool

	Voice      *voice.Client // nil: голосовые выключены
	VoiceReply string        // mirror | always | never
	VoiceMax   int           // длиннее: отвечать текстом

	GroupNames []string      // на какие имена откликается в группе
	ChimePct   int           // шанс вклиниться в группе без обращения, % (по умолчанию 6)
	GroupCool  time.Duration // пауза между её ответами в одной группе
	groupAt    map[int64]time.Time
	lastIn     map[int64]time.Time // когда в чате последний раз писали ей
}

// LastIncoming: когда хозяин (или любой собеседник чата) писал ей в последний раз.
func (b *Bot) LastIncoming(chat int64) time.Time {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.lastIn[chat]
}

// Initiate: она сама пишет в чат (напоминание, «соскучилась»): prompt служебный, модель отвечает как обычно.
// ok=false: чат занят разговором или она решила промолчать (ответ SKIP).
func (b *Bot) Initiate(ctx context.Context, chat int64, prompt string) (sent bool) {
	b.mu.Lock()
	if b.busy[chat] {
		b.mu.Unlock()
		return false
	}
	b.busy[chat] = true
	b.mu.Unlock()
	defer func() {
		b.mu.Lock()
		b.busy[chat] = false
		b.lastIn[chat] = time.Now() // чтобы не писать подряд снова
		b.mu.Unlock()
	}()
	session := fmt.Sprintf("tg:%d", chat)
	ctx = tools.WithChat(ctx, chat, 0)
	ans, err := b.Agent.Reply(ctx, session, prompt)
	trim := strings.TrimSpace(ans)
	if err != nil || trim == "" || strings.HasPrefix(strings.ToUpper(trim), "SKIP") || strings.HasPrefix(trim, "(не вышло") {
		if err == nil {
			b.Agent.DropLast(session, 2)
		}
		return false
	}
	rd, _ := b.tr.(Reader)
	if rd != nil {
		rd.Typing(chat)
	}
	select {
	case <-time.After(b.Agent.ThinkDelay()):
	case <-ctx.Done():
		return false
	}
	if tools.Spoke(ctx) {
		return true
	}
	if b.sendVoice(ctx, chat, ans, b.Agent.TakeVoice(session)) {
		return true
	}
	b.sendChunks(ctx, chat, ans, rd)
	return true
}

// SetGroups: имена и пауза для групп (группа должна быть в allowed_ids).
func (b *Bot) SetGroups(names []string, cool time.Duration, chimePct int) {
	if chimePct != 0 {
		if chimePct < 0 {
			chimePct = 0
		}
		b.ChimePct = chimePct
	}
	if len(names) > 0 {
		b.GroupNames = names
	}
	if cool > 0 {
		b.GroupCool = cool
	}
}

// addressed: обратились ли к ней в группе.
func (b *Bot) addressed(m Incoming) bool {
	if m.Mentioned {
		return true
	}
	t := strings.ToLower(m.Text)
	for _, n := range b.GroupNames {
		if n != "" && strings.Contains(t, strings.ToLower(n)) {
			return true
		}
	}
	return false
}

// SetVoice включает голосовые: распознавание входящих и озвучку ответов.
func (b *Bot) SetVoice(c *voice.Client, reply string, maxChars int) {
	b.Voice, b.VoiceReply, b.VoiceMax = c, reply, maxChars
}

func NewBot(tr Transport, owner int64, allowed []int64, a *agent.Agent, l *budget.Ledger) *Bot {
	b := &Bot{tr: tr, OwnerID: owner, allowed: map[int64]bool{owner: true}, Agent: a, Ledger: l, busy: map[int64]bool{}, groupAt: map[int64]time.Time{}, lastIn: map[int64]time.Time{}, GroupNames: []string{"рейна", "рейн", "reina"}, GroupCool: 15 * time.Second, ChimePct: 6}
	for _, id := range allowed {
		b.allowed[id] = true
	}
	a.Confirm = func(session, desc string) bool { return b.ask(desc) }
	return b
}

func (b *Bot) Send(chat int64, text string) {
	r := []rune(text)
	for len(r) > 0 { // лимит Telegram 4096
		n := len(r)
		if n > 4000 {
			n = 4000
		}
		if err := b.tr.Send(chat, string(r[:n])); err != nil {
			log.Printf("telegram: не отправилось: %v", err)
			return
		}
		r = r[n:]
	}
}

// ask спрашивает владельца и ждёт ответ до двух минут. Отвечать «да» может только он сам.
func (b *Bot) ask(desc string) bool {
	ch := make(chan bool, 1)
	b.mu.Lock()
	b.pending = ch
	b.mu.Unlock()
	b.Send(b.OwnerID, "Выполнить? "+desc+"\nОтветьте «да» или «нет».")
	defer func() { b.mu.Lock(); b.pending = nil; b.mu.Unlock() }()
	select {
	case v := <-ch:
		return v
	case <-time.After(2 * time.Minute):
		return false
	}
}

// Handle обрабатывает одно входящее сообщение. Отдельно от транспорта, чтобы тестировать.
func (b *Bot) Handle(ctx context.Context, chat int64, text string) {
	b.HandleIncoming(ctx, Incoming{Chat: chat, Text: text})
}

func (b *Bot) HandleIncoming(ctx context.Context, m Incoming) {
	chat, text := m.Chat, m.Text
	if !b.allowed[chat] {
		return // чужим не отвечаем вообще
	}
	say := func(s string) {
		if !m.Group { // в группах об ошибках молчим
			b.Send(chat, s)
		}
	}
	chime := false // в группе вклинивается сама, к ней не обращались
	if m.Group {
		if len(m.Voice) > 0 {
			return
		}
		if !b.addressed(m) {
			if len(m.Image) > 0 || len(strings.TrimSpace(m.Text)) < 4 || rand.Intn(100) >= b.ChimePct {
				return
			}
			chime = true
		}
		b.mu.Lock()
		last := b.groupAt[chat]
		if time.Since(last) < b.GroupCool {
			b.mu.Unlock()
			return
		}
		b.groupAt[chat] = time.Now()
		b.mu.Unlock()
		if chime {
			text = "[в группе, пишет " + m.From + "; к тебе не обращались. Вклинивайся, только если тебе правда есть что сказать (смешно, близко, возмутило), коротко; иначе ответь одним словом SKIP] " + text
		} else {
			text = "[в группе, пишет " + m.From + "] " + text
		}
		m.Text = text
	}
	if r, ok := b.tr.(Reader); ok && m.MsgID > 0 && !m.Group {
		go r.MarkRead(chat, m.MsgID) // две галочки только тем, кому она отвечает
	}
	t := strings.ToLower(strings.TrimSpace(text))
	if len(m.Image) > 0 {
		t = "" // подпись к фото не считается командой или ответом «да»
	}
	if chat == b.OwnerID && !m.Group && len(m.Image) == 0 && len(m.Voice) == 0 {
		b.mu.Lock()
		p := b.pending
		b.mu.Unlock()
		if p != nil {
			select {
			case p <- (t == "да" || t == "yes" || t == "y" || t == "ок"):
			default:
			}
			return
		}
	}
	b.mu.Lock()
	b.lastIn[chat] = time.Now()
	b.mu.Unlock()
	session := fmt.Sprintf("tg:%d", chat)
	switch {
	case t == "/start":
		say("Привет! Я Рейна. Пиши как обычно. /usage покажет расходы.")
		return
	case t == "/reset":
		b.Agent.Reset(session)
		say("Разговор забыла, долгая память осталась.")
		return
	case t == "/usage":
		d := b.Ledger.Today()
		say(fmt.Sprintf("Сегодня: запросов %d, токенов %d вход / %d выход, $%.4f, ответов из памяти без запроса: %d.", d.Requests, d.Prompt, d.Completion, d.USD, d.Saved))
		return
	}
	b.mu.Lock()
	if b.busy[chat] {
		b.mu.Unlock()
		say("Секунду, ещё отвечаю на прошлое.")
		return
	}
	b.busy[chat] = true
	b.mu.Unlock()
	go func() {
		defer func() {
			if r := recover(); r != nil { // одна ошибка не роняет бота
				log.Printf("паника в обработчике: %v", r)
				say("Что-то сломалось внутри, но я жива. Попробуй ещё раз.")
			}
			b.mu.Lock()
			b.busy[chat] = false
			b.mu.Unlock()
		}()
		cctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		defer cancel()
		cctx = tools.WithChat(cctx, chat, m.MsgID)
		rd, _ := b.tr.(Reader)
		heardVoice := false
		if len(m.Voice) > 0 {
			if b.Voice == nil {
				say("Голосовое получила, но распознавание не настроено. На сервере: ./reina voice <ключ ElevenLabs> <voice_id>")
				return
			}
			tx, terr := b.Voice.Transcribe(cctx, m.Voice, m.VoiceMime)
			if terr != nil || tx == "" {
				log.Printf("голосовое не распозналось: %v", terr)
				say("Не разобрала голосовое, напиши текстом или запиши ещё раз.")
				return
			}
			text, heardVoice = "[голосовое сообщение] "+tx, true
		}
		if len(m.Image) > 8<<20 {
			say("Картинка слишком большая (больше 8 МБ).")
			return
		}
		type result struct {
			ans string
			err error
		}
		done := make(chan result, 1)
		go func() { // мысли и ответ готовятся сразу, а «печатает…» появится позже
			var r result
			defer func() {
				if p := recover(); p != nil { // паника в ответе не роняет процесс
					log.Printf("паника в ответе: %v", p)
					r.err = fmt.Errorf("внутренняя ошибка")
				}
				done <- r
			}()
			if len(m.Image) > 0 {
				r.ans, r.err = b.Agent.ReplyImage(cctx, session, text, "data:"+m.Mime+";base64,"+base64.StdEncoding.EncodeToString(m.Image))
			} else {
				r.ans, r.err = b.Agent.Reply(cctx, session, text)
			}
		}()
		// сначала «прочитала и думает»: 3-4 секунды без «печатает…»
		select {
		case <-time.After(b.Agent.ThinkDelay()):
		case <-cctx.Done():
		}
		typingSince := time.Now()
		var res result
		for got := false; !got; {
			if rd != nil && !chime {
				rd.Typing(chat)
			}
			select {
			case res = <-done:
				got = true
			case <-time.After(4 * time.Second): // «печатает…» живёт около 5 секунд, обновляем
			case <-cctx.Done():
				say("Не получилось: слишком долго думала.")
				return
			}
		}
		ans, err := res.ans, res.err
		if chime {
			tr := strings.TrimSpace(ans)
			if err != nil || tr == "" || strings.HasPrefix(strings.ToUpper(tr), "SKIP") || strings.HasPrefix(tr, "(не вышло") {
				if err == nil {
					b.Agent.DropLast(session, 2)
				}
				return
			}
		}
		if err != nil {
			say("Не получилось: " + err.Error())
			return
		}
		// не мгновенно: «печатает…» по длине ответа, за вычетом уже напечатанного
		if rd != nil {
			for d := b.Agent.Pace(ans, time.Since(typingSince)); d > 0; d = b.Agent.Pace(ans, time.Since(typingSince)) {
				rd.Typing(chat)
				if d > 4*time.Second {
					d = 4 * time.Second
				}
				select {
				case <-time.After(d):
				case <-cctx.Done():
					d = 0
				}
				if cctx.Err() != nil {
					break
				}
			}
		}
		if tools.Spoke(cctx) { // она уже ответила голосовым через tg_voice: текстом не дублируем
			b.spontaneous(cctx, session, chat, m.MsgID)
			return
		}
		if b.sendVoice(cctx, chat, ans, heardVoice || b.Agent.TakeVoice(session)) {
			b.spontaneous(cctx, session, chat, m.MsgID)
			return
		}
		b.sendChunks(cctx, chat, ans, rd)
		b.spontaneous(cctx, session, chat, m.MsgID)
	}()
}

func (b *Bot) Name() string  { return "telegram" }
func (b *Bot) Health() error { return b.tr.Health() }

func (b *Bot) Run(ctx context.Context) error {
	return b.tr.Run(ctx, func(m Incoming) { b.HandleIncoming(ctx, m) })
}

// spontaneous: иногда сама ставит реакцию на сообщение или кидает стикер, если после раздумий ей этого захотелось.
func (b *Bot) spontaneous(ctx context.Context, session string, chat int64, msgID int) {
	e := b.Agent.TakeEmoji(session)
	msgr, ok := b.tr.(tools.Messenger)
	if e == "" || !ok || rand.Intn(100) >= b.Agent.SpontPct() {
		return
	}
	var err error
	if msgID != 0 && rand.Intn(10) < 7 {
		err = msgr.React(ctx, chat, msgID, tools.ReactionFor(e))
	} else {
		err = msgr.SendSticker(ctx, chat, e)
	}
	if err != nil {
		log.Printf("сама не смогла отправить %s: %v", e, err)
	}
}

// sendVoice озвучивает ответ, если так настроено; при любой ошибке возвращает false и ответ уходит текстом.
func (b *Bot) sendVoice(ctx context.Context, chat int64, ans string, want bool) bool {
	vs, ok := b.tr.(VoiceSender)
	if !ok || b.Voice == nil || b.VoiceReply == "never" || (b.VoiceReply != "always" && !want) {
		return false
	}
	max := b.VoiceMax
	if max <= 0 {
		max = 600
	}
	say := voice.ForSpeech(ans)
	if say == "" || len([]rune(say)) > max {
		return false
	}
	audio, mime, err := b.Voice.Speak(ctx, say)
	if err != nil {
		log.Printf("озвучка не вышла, отвечаю текстом: %v", err)
		return false
	}
	if err := vs.SendVoice(ctx, chat, audio, mime, voice.OggSeconds(audio)); err != nil {
		log.Printf("голосовое не отправилось, отвечаю текстом: %v", err)
		return false
	}
	return true
}

// SpeakTo озвучивает текст и отправляет голосовым (инструмент tg_voice).
func (b *Bot) SpeakTo(ctx context.Context, chat int64, text string) error {
	vs, ok := b.tr.(VoiceSender)
	if !ok || b.Voice == nil {
		return fmt.Errorf("голосовые не настроены")
	}
	say := voice.ForSpeech(text)
	if say == "" {
		return fmt.Errorf("пустой текст")
	}
	audio, mime, err := b.Voice.Speak(ctx, say)
	if err != nil {
		return err
	}
	return vs.SendVoice(ctx, chat, audio, mime, voice.OggSeconds(audio))
}

// sendChunks шлёт ответ короткими сообщениями (одна мысль это несколько сообщений подряд), перед каждым следующим «печатает…» и пауза.
func (b *Bot) sendChunks(ctx context.Context, chat int64, ans string, rd Reader) {
	parts := agent.Split(ans, b.Agent.ChunkMax())
	if len(parts) == 0 {
		return
	}
	if max := b.Agent.MaxChunks(); len(parts) > max { // хвост склеиваем в последнее сообщение, ничего не теряя
		parts = append(parts[:max-1], strings.Join(parts[max-1:], " "))
	}
	for i, p := range parts {
		if i > 0 {
			if d := b.Agent.ChunkPause(p); d > 0 {
				if rd != nil {
					rd.Typing(chat)
				}
				select {
				case <-time.After(d):
				case <-ctx.Done():
					b.Send(chat, strings.Join(parts[i:], " "))
					return
				}
			}
		}
		if tp := b.Agent.TypoPct(); tp > 0 && rand.Intn(100) < tp {
			if typo, fix, ok := agent.Typo(p); ok {
				b.Send(chat, typo)
				if d := b.Agent.ChunkPause(fix); d > 0 {
					select {
					case <-time.After(d):
					case <-ctx.Done():
					}
				}
				b.Send(chat, fix)
				continue
			}
		}
		b.Send(chat, p)
	}
}
