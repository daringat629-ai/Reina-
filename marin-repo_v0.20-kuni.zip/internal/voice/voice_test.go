package voice

import (
	"context"
	"encoding/binary"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func newTest(h http.HandlerFunc, dc int) (*Client, func()) {
	srv := httptest.NewServer(h)
	c := New(Config{APIKey: "k", VoiceID: "v1", DailyChars: dc})
	c.BaseURL = srv.URL
	return c, srv.Close
}

func TestTranscribeSendsFileAndKey(t *testing.T) {
	c, stop := newTest(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("xi-api-key") != "k" || r.URL.Path != "/v1/speech-to-text" {
			t.Errorf("запрос: %s %v", r.URL.Path, r.Header)
		}
		b, _ := io.ReadAll(r.Body)
		if !strings.Contains(string(b), "scribe_v1") || !strings.Contains(string(b), "AUDIO") {
			t.Errorf("тело без модели или файла")
		}
		w.Write([]byte(`{"text":" привет мир ","language_code":"rus"}`))
	}, 0)
	defer stop()
	got, err := c.Transcribe(context.Background(), []byte("AUDIO"), "audio/ogg")
	if err != nil || got != "привет мир" {
		t.Fatalf("%q %v", got, err)
	}
}

func TestSpeakFallsBackToMp3WhenOpusRefused(t *testing.T) {
	var formats []string
	c, stop := newTest(func(w http.ResponseWriter, r *http.Request) {
		f := r.URL.Query().Get("output_format")
		formats = append(formats, f)
		if strings.HasPrefix(f, "opus") {
			w.WriteHeader(422)
			w.Write([]byte("bad format"))
			return
		}
		w.Write([]byte("MP3DATA"))
	}, 0)
	defer stop()
	b, mime, err := c.Speak(context.Background(), "привет")
	if err != nil || mime != "audio/mpeg" || string(b) != "MP3DATA" || len(formats) != 2 {
		t.Fatalf("%q %s %v %v", b, mime, err, formats)
	}
}

func TestSpeakStopsOnAuthErrorAndDailyCap(t *testing.T) {
	n := 0
	c, stop := newTest(func(w http.ResponseWriter, r *http.Request) { n++; w.WriteHeader(401) }, 10)
	defer stop()
	if _, _, err := c.Speak(context.Background(), "привет"); err == nil || !strings.Contains(err.Error(), "401") || n != 1 {
		t.Fatalf("401 не должен повторяться: %v n=%d", err, n)
	}
	if _, _, err := c.Speak(context.Background(), "очень длинный текст сверх потолка"); err == nil || !strings.Contains(err.Error(), "потолок") {
		t.Fatalf("потолок: %v", err)
	}
	c.Now = func() time.Time { return time.Now().Add(48 * time.Hour) }
	if _, _, err := c.Speak(context.Background(), "привет"); err != nil && strings.Contains(err.Error(), "потолок") {
		t.Fatal("на следующий день счётчик обнуляется")
	}
}

func TestNotConfigured(t *testing.T) {
	c := New(Config{})
	if _, err := c.Transcribe(context.Background(), []byte("x"), ""); err == nil {
		t.Fatal("без ключа должна быть ошибка")
	}
}

func TestOggSecondsAndForSpeech(t *testing.T) {
	page := make([]byte, 27)
	copy(page, "OggS")
	binary.LittleEndian.PutUint64(page[6:], 48000*3+100)
	if got := OggSeconds(append([]byte("junk"), page...)); got != 4 {
		t.Fatalf("секунд %d", got)
	}
	if OggSeconds([]byte("nope")) != 0 {
		t.Fatal("мусор даёт 0")
	}
	if got := ForSpeech("**Ну привет** 😏 `код` _ок_"); got != "Ну привет код ок" {
		t.Fatalf("%q", got)
	}
}

func TestSpeakViaOpenRouterGrok(t *testing.T) {
	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		got = r.URL.Path + " " + r.Header.Get("Authorization") + " " + string(b)
		w.Write(make([]byte, 500))
	}))
	defer srv.Close()
	c := New(Config{ORBase: srv.URL, ORKey: "k"})
	au, mime, err := c.Speak(context.Background(), "привет")
	if err != nil || mime != "audio/mpeg" || len(au) != 500 {
		t.Fatal(err, mime, len(au))
	}
	for _, w := range []string{"/audio/speech", "Bearer k", "x-ai/grok-voice-tts-1.0", `"voice":"eve"`, `"response_format":"mp3"`} {
		if !strings.Contains(got, w) {
			t.Fatalf("нет %q в %s", w, got)
		}
	}
}
