module marin

go 1.21
