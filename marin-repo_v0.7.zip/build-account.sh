#!/bin/sh
# Сборка с входом обычным аккаунтом Telegram (gotd/td). Нужен Go и интернет, чтобы скачать библиотеку один раз.
# На Alpine: apk add go
set -e
cd "$(dirname "$0")"
go get github.com/gotd/td@latest
go mod tidy
CGO_ENABLED=0 go build -tags tguser -trimpath -ldflags="-s -w" -o marin .
echo "готово: ./marin (с входом аккаунтом). Дальше: ./marin import-kuni /путь/к/config.toml ; ./marin init ; ./marin run"
