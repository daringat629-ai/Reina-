package budget

import (
	"testing"
	"time"
)

func TestLedgerCountsPerDayAndEnforcesTheCap(t *testing.T) {
	d := t.TempDir()
	l := Open(d, 0.05)
	now := time.Date(2026, 10, 15, 12, 0, 0, 0, time.UTC)
	l.Now = func() time.Time { return now }
	l.Add(1000, 100, 0.03)
	if l.Exceeded() {
		t.Fatal("рано")
	}
	l.Add(1000, 100, 0.03)
	if !l.Exceeded() {
		t.Fatal("потолок не сработал")
	}
	now = now.Add(24 * time.Hour)
	if l.Exceeded() {
		t.Fatal("на следующий день счёт с нуля")
	}
	l2 := Open(d, 0.05)
	l2.Now = func() time.Time { return now.Add(-24 * time.Hour) }
	if l2.Today().Requests != 2 {
		t.Fatalf("учёт не сохранился: %+v", l2.Today())
	}
}

func TestParallelRequestsCannotJointlyExceedTheCap(t *testing.T) {
	l := Open(t.TempDir(), 0.10)
	var held []*Reservation
	ok := 0
	for i := 0; i < 10; i++ {
		if r, good := l.Reserve(0.04); good {
			ok++
			held = append(held, r)
		}
	}
	if ok != 2 {
		t.Fatalf("при потолке 0.10 и цене 0.04 влезают два запроса, прошло %d", ok)
	}
	l.Settle(held[0], 0, 0, 0) // запрос не удался: резерв вернулся
	if _, good := l.Reserve(0.04); !good {
		t.Fatal("возвращённый резерв не освободил место")
	}
	l.Settle(held[1], 1000, 100, 0.04)
	if l.Today().USD != 0.04 || l.Today().Requests != 1 {
		t.Fatalf("факт не записан: %+v", l.Today())
	}
}
