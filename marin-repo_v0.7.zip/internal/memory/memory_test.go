package memory

import (
	"os"
	"strings"
	"testing"
	"time"
)

func texts(fs []Fact) string {
	var t []string
	for _, f := range fs {
		t = append(t, f.Text)
	}
	return strings.Join(t, "|")
}

func TestSearchFindsByStemAndPersists(t *testing.T) {
	d := t.TempDir()
	s := Open(d)
	s.Add("Купить красную ткань для платья", "user", 0)
	s.Add("Ноутбук HP на Ubuntu", "user", 0)
	if _, added := s.Add("Купить красную ткань для платья", "user", 0); added {
		t.Fatal("дубль добавился")
	}
	if got := texts(s.Search("где моя ткань?", 3)); got != "Купить красную ткань для платья" {
		t.Fatalf("поиск по основе слова не сработал: %q", got)
	}
	if len(s.Search("погода", 3)) != 0 {
		t.Fatal("без совпадений память молчит")
	}
	if Open(d).Len() != 2 {
		t.Fatal("память не сохранилась")
	}
}

func TestAddingAppendsInsteadOfRewritingTheFile(t *testing.T) {
	d := t.TempDir()
	s := Open(d)
	s.Add("первый факт", "user", 0)
	before, _ := os.ReadFile(d + "/memory.jsonl")
	s.Add("второй факт", "user", 0)
	after, _ := os.ReadFile(d + "/memory.jsonl")
	if !strings.HasPrefix(string(after), string(before)) {
		t.Fatal("старые строки были переписаны, а не дополнены")
	}
}

func TestUpdateDeleteAndExpiry(t *testing.T) {
	d := t.TempDir()
	s := Open(d)
	now := time.Date(2026, 10, 15, 0, 0, 0, 0, time.UTC)
	s.Now = func() time.Time { return now }
	id, _ := s.Add("хозяин пьёт кофе", "user", 0)
	tmp, _ := s.Add("завтра у хозяина встреча", "user", 1)
	v := s.Version()
	if !s.Update(id, "хозяин пьёт чай") || s.Version() == v {
		t.Fatal("правка не засчитана")
	}
	if texts(s.Search("чай", 3)) != "хозяин пьёт чай" {
		t.Fatal("после правки поиск старый")
	}
	now = now.Add(48 * time.Hour)
	if len(s.Search("встреча", 3)) != 0 || s.Len() != 1 {
		t.Fatal("факт с истёкшим сроком всё ещё жив")
	}
	_ = tmp
	if !s.Delete(id) || s.Delete(id) || s.Len() != 0 {
		t.Fatal("удаление")
	}
	r := Open(d)
	r.Now = s.Now
	if r.Len() != 0 {
		t.Fatalf("после перезапуска удалённый факт вернулся: %d", r.Len())
	}
}

func TestOldFormatLinesAreStillRead(t *testing.T) {
	d := t.TempDir()
	os.WriteFile(d+"/memory.jsonl", []byte(`{"t":1,"text":"старая запись"}`+"\n"), 0o600)
	if Open(d).Len() != 1 {
		t.Fatal("файл прежней версии не прочитан")
	}
}

func TestGarbageGetsCompactedOnOpen(t *testing.T) {
	d := t.TempDir()
	s := Open(d)
	for i := 0; i < 80; i++ {
		id, _ := s.Add(strings.Repeat("ф", i+1), "user", 0)
		s.Delete(id)
	}
	s.Add("живой", "user", 0)
	Open(d)
	b, _ := os.ReadFile(d + "/memory.jsonl")
	if n := strings.Count(string(b), "\n"); n > 5 {
		t.Fatalf("журнал не сжался: %d строк", n)
	}
}
