//go:build tguser

package telegram

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gotd/td/telegram"
	"github.com/gotd/td/telegram/auth"
	"github.com/gotd/td/telegram/downloader"
	"github.com/gotd/td/telegram/message"
	"github.com/gotd/td/tg"
)

// UserConfig: вход как обычный аккаунт (api_id и api_hash берутся на my.telegram.org).
type UserConfig struct {
	APIID       int
	APIHash     string
	Phone       string
	Password    string // пароль двухфакторной защиты, если включена
	SessionPath string
}

// User: транспорт «аккаунт» на чистом Go (gotd/td, MTProto), без C-библиотек. Сессия хранится в файле, вход по номеру и коду один раз.
type User struct {
	cfg    UserConfig
	mu     sync.Mutex
	peers  map[int64]tg.InputPeerClass
	sender *message.Sender
	api    *tg.Client
	runCtx context.Context
	ready  bool
	lastOK time.Time
}

func NewUser(cfg UserConfig) (Transport, error) {
	if cfg.APIID == 0 || cfg.APIHash == "" || cfg.Phone == "" {
		return nil, errors.New("нужны telegram.api_id, telegram.api_hash и telegram.phone в config.json (marin init)")
	}
	return &User{cfg: cfg, peers: map[int64]tg.InputPeerClass{}, lastOK: time.Now()}, nil
}

func (u *User) Health() error {
	u.mu.Lock()
	defer u.mu.Unlock()
	if u.ready && time.Since(u.lastOK) > 10*time.Minute {
		return fmt.Errorf("нет связи с Telegram уже %s", time.Since(u.lastOK).Round(time.Second))
	}
	return nil
}

func (u *User) Send(chat int64, text string) error {
	u.mu.Lock()
	peer, sender, ctx := u.peers[chat], u.sender, u.runCtx
	u.mu.Unlock()
	if peer == nil || sender == nil {
		return fmt.Errorf("собеседник %d ещё не писал в эту сессию, адрес неизвестен", chat)
	}
	_, err := sender.To(peer).Text(ctx, text)
	return err
}

func (u *User) Run(ctx context.Context, in func(Incoming)) error {
	disp := tg.NewUpdateDispatcher()
	client := telegram.NewClient(u.cfg.APIID, u.cfg.APIHash, telegram.Options{
		SessionStorage: &telegram.FileSessionStorage{Path: u.cfg.SessionPath},
		UpdateHandler:  disp,
	})
	disp.OnNewMessage(func(ctx context.Context, e tg.Entities, upd *tg.UpdateNewMessage) error {
		m, ok := upd.Message.(*tg.Message)
		if !ok || m.Out {
			return nil
		}
		pu, ok := m.PeerID.(*tg.PeerUser) // только личные сообщения, группы и каналы игнорируем
		if !ok {
			return nil
		}
		if usr, ok := e.Users[pu.UserID]; ok {
			u.mu.Lock()
			u.peers[pu.UserID] = usr.AsInputPeer()
			u.lastOK = time.Now()
			u.mu.Unlock()
		}
		inc := Incoming{Chat: pu.UserID, Text: m.Message}
		if mp, ok := m.Media.(*tg.MessageMediaPhoto); ok { // фото: берём самый большой размер
			if ph, ok := mp.Photo.AsNotEmpty(); ok {
				var best *tg.PhotoSize
				for _, sz := range ph.Sizes {
					if ps, ok := sz.(*tg.PhotoSize); ok && (best == nil || ps.Size > best.Size) {
						best = ps
					}
				}
				if best != nil {
					var buf bytes.Buffer
					loc := &tg.InputPhotoFileLocation{ID: ph.ID, AccessHash: ph.AccessHash, FileReference: ph.FileReference, ThumbSize: best.Type}
					if _, err := downloader.NewDownloader().Download(u.api, loc).Stream(ctx, &buf); err != nil {
						log.Printf("telegram: фото не скачалось: %v", err)
						return nil
					}
					inc.Image, inc.Mime = buf.Bytes(), "image/jpeg"
				}
			}
		}
		if inc.Text == "" && len(inc.Image) == 0 {
			return nil
		}
		in(inc)
		return nil
	})
	return client.Run(ctx, func(ctx context.Context) error {
		flow := auth.NewFlow(auth.Constant(u.cfg.Phone, u.cfg.Password, auth.CodeAuthenticatorFunc(
			func(ctx context.Context, _ *tg.AuthSentCode) (string, error) {
				fmt.Print("Код из Telegram (придёт в приложение или SMS): ")
				s, err := bufio.NewReader(os.Stdin).ReadString('\n')
				return strings.TrimSpace(s), err
			})), auth.SendCodeOptions{})
		if err := client.Auth().IfNecessary(ctx, flow); err != nil {
			return fmt.Errorf("вход не удался: %w", err)
		}
		u.mu.Lock()
		u.api = client.API()
		u.sender, u.runCtx, u.ready, u.lastOK = message.NewSender(u.api), ctx, true, time.Now()
		u.mu.Unlock()
		log.Printf("Telegram: аккаунт %s вошёл", u.cfg.Phone)
		<-ctx.Done()
		return nil
	})
}
