//go:build !tguser

package telegram

import "errors"

// UserConfig: вход как обычный аккаунт.
type UserConfig struct {
	APIID       int
	APIHash     string
	Phone       string
	Password    string // пароль двухфакторной защиты, если включена
	SessionPath string
}

func NewUser(UserConfig) (Transport, error) {
	return nil, errors.New("эта сборка без входа аккаунтом; соберите с тегом: go get github.com/gotd/td@latest && go build -tags tguser (см. README)")
}
