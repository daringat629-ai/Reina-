package panel

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"marin/internal/agent"
	"marin/internal/budget"
	"marin/internal/config"
	"marin/internal/memory"
	"marin/internal/supervisor"
	"marin/internal/tools"
)

type dummy struct{ name string }

func (d dummy) Name() string                  { return d.name }
func (d dummy) Run(ctx context.Context) error { <-ctx.Done(); return nil }
func (d dummy) Health() error                 { return nil }

func deps(t *testing.T, token string) (Deps, *supervisor.Supervisor) {
	cfg := config.Default()
	cfg.Home = t.TempDir()
	led, mem := budget.Open(cfg.Home, 0), memory.Open(cfg.Home)
	a := agent.New(cfg, nil, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	sup := supervisor.New()
	return Deps{Token: token, Led: led, Mem: mem, Agent: a, Sup: sup}, sup
}

func do(h http.Handler, method, path, token, ip, body string) *httptest.ResponseRecorder {
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.RemoteAddr = ip + ":5555"
	if token != "" {
		req.Header.Set("X-Token", token)
	}
	h.ServeHTTP(rec, req)
	return rec
}

func TestPanelNeedsTheTokenAndRejectsAnEmptyOne(t *testing.T) {
	d, _ := deps(t, "s3cret")
	h := Handler(d, NewLimiter())
	for _, tc := range []struct {
		token string
		want  int
	}{{"s3cret", 200}, {"bad", 401}, {"", 401}, {"é", 401}} {
		if rec := do(h, "GET", "/api/status", tc.token, "1.1.1.1", ""); rec.Code != tc.want {
			t.Errorf("%q: %d", tc.token, rec.Code)
		}
	}
	d0, _ := deps(t, "")
	if do(Handler(d0, NewLimiter()), "GET", "/api/status", "", "1.1.1.1", "").Code != 401 {
		t.Error("пустой токен в настройках открыл панель")
	}
	if do(h, "GET", "/health", "", "1.1.1.1", "").Code != 200 {
		t.Error("health без токена")
	}
}

func TestTokenGuessingIsBlockedPerAddressAndTheRightTokenResetsTheCount(t *testing.T) {
	d, _ := deps(t, "right")
	now := time.Now()
	lim := NewLimiter()
	lim.Now = func() time.Time { return now }
	h := Handler(d, lim)
	for i := 0; i < 5; i++ {
		do(h, "GET", "/api/status", "wrong"+strings.Repeat("x", i), "9.9.9.9", "")
	}
	if rec := do(h, "GET", "/api/status", "right", "9.9.9.9", ""); rec.Code != 429 {
		t.Fatalf("после 5 неверных даже верный токен должен ждать: %d", rec.Code)
	}
	if rec := do(h, "GET", "/api/status", "right", "8.8.8.8", ""); rec.Code != 200 {
		t.Fatalf("другой адрес не должен страдать: %d", rec.Code)
	}
	now = now.Add(2 * time.Minute)
	if rec := do(h, "GET", "/api/status", "right", "9.9.9.9", ""); rec.Code != 200 {
		t.Fatalf("блокировка не снялась: %d", rec.Code)
	}
	for i := 0; i < 4; i++ {
		do(h, "GET", "/api/status", "bad", "7.7.7.7", "")
	}
	do(h, "GET", "/api/status", "right", "7.7.7.7", "")
	do(h, "GET", "/api/status", "bad", "7.7.7.7", "")
	if rec := do(h, "GET", "/api/status", "right", "7.7.7.7", ""); rec.Code != 200 {
		t.Fatal("верный токен должен обнулять счётчик ошибок")
	}
}

func TestModulesCanBeListedAndSwitchedFromThePanelButNotThePanelItself(t *testing.T) {
	d, sup := deps(t, "t")
	sup.Add(dummy{"voice"}, true)
	ctx, cancel := context.WithCancel(context.Background())
	sup.Start(ctx)
	defer func() { cancel(); sup.Wait() }()
	h := Handler(d, NewLimiter())
	time.Sleep(50 * time.Millisecond)
	if rec := do(h, "GET", "/api/modules", "t", "1.1.1.1", ""); !strings.Contains(rec.Body.String(), `"voice"`) || !strings.Contains(rec.Body.String(), "running") {
		t.Fatal(rec.Body.String())
	}
	if rec := do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"voice","enabled":false}`); !strings.Contains(rec.Body.String(), "stopped") {
		t.Fatal(rec.Body.String())
	}
	if do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"panel","enabled":false}`).Code != 400 {
		t.Fatal("панель не должна выключать сама себя")
	}
	if do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"нет","enabled":true}`).Code != 400 {
		t.Fatal("неизвестный модуль")
	}
}

func TestMemoryCanBeListedAndAFactDeletedThroughThePanel(t *testing.T) {
	d, _ := deps(t, "t")
	id, _ := d.Mem.Add("секретный факт", "user", 0)
	h := Handler(d, NewLimiter())
	if !strings.Contains(do(h, "GET", "/api/memory", "t", "1.1.1.1", "").Body.String(), "секретный факт") {
		t.Fatal("факт не виден")
	}
	if do(h, "DELETE", "/api/memory?id=999", "t", "1.1.1.1", "").Code != 404 {
		t.Fatal("несуществующий факт")
	}
	do(h, "DELETE", "/api/memory?id="+fmt.Sprint(id), "t", "1.1.1.1", "")
	if d.Mem.Len() != 0 {
		t.Fatal("факт не удалён")
	}
}
