// Package panel: небольшая панель состояния по HTTP (по умолчанию только 127.0.0.1).
// Доступ по токену в заголовке X-Token. Защита от перебора: после нескольких неверных токенов с одного адреса он блокируется на время.
// Для доступа не с этого компьютера нужен https или защищённый туннель (Tailscale и подобные): сама панель токен по сети в открытом виде не защитит.
package panel

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"marin/internal/agent"
	"marin/internal/budget"
	"marin/internal/memory"
	"marin/internal/supervisor"
)

// Limiter считает неверные попытки по адресу.
type Limiter struct {
	mu    sync.Mutex
	fails map[string]*rec
	Max   int
	Lock  time.Duration
	Now   func() time.Time
}

type rec struct {
	n     int
	until time.Time
}

func NewLimiter() *Limiter {
	return &Limiter{fails: map[string]*rec{}, Max: 5, Lock: time.Minute, Now: time.Now}
}

// Blocked: адрес сейчас заблокирован.
func (l *Limiter) Blocked(ip string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	r := l.fails[ip]
	return r != nil && l.Now().Before(r.until)
}

func (l *Limiter) Fail(ip string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	r := l.fails[ip]
	if r == nil {
		if len(l.fails) > 1000 { // адресов слишком много: начинаем счёт заново, память не растёт
			l.fails = map[string]*rec{}
		}
		r = &rec{}
		l.fails[ip] = r
	}
	if r.until.Before(l.Now()) && r.n >= l.Max {
		r.n = 0 // блокировка кончилась: счёт с нуля
	}
	r.n++
	if r.n >= l.Max {
		r.until = l.Now().Add(l.Lock)
	}
}

func (l *Limiter) OK(ip string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	delete(l.fails, ip)
}

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

type Deps struct {
	Token string
	Led   *budget.Ledger
	Mem   memory.Store
	Agent *agent.Agent
	Sup   *supervisor.Supervisor
}

func Handler(d Deps, lim *Limiter) http.Handler {
	mux := http.NewServeMux()
	auth := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			ip := clientIP(r)
			if lim.Blocked(ip) {
				w.Header().Set("Retry-After", "60")
				http.Error(w, `{"error":"too many attempts"}`, http.StatusTooManyRequests)
				return
			}
			if d.Token == "" || subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Token")), []byte(d.Token)) != 1 {
				lim.Fail(ip)
				http.Error(w, `{"error":"token"}`, http.StatusUnauthorized)
				return
			}
			lim.OK(ip)
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("Cache-Control", "no-store")
			h(w, r)
		}
	}
	mux.HandleFunc("/api/status", auth(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"ok": true, "today": d.Led.Today(), "facts": d.Mem.Len(), "sessions": d.Agent.SessionCount()})
	}))
	mux.HandleFunc("/api/modules", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost { // {"name":"telegram","enabled":false}
			var b struct {
				Name    string `json:"name"`
				Enabled bool   `json:"enabled"`
			}
			if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b) != nil || b.Name == "" {
				http.Error(w, `{"error":"bad request"}`, http.StatusBadRequest)
				return
			}
			if b.Name == "panel" && !b.Enabled {
				http.Error(w, `{"error":"панель нельзя выключить из самой панели"}`, http.StatusBadRequest)
				return
			}
			var err error
			if b.Enabled {
				err = d.Sup.Enable(b.Name)
			} else {
				err = d.Sup.Disable(b.Name)
			}
			if err != nil {
				http.Error(w, `{"error":`+quote(err.Error())+`}`, http.StatusBadRequest)
				return
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"modules": d.Sup.Status()})
	}))
	mux.HandleFunc("/api/memory", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			var id int64
			if _, err := fmt.Sscan(r.URL.Query().Get("id"), &id); err != nil || !d.Mem.Delete(id) {
				http.Error(w, `{"error":"нет такого факта"}`, http.StatusNotFound)
				return
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"facts": d.Mem.List(100)})
	}))
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) { w.Write([]byte("ok")) })
	return mux
}

func quote(s string) string { b, _ := json.Marshal(s); return string(b) }

// Module: панель как модуль под присмотром супервизора.
type Module struct {
	Addr string
	H    http.Handler
	mu   sync.Mutex
	srv  *http.Server
}

func (m *Module) Name() string { return "panel" }

func (m *Module) Run(ctx context.Context) error {
	srv := &http.Server{Addr: m.Addr, Handler: m.H, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second}
	ln, err := net.Listen("tcp", m.Addr)
	if err != nil {
		return err
	}
	m.mu.Lock()
	m.srv = srv
	m.mu.Unlock()
	go func() {
		<-ctx.Done()
		sh, c := context.WithTimeout(context.Background(), 3*time.Second)
		defer c()
		srv.Shutdown(sh)
	}()
	if err := srv.Serve(ln); err != nil && err != http.ErrServerClosed {
		return err
	}
	return nil
}

// Health: панель должна отвечать на /health.
func (m *Module) Health() error {
	addr := m.Addr
	if strings.HasPrefix(addr, ":") {
		addr = "127.0.0.1" + addr
	}
	c := http.Client{Timeout: 2 * time.Second}
	resp, err := c.Get("http://" + addr + "/health")
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}
