package llm

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestMessageWithImagesUsesContentParts(t *testing.T) {
	b, _ := json.Marshal(Message{Role: "user", Content: "что тут?", Images: []string{"data:image/jpeg;base64,AAA"}})
	s := string(b)
	if !strings.Contains(s, `"type":"image_url"`) || !strings.Contains(s, `"text":"что тут?"`) || !strings.Contains(s, "data:image/jpeg;base64,AAA") {
		t.Fatal(s)
	}
	b, _ = json.Marshal(Message{Role: "user", Content: "привет"})
	if !strings.Contains(string(b), `"content":"привет"`) {
		t.Fatal("обычное сообщение осталось строкой: " + string(b))
	}
}
