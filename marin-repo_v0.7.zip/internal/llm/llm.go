// Package llm: клиент OpenAI-совместимого чата с инструментами. Без внешних зависимостей.
package llm

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

type ToolCall struct {
	ID       string `json:"id"`
	Type     string `json:"type"`
	Function struct {
		Name      string `json:"name"`
		Arguments string `json:"arguments"`
	} `json:"function"`
}

type Message struct {
	Role       string     `json:"role"`
	Content    string     `json:"content"`
	ToolCalls  []ToolCall `json:"tool_calls,omitempty"`
	ToolCallID string     `json:"tool_call_id,omitempty"`
	Images     []string   `json:"-"` // data:image/...;base64,... (только для моделей с картинками)
}

// MarshalJSON: сообщение с картинками уходит в формате OpenAI с массивом частей content.
func (m Message) MarshalJSON() ([]byte, error) {
	type plain Message
	if len(m.Images) == 0 {
		return json.Marshal(plain(m))
	}
	parts := []map[string]any{{"type": "text", "text": m.Content}}
	for _, u := range m.Images {
		parts = append(parts, map[string]any{"type": "image_url", "image_url": map[string]string{"url": u}})
	}
	return json.Marshal(struct {
		Role    string           `json:"role"`
		Content []map[string]any `json:"content"`
	}{m.Role, parts})
}

type Tool struct {
	Type     string `json:"type"`
	Function struct {
		Name        string         `json:"name"`
		Description string         `json:"description"`
		Parameters  map[string]any `json:"parameters"`
	} `json:"function"`
}

type Usage struct {
	Prompt     int `json:"prompt_tokens"`
	Completion int `json:"completion_tokens"`
}

type Request struct {
	Model     string    `json:"model"`
	Messages  []Message `json:"messages"`
	Tools     []Tool    `json:"tools,omitempty"`
	MaxTokens int       `json:"max_tokens,omitempty"`
}

type Response struct {
	Message Message
	Usage   Usage
}

type Client struct {
	BaseURL, APIKey string
	HTTP            *http.Client
}

func New(base, key string, timeoutSec int) *Client {
	if timeoutSec <= 0 {
		timeoutSec = 60
	}
	return &Client{BaseURL: strings.TrimRight(base, "/"), APIKey: key, HTTP: &http.Client{Timeout: time.Duration(timeoutSec) * time.Second}}
}

// Chat делает один запрос. Ошибки сети и 5xx/429 повторяются дважды с паузой, остальные сразу возвращаются.
func (c *Client) Chat(ctx context.Context, r Request) (Response, error) {
	body, _ := json.Marshal(r)
	var last error
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 {
			select {
			case <-time.After(time.Duration(attempt) * 700 * time.Millisecond):
			case <-ctx.Done():
				return Response{}, ctx.Err()
			}
		}
		req, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/chat/completions", bytes.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		if c.APIKey != "" {
			req.Header.Set("Authorization", "Bearer "+c.APIKey)
		}
		resp, err := c.HTTP.Do(req)
		if err != nil {
			last = err
			continue
		}
		data, _ := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
		resp.Body.Close()
		if resp.StatusCode == 429 || resp.StatusCode >= 500 {
			last = fmt.Errorf("сервер модели: %d", resp.StatusCode)
			continue
		}
		if resp.StatusCode != 200 {
			return Response{}, fmt.Errorf("сервер модели: %d %s", resp.StatusCode, short(string(data), 200))
		}
		var out struct {
			Choices []struct {
				Message Message `json:"message"`
			} `json:"choices"`
			Usage Usage `json:"usage"`
		}
		if err := json.Unmarshal(data, &out); err != nil || len(out.Choices) == 0 {
			return Response{}, fmt.Errorf("непонятный ответ модели: %s", short(string(data), 200))
		}
		return Response{Message: out.Choices[0].Message, Usage: out.Usage}, nil
	}
	return Response{}, fmt.Errorf("нет связи с моделью: %v", last)
}

func short(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "…"
}
