package llm

import (
	"context"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
)

func TestChatRetriesServerErrorsAndParsesUsage(t *testing.T) {
	var n int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if atomic.AddInt32(&n, 1) < 3 {
			w.WriteHeader(503)
			return
		}
		if r.Header.Get("Authorization") != "Bearer k" {
			w.WriteHeader(401)
			return
		}
		w.Write([]byte(`{"choices":[{"message":{"role":"assistant","content":"привет"}}],"usage":{"prompt_tokens":12,"completion_tokens":3}}`))
	}))
	defer srv.Close()
	r, err := New(srv.URL, "k", 5).Chat(context.Background(), Request{Model: "m", Messages: []Message{{Role: "user", Content: "x"}}})
	if err != nil || r.Message.Content != "привет" || r.Usage.Prompt != 12 || n != 3 {
		t.Fatalf("%v %+v %d", err, r, n)
	}
}

func TestChatDoesNotRetryClientErrors(t *testing.T) {
	var n int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { atomic.AddInt32(&n, 1); w.WriteHeader(401) }))
	defer srv.Close()
	if _, err := New(srv.URL, "bad", 5).Chat(context.Background(), Request{Model: "m"}); err == nil || n != 1 {
		t.Fatalf("401 нужно вернуть сразу: %v %d", err, n)
	}
}
