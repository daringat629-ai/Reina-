// Package supervisor: жизненный цикл модулей. Каждый модуль (Telegram, панель, дальше голос, мир и так далее) работает в своей горутине
// под присмотром: паника не выходит наружу, упавший модуль перезапускается с растущей паузой, зависший (не проходит Health) перезапускается,
// любой модуль можно выключить и включить на ходу, не трогая остальные.
package supervisor

import (
	"context"
	"fmt"
	"log"
	"sort"
	"sync"
	"time"
)

type Module interface {
	Name() string
	Run(ctx context.Context) error // работает до отмены контекста; возврат раньше срока считается сбоем
	Health() error                 // быстрая проверка «жив ли», nil = здоров
}

type Status struct {
	Name     string `json:"name"`
	State    string `json:"state"` // running | stopped | backoff
	Restarts int    `json:"restarts"`
	LastErr  string `json:"last_error,omitempty"`
	Since    int64  `json:"since"`
}

type entry struct {
	m        Module
	cancel   context.CancelFunc
	done     chan struct{}
	enabled  bool
	state    string
	restarts int
	lastErr  string
	since    time.Time
}

type Supervisor struct {
	mu      sync.Mutex
	mods    map[string]*entry
	ctx     context.Context
	wg      sync.WaitGroup
	MinWait time.Duration // первая пауза перед перезапуском
	MaxWait time.Duration
	Health  time.Duration // как часто проверять Health
	Strikes int           // сколько проверок подряд должно провалиться
	Stable  time.Duration // проработал столько: пауза сбрасывается
}

func New() *Supervisor {
	return &Supervisor{mods: map[string]*entry{}, MinWait: time.Second, MaxWait: time.Minute, Health: 15 * time.Second, Strikes: 3, Stable: 30 * time.Second}
}

// Add регистрирует модуль; если супервизор уже запущен и enabled, модуль стартует сразу.
func (s *Supervisor) Add(m Module, enabled bool) {
	s.mu.Lock()
	e := &entry{m: m, enabled: enabled, state: "stopped", since: time.Now()}
	s.mods[m.Name()] = e
	started := s.ctx != nil
	s.mu.Unlock()
	if started && enabled {
		s.start(e)
	}
}

// Start запускает все включённые модули; Wait ждёт их остановки после отмены ctx.
func (s *Supervisor) Start(ctx context.Context) {
	s.mu.Lock()
	s.ctx = ctx
	var list []*entry
	for _, e := range s.mods {
		if e.enabled {
			list = append(list, e)
		}
	}
	s.mu.Unlock()
	for _, e := range list {
		s.start(e)
	}
}

func (s *Supervisor) Wait() { s.wg.Wait() }

func (s *Supervisor) start(e *entry) {
	s.mu.Lock()
	if e.cancel != nil {
		s.mu.Unlock()
		return
	}
	ctx, cancel := context.WithCancel(s.ctx)
	e.cancel, e.done, e.enabled = cancel, make(chan struct{}), true
	done := e.done
	s.mu.Unlock()
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		defer close(done)
		s.loop(ctx, e)
		s.mu.Lock()
		e.state, e.since = "stopped", time.Now()
		s.mu.Unlock()
	}()
}

func safeRun(ctx context.Context, m Module) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("паника: %v", r)
		}
	}()
	return m.Run(ctx)
}

func safeHealth(m Module) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("паника в проверке: %v", r)
		}
	}()
	return m.Health()
}

func (s *Supervisor) loop(ctx context.Context, e *entry) {
	wait := s.MinWait
	for ctx.Err() == nil {
		s.set(e, "running", "")
		runCtx, cancel := context.WithCancel(ctx)
		began := time.Now()
		hdone := make(chan struct{})
		go s.watch(runCtx, e, cancel, hdone)
		err := safeRun(runCtx, e.m)
		cancel()
		<-hdone
		if ctx.Err() != nil {
			return
		}
		msg := "модуль завершился"
		if err != nil {
			msg = err.Error()
		}
		log.Printf("модуль %s: %s; перезапуск через %s", e.m.Name(), msg, wait)
		s.mu.Lock()
		e.restarts++
		s.mu.Unlock()
		s.set(e, "backoff", msg)
		if time.Since(began) > s.Stable {
			wait = s.MinWait
		}
		select {
		case <-time.After(wait):
		case <-ctx.Done():
			return
		}
		if wait *= 2; wait > s.MaxWait {
			wait = s.MaxWait
		}
	}
}

// watch опрашивает Health; после Strikes провалов подряд отменяет запуск, и loop перезапускает модуль.
func (s *Supervisor) watch(ctx context.Context, e *entry, cancel context.CancelFunc, done chan struct{}) {
	defer close(done)
	bad := 0
	t := time.NewTicker(s.Health)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			if err := safeHealth(e.m); err != nil {
				bad++
				s.mu.Lock()
				e.lastErr = "здоровье: " + err.Error()
				s.mu.Unlock()
				if bad >= s.Strikes {
					cancel()
					return
				}
			} else {
				bad = 0
			}
		}
	}
}

func (s *Supervisor) set(e *entry, state, err string) {
	s.mu.Lock()
	e.state, e.since = state, time.Now()
	if err != "" {
		e.lastErr = err
	}
	s.mu.Unlock()
}

// Disable выключает модуль и ждёт его остановки; остальные не затрагиваются.
func (s *Supervisor) Disable(name string) error {
	s.mu.Lock()
	e := s.mods[name]
	if e == nil {
		s.mu.Unlock()
		return fmt.Errorf("нет модуля %q", name)
	}
	e.enabled = false
	cancel, done := e.cancel, e.done
	e.cancel = nil
	s.mu.Unlock()
	if cancel != nil {
		cancel()
		<-done
	}
	return nil
}

func (s *Supervisor) Enable(name string) error {
	s.mu.Lock()
	e := s.mods[name]
	ok := s.ctx != nil
	s.mu.Unlock()
	if e == nil {
		return fmt.Errorf("нет модуля %q", name)
	}
	if !ok {
		e.enabled = true
		return nil
	}
	s.start(e)
	return nil
}

func (s *Supervisor) Status() []Status {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Status
	for n, e := range s.mods {
		out = append(out, Status{Name: n, State: e.state, Restarts: e.restarts, LastErr: e.lastErr, Since: e.since.Unix()})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}
