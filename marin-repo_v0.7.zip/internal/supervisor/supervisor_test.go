package supervisor

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
)

type mod struct {
	name   string
	runs   int32
	run    func(ctx context.Context, n int32) error
	health func() error
}

func (m *mod) Name() string { return m.name }
func (m *mod) Run(ctx context.Context) error {
	n := atomic.AddInt32(&m.runs, 1)
	return m.run(ctx, n)
}
func (m *mod) Health() error {
	if m.health == nil {
		return nil
	}
	return m.health()
}

func fast() *Supervisor {
	s := New()
	s.MinWait, s.MaxWait, s.Health, s.Stable = 5*time.Millisecond, 20*time.Millisecond, 10*time.Millisecond, time.Hour
	return s
}

func until(t *testing.T, what string, f func() bool) {
	for i := 0; i < 400; i++ {
		if f() {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("не дождались: " + what)
}

func state(s *Supervisor, name string) Status {
	for _, x := range s.Status() {
		if x.Name == name {
			return x
		}
	}
	return Status{}
}

func block(ctx context.Context, _ int32) error { <-ctx.Done(); return nil }

func TestAPanickingModuleIsRestartedAndDoesNotTouchItsNeighbour(t *testing.T) {
	s := fast()
	bad := &mod{name: "bad", run: func(ctx context.Context, n int32) error {
		if n < 3 {
			panic("бум")
		}
		<-ctx.Done()
		return nil
	}}
	good := &mod{name: "good", run: block}
	s.Add(bad, true)
	s.Add(good, true)
	ctx, cancel := context.WithCancel(context.Background())
	s.Start(ctx)
	until(t, "перезапуск после паники", func() bool { return state(s, "bad").State == "running" && atomic.LoadInt32(&bad.runs) >= 3 })
	if state(s, "good").Restarts != 0 || atomic.LoadInt32(&good.runs) != 1 {
		t.Fatal("сосед пострадал")
	}
	if state(s, "bad").LastErr == "" {
		t.Fatal("причина сбоя не записана")
	}
	cancel()
	s.Wait()
}

func TestAHungModuleIsRestartedWhenHealthChecksFail(t *testing.T) {
	s := fast()
	var sick atomic.Bool
	sick.Store(true)
	m := &mod{name: "hung", run: block, health: func() error {
		if sick.Load() {
			sick.Store(false) // после перезапуска «выздоравливает»
			return errors.New("не отвечает")
		}
		return nil
	}}
	s.Strikes = 1
	s.Add(m, true)
	ctx, cancel := context.WithCancel(context.Background())
	s.Start(ctx)
	until(t, "перезапуск зависшего", func() bool { return atomic.LoadInt32(&m.runs) >= 2 })
	cancel()
	s.Wait()
}

func TestModulesCanBeSwitchedOffAndOnWhileTheCoreKeepsRunning(t *testing.T) {
	s := fast()
	a, b := &mod{name: "a", run: block}, &mod{name: "b", run: block}
	s.Add(a, true)
	s.Add(b, true)
	ctx, cancel := context.WithCancel(context.Background())
	s.Start(ctx)
	until(t, "оба работают", func() bool { return state(s, "a").State == "running" && state(s, "b").State == "running" })
	if err := s.Disable("a"); err != nil {
		t.Fatal(err)
	}
	if state(s, "a").State != "stopped" || state(s, "b").State != "running" {
		t.Fatalf("выключился не тот: %+v", s.Status())
	}
	s.Enable("a")
	until(t, "включился снова", func() bool { return state(s, "a").State == "running" && atomic.LoadInt32(&a.runs) == 2 })
	if s.Disable("нет") == nil || s.Enable("нет") == nil {
		t.Fatal("неизвестный модуль должен давать ошибку")
	}
	late := &mod{name: "late", run: block}
	s.Add(late, true) // добавлен на лету
	until(t, "добавленный на лету стартовал", func() bool { return state(s, "late").State == "running" })
	cancel()
	s.Wait()
}

func TestAModuleThatReturnsEarlyIsRestartedWithGrowingPause(t *testing.T) {
	s := fast()
	m := &mod{name: "quick", run: func(ctx context.Context, n int32) error { return errors.New("упал") }}
	s.Add(m, true)
	ctx, cancel := context.WithCancel(context.Background())
	s.Start(ctx)
	until(t, "несколько перезапусков", func() bool { return atomic.LoadInt32(&m.runs) >= 4 })
	if state(s, "quick").LastErr != "упал" {
		t.Fatal("причина не сохранена")
	}
	cancel()
	s.Wait()
}
