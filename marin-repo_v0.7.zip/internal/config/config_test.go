package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestImportKuniReadsApiIdAndHashFromTheOldConfig(t *testing.T) {
	p := filepath.Join(t.TempDir(), "config.toml")
	os.WriteFile(p, []byte("[general]\ntelegram_api_id = 12345   # my.telegram.org\ntelegram_api_hash = \"abcdef0123\"\nother = 1\n"), 0o600)
	id, h, err := ImportKuni(p)
	if err != nil || id != 12345 || h != "abcdef0123" {
		t.Fatalf("%d %q %v", id, h, err)
	}
	os.WriteFile(p, []byte("[general]\ntelegram_api_id = 0\ntelegram_api_hash = \"\"\n"), 0o600)
	if _, _, err := ImportKuni(p); err == nil {
		t.Fatal("пустые значения не должны считаться настройкой")
	}
}

func TestSaveKeepsThePrivateMode(t *testing.T) {
	c := Default()
	c.Home = t.TempDir()
	if err := Save(c); err != nil {
		t.Fatal(err)
	}
	st, _ := os.Stat(Path(c.Home))
	if st.Mode().Perm() != 0o600 {
		t.Fatalf("в конфиге ключи, права %v", st.Mode().Perm())
	}
	if got, err := Load(c.Home); err != nil || got.Telegram.Mode != "account" {
		t.Fatalf("%v %+v", err, got.Telegram)
	}
}

func TestPhoneMustBeInternational(t *testing.T) {
	for in, want := range map[string]bool{"+996 770 239 878": true, "+996(770)239-878": true, "770239878": false, "": false, "+1": false} {
		if got, ok := NormalizePhone(in); ok != want {
			t.Errorf("%q: %q %v", in, got, ok)
		}
	}
	if got, _ := NormalizePhone(" +996 770 239 878 "); got != "+996770239878" {
		t.Fatal(got)
	}
}
