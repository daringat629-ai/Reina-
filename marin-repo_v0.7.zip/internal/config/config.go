// Package config: единственный файл настроек ~/.marin/config.json. Только стандартная библиотека.
package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

type Config struct {
	Home     string   `json:"-"`
	Telegram Telegram `json:"telegram"`
	LLM      LLM      `json:"llm"`
	Budget   Budget   `json:"budget"`
	Agent    Agent    `json:"agent"`
	Panel    Panel    `json:"panel"`
}

type Telegram struct {
	Mode       string  `json:"mode"`   // account (обычный аккаунт, как у прежней Марин) или bot (токен от BotFather)
	Token      string  `json:"token"`  // для режима bot
	APIID      int     `json:"api_id"` // для режима account: my.telegram.org
	APIHash    string  `json:"api_hash"`
	Phone      string  `json:"phone"`       // +996...
	Password   string  `json:"password"`    // пароль двухфакторной защиты, если есть
	OwnerID    int64   `json:"owner_id"`    // ваш user id: только вам задаются вопросы про опасное
	AllowedIDs []int64 `json:"allowed_ids"` // кому ещё отвечать; остальным молчим
}

type LLM struct {
	BaseURL     string `json:"base_url"` // любой OpenAI-совместимый сервер: OpenRouter, Ollama, свой
	APIKey      string `json:"api_key"`
	FastModel   string `json:"fast_model"`   // для коротких бытовых сообщений
	StrongModel string `json:"strong_model"` // для сложных и с инструментами
	VisionModel string `json:"vision_model"` // для сообщений с картинками (пусто: картинки не разбираются)
	TimeoutSec  int    `json:"timeout_sec"`
}

// Budget: цены за 1 млн токенов (в долларах) и дневной потолок расходов. 0 = без потолка.
type Budget struct {
	DailyUSD      float64 `json:"daily_usd"`
	FastInPerM    float64 `json:"fast_in_per_m"`
	FastOutPerM   float64 `json:"fast_out_per_m"`
	StrongInPerM  float64 `json:"strong_in_per_m"`
	StrongOutPerM float64 `json:"strong_out_per_m"`
	VisionInPerM  float64 `json:"vision_in_per_m"`
	VisionOutPerM float64 `json:"vision_out_per_m"`
}

type Agent struct {
	Persona       string   `json:"persona"`
	WindowMsgs    int      `json:"window_msgs"`     // сколько последних сообщений идёт в запрос как есть
	SummaryChars  int      `json:"summary_chars"`   // потолок «краткого пересказа» старого разговора
	ToolOutputMax int      `json:"tool_output_max"` // потолок вывода инструмента, символов
	FastMaxTokens int      `json:"fast_max_tokens"`
	StrongMaxTok  int      `json:"strong_max_tokens"`
	CacheTTLSec   int      `json:"cache_ttl_sec"` // одинаковый вопрос без инструментов: ответ из памяти, 0 токенов
	ShellPolicy   string   `json:"shell_policy"`  // ask (спрашивать), always (без вопросов), never
	AllowedTools  []string `json:"allowed_tools"` // пусто: все встроенные; иначе только перечисленные
	ReadRoots     []string `json:"read_roots"`    // откуда можно читать файлы (пусто: домашний каталог)
	MaxCommand    int      `json:"max_command"`
	MaxDangerous  int      `json:"max_dangerous_per_turn"`
	Desktop       *bool    `json:"desktop"`   // управление ПК: экран, мышь, клавиатура, обои, запуск программ (по умолчанию включено)
	MaxSteps      int      `json:"max_steps"` // шагов «подумала, сделала, посмотрела» за один ответ (по умолчанию 6; для задач на ПК 20-30)
}

type Panel struct {
	Addr  string `json:"addr"` // 127.0.0.1:8767
	Token string `json:"token"`
}

func Default() Config {
	return Config{
		LLM:    LLM{BaseURL: "https://openrouter.ai/api/v1", FastModel: "deepseek/deepseek-v4.1-flash", StrongModel: "deepseek/deepseek-v4.1-flash", VisionModel: "qwen/qwen3-vl-30b-a3b-instruct", TimeoutSec: 60},
		Budget: Budget{DailyUSD: 1, FastInPerM: 0.02, FastOutPerM: 0.72, StrongInPerM: 0.02, StrongOutPerM: 0.72, VisionInPerM: 0.15, VisionOutPerM: 0.60},
		Agent: Agent{
			Persona:    "Ты Марин Китагава: живая, тёплая, говоришь коротко и по-русски. Отвечай по делу, без воды.",
			WindowMsgs: 10, SummaryChars: 700, ToolOutputMax: 1500, FastMaxTokens: 400, StrongMaxTok: 1200, CacheTTLSec: 600, ShellPolicy: "ask", MaxCommand: 1000, MaxDangerous: 3},
		Panel:    Panel{Addr: "127.0.0.1:8767"},
		Telegram: Telegram{Mode: "account"},
	}
}

func HomeDir() string {
	if h := os.Getenv("MARIN_HOME"); h != "" {
		return h
	}
	u, err := os.UserHomeDir()
	if err != nil {
		u = "."
	}
	return filepath.Join(u, ".marin")
}

func Path(home string) string { return filepath.Join(home, "config.json") }

// Load читает конфиг; недостающие поля берутся по умолчанию. Нет файла: ошибка os.ErrNotExist (вызывающий предложит `marin init`).
func Load(home string) (Config, error) {
	c := Default()
	c.Home = home
	b, err := os.ReadFile(Path(home))
	if err != nil {
		return c, err
	}
	if err := json.Unmarshal(b, &c); err != nil {
		return c, errors.New("config.json: " + err.Error())
	}
	return c, nil
}

// Save пишет конфиг с правами 0600 (там ключи).
func Save(c Config) error {
	if err := os.MkdirAll(c.Home, 0o700); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(c, "", "  ")
	tmp := Path(c.Home) + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, Path(c.Home))
}

var kuniKV = regexp.MustCompile(`(?m)^\s*(telegram_api_id|telegram_api_hash)\s*=\s*("([^"]*)"|[0-9]+)`)

// ImportKuni достаёт telegram_api_id и telegram_api_hash из config.toml прежней Марин (секция [general]).
func ImportKuni(path string) (id int, hash string, err error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0, "", err
	}
	for _, m := range kuniKV.FindAllStringSubmatch(string(b), -1) {
		switch m[1] {
		case "telegram_api_id":
			fmt.Sscan(m[2], &id)
		case "telegram_api_hash":
			hash = m[3]
		}
	}
	if id == 0 || hash == "" {
		return 0, "", errors.New("в этом файле не нашлись telegram_api_id и telegram_api_hash")
	}
	return id, hash, nil
}

// NormalizePhone приводит номер к виду +<цифры> (убирает пробелы, скобки, дефисы). Без плюса и кода страны номер не принимается: ok=false.
func NormalizePhone(p string) (string, bool) {
	var b []rune
	for _, r := range strings.TrimSpace(p) {
		if r >= '0' && r <= '9' || r == '+' && len(b) == 0 {
			b = append(b, r)
		}
	}
	s := string(b)
	if len(s) < 8 || s[0] != '+' || len(s) > 16 {
		return s, false
	}
	return s, true
}
