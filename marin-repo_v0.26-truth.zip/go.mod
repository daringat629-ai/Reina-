module reina

go 1.21
