#!/bin/sh
# Сборка с входом обычным аккаунтом Telegram (gotd/td). Нужен Go и интернет, чтобы скачать библиотеку один раз.
# На Alpine: apk add go
set -e
cd "$(dirname "$0")"
go get github.com/gotd/td@latest
go mod tidy
CGO_ENABLED=0 go build -tags tguser -trimpath -ldflags="-s -w" -o reina .
echo "готово: ./reina (с входом аккаунтом). Дальше: ./reina import-kuni /путь/к/config.toml ; ./reina init ; ./reina run"
