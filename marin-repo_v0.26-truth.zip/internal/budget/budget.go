// Package budget: учёт токенов и денег по дням, дневной потолок.
package budget

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type Day struct {
	Requests   int     `json:"requests"`
	Prompt     int     `json:"prompt"`
	Completion int     `json:"completion"`
	USD        float64 `json:"usd"`
	Saved      int     `json:"cache_hits"` // сколько ответов взято из памяти без запроса
}

type Ledger struct {
	mu   sync.Mutex
	path string
	Days map[string]*Day  `json:"days"`
	Cap  float64          `json:"-"`
	held float64          // деньги, зарезервированные под запросы в полёте
	Now  func() time.Time `json:"-"`
}

func Open(home string, dailyCap float64) *Ledger {
	l := &Ledger{path: filepath.Join(home, "usage.json"), Days: map[string]*Day{}, Cap: dailyCap, Now: time.Now}
	if b, err := os.ReadFile(l.path); err == nil {
		_ = json.Unmarshal(b, l)
		if l.Days == nil {
			l.Days = map[string]*Day{}
		}
	}
	return l
}

func (l *Ledger) today() *Day {
	k := l.Now().Format("2006-01-02")
	d := l.Days[k]
	if d == nil {
		d = &Day{}
		l.Days[k] = d
		if len(l.Days) > 60 { // хранить не больше 60 дней
			for old := range l.Days {
				if old < l.Now().AddDate(0, 0, -60).Format("2006-01-02") {
					delete(l.Days, old)
				}
			}
		}
	}
	return d
}

func (l *Ledger) save() {
	b, _ := json.Marshal(l)
	_ = os.WriteFile(l.path+".tmp", b, 0o600)
	_ = os.Rename(l.path+".tmp", l.path)
}

func (l *Ledger) Add(prompt, completion int, usd float64) {
	l.mu.Lock()
	defer l.mu.Unlock()
	d := l.today()
	d.Requests++
	d.Prompt += prompt
	d.Completion += completion
	d.USD += usd
	l.save()
}

func (l *Ledger) CacheHit() {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.today().Saved++
	l.save()
}

// Exceeded: дневной потолок исчерпан.
func (l *Ledger) Exceeded() bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.Cap > 0 && l.today().USD >= l.Cap
}

func (l *Ledger) Today() Day {
	l.mu.Lock()
	defer l.mu.Unlock()
	return *l.today()
}

// Reservation: резерв под один запрос. Без резерва несколько параллельных запросов проходили проверку одновременно и вместе превышали потолок.
type Reservation struct{ est float64 }

// Reserve резервирует est долларов; false, если вместе с уже потраченным и зарезервированным потолок будет превышен.
func (l *Ledger) Reserve(est float64) (*Reservation, bool) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.Cap > 0 && l.today().USD+l.held+est > l.Cap {
		return nil, false
	}
	l.held += est
	return &Reservation{est: est}, true
}

// Settle снимает резерв и записывает фактический расход (usd = 0 и нули токенов при ошибке запроса: резерв просто возвращается).
func (l *Ledger) Settle(r *Reservation, prompt, completion int, usd float64) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if r != nil {
		l.held -= r.est
		if l.held < 0 {
			l.held = 0
		}
	}
	if prompt == 0 && completion == 0 && usd == 0 {
		return
	}
	d := l.today()
	d.Requests++
	d.Prompt += prompt
	d.Completion += completion
	d.USD += usd
	l.save()
}

// DayRow: итог за один день.
type DayRow struct {
	Date string `json:"date"`
	Day
}

// History: последние n дней (старые первыми), без пропусков: дни без запросов нулевые.
func (l *Ledger) History(n int) []DayRow {
	l.mu.Lock()
	defer l.mu.Unlock()
	out := make([]DayRow, 0, n)
	for i := n - 1; i >= 0; i-- {
		k := l.Now().AddDate(0, 0, -i).Format("2006-01-02")
		r := DayRow{Date: k}
		if d := l.Days[k]; d != nil {
			r.Day = *d
		}
		out = append(out, r)
	}
	return out
}
