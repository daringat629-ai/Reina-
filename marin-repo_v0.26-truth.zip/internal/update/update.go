// Package update: самообновление. Хозяин присылает ей в личку zip из GitHub Actions (marin-linux N.zip) с подписью /update:
// она достаёт бинарник под свою архитектуру, подменяет себя (старый остаётся как reina.old) и перезапускается.
package update

import (
	"archive/zip"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"strings"
)

const maxBin = 80 << 20

// Extract достаёт из zip бинарник под архитектуру goarch (marin-linux-amd64, marin-linux-arm64 или просто reina).
func Extract(zipBytes []byte, goarch string) ([]byte, string, error) {
	zr, err := zip.NewReader(bytes.NewReader(zipBytes), int64(len(zipBytes)))
	if err != nil {
		return nil, "", errors.New("это не zip")
	}
	var pick *zip.File
	for _, f := range zr.File {
		n := strings.ToLower(path.Base(f.Name))
		if f.FileInfo().IsDir() {
			continue
		}
		if strings.Contains(n, "linux-"+goarch) && !strings.HasSuffix(n, ".sha256") {
			pick = f
			break
		}
		if n == "reina" && pick == nil {
			pick = f
		}
	}
	if pick == nil {
		return nil, "", fmt.Errorf("в архиве нет бинарника под %s", goarch)
	}
	if pick.UncompressedSize64 > maxBin {
		return nil, "", errors.New("бинарник слишком большой")
	}
	rc, err := pick.Open()
	if err != nil {
		return nil, "", err
	}
	defer rc.Close()
	b, err := io.ReadAll(io.LimitReader(rc, maxBin+1))
	if err != nil {
		return nil, "", err
	}
	if len(b) < 1<<20 || len(b) > maxBin || !bytes.HasPrefix(b, []byte("\x7fELF")) {
		return nil, "", errors.New("это не исполняемый файл Linux (ELF) или он подозрительно маленький")
	}
	return b, pick.Name, nil
}

// Install кладёт новый бинарник на место exe; прежний сохраняется рядом как exe.old.
func Install(exe string, bin []byte) error {
	tmp := exe + ".new"
	if err := os.WriteFile(tmp, bin, 0o755); err != nil {
		return err
	}
	if old, err := os.ReadFile(exe); err == nil {
		_ = os.WriteFile(exe+".old", old, 0o755)
	}
	if err := os.Rename(tmp, exe); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}
