package update

import (
	"archive/zip"
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func mk(t *testing.T, files map[string][]byte) []byte {
	var b bytes.Buffer
	w := zip.NewWriter(&b)
	for n, c := range files {
		f, _ := w.Create(n)
		f.Write(c)
	}
	w.Close()
	return b.Bytes()
}

func elf(n int) []byte { return append([]byte("\x7fELF"), make([]byte, n)...) }

func TestExtractPicksRightArchAndRejectsGarbage(t *testing.T) {
	z := mk(t, map[string][]byte{"marin-linux-amd64": elf(2 << 20), "marin-linux-arm64": append(elf(2<<20), 1)})
	b, name, err := Extract(z, "arm64")
	if err != nil || name != "marin-linux-arm64" || len(b) != 4+(2<<20)+1 {
		t.Fatal(name, err, len(b))
	}
	if _, _, err := Extract(z, "riscv64"); err == nil {
		t.Fatal("нет такой архитектуры")
	}
	if _, _, err := Extract(mk(t, map[string][]byte{"marin-linux-amd64": []byte("not elf, just text....")}), "amd64"); err == nil {
		t.Fatal("не ELF должен отклоняться")
	}
	if _, _, err := Extract([]byte("not a zip"), "amd64"); err == nil {
		t.Fatal("не zip")
	}
}

func TestInstallKeepsOldCopy(t *testing.T) {
	d := t.TempDir()
	exe := filepath.Join(d, "reina")
	os.WriteFile(exe, []byte("old"), 0o755)
	if err := Install(exe, []byte("new")); err != nil {
		t.Fatal(err)
	}
	if b, _ := os.ReadFile(exe); string(b) != "new" {
		t.Fatal("новый не на месте")
	}
	if b, _ := os.ReadFile(exe + ".old"); string(b) != "old" {
		t.Fatal("старый не сохранён")
	}
}
