//go:build windows

package update

import "errors"

func Restart(exe string) error {
	return errors.New("перезапуск не поддерживается, запустите заново")
}
