//go:build !windows

package update

import (
	"os"
	"syscall"
)

// Restart заменяет текущий процесс новым бинарником с теми же аргументами.
func Restart(exe string) error { return syscall.Exec(exe, os.Args, os.Environ()) }
