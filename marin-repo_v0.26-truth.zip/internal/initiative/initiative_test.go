package initiative

import (
	"context"
	"path/filepath"
	"testing"
	"time"

	"reina/internal/config"
	"reina/internal/tools"
)

type fake struct {
	prompts []string
	last    time.Time
	ok      bool
}

func (f *fake) Initiate(ctx context.Context, chat int64, p string) bool {
	f.prompts = append(f.prompts, p)
	return f.ok
}
func (f *fake) LastIncoming(int64) time.Time { return f.last }

func TestReminderFiresOnceAndIsRetriedWhenBusy(t *testing.T) {
	r := tools.NewReminders(filepath.Join(t.TempDir(), "r.json"), "UTC")
	now := time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)
	r.Now = func() time.Time { return now }
	r.Add(now.Add(-time.Minute), "выпить воды")
	f := &fake{ok: false}
	m := &Module{Owner: 1, Cfg: config.Initiative{Disabled: true}, Rem: r, Bot: f, Now: func() time.Time { return now }}
	m.Step(context.Background())
	if len(f.prompts) != 1 || len(r.List()) != 1 {
		t.Fatalf("занято: напоминание должно вернуться, prompts=%d list=%d", len(f.prompts), len(r.List()))
	}
	f.ok = true
	now = now.Add(2 * time.Minute)
	m.Step(context.Background())
	if len(r.List()) != 0 || len(f.prompts) != 2 {
		t.Fatalf("после отправки напоминаний быть не должно: %d", len(r.List()))
	}
}

func TestInitiativeRespectsNightIdleAndDailyLimit(t *testing.T) {
	r := tools.NewReminders(filepath.Join(t.TempDir(), "r.json"), "UTC")
	cur := time.Date(2026, 1, 1, 3, 0, 0, 0, time.UTC) // ночь
	f := &fake{ok: true, last: cur.Add(-10 * time.Hour)}
	m := &Module{Owner: 1, Cfg: config.Initiative{Pct: 100, CheckMin: 1, MaxPerDay: 2, FromHour: 10, ToHour: 23}, Rem: r, Bot: f, Now: func() time.Time { return cur }}
	m.Step(context.Background())
	if len(f.prompts) != 0 {
		t.Fatal("ночью не пишет")
	}
	cur = time.Date(2026, 1, 1, 14, 0, 0, 0, time.UTC)
	f.last = cur.Add(-time.Hour) // недавно общались
	m.Step(context.Background())
	if len(f.prompts) != 0 {
		t.Fatal("если недавно общались, не пишет")
	}
	f.last = cur.Add(-5 * time.Hour)
	for i := 0; i < 5; i++ {
		cur = cur.Add(10 * time.Minute)
		m.Step(context.Background())
	}
	if len(f.prompts) != 2 {
		t.Fatalf("лимит 2 в сутки, было %d", len(f.prompts))
	}
}

func TestParseWhen(t *testing.T) {
	r := tools.NewReminders(filepath.Join(t.TempDir(), "r.json"), "Asia/Bishkek")
	now := time.Date(2026, 1, 1, 6, 0, 0, 0, time.UTC)
	r.Now = func() time.Time { return now }
	if w, err := r.ParseWhen(30, ""); err != nil || !w.Equal(now.Add(30*time.Minute)) {
		t.Fatal("in_minutes", w, err)
	}
	w, err := r.ParseWhen(0, "2026-01-01 18:00") // Бишкек UTC+6 -> 12:00 UTC
	if err != nil || w.UTC().Hour() != 12 {
		t.Fatal("at", w, err)
	}
	if _, err := r.ParseWhen(0, "2025-01-01 10:00"); err == nil {
		t.Fatal("прошлое должно отклоняться")
	}
	if _, err := r.ParseWhen(0, "завтра"); err == nil {
		t.Fatal("мусор должен отклоняться")
	}
}
