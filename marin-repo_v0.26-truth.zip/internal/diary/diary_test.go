package diary

import (
	"strings"
	"testing"
	"time"
)

const page1 = "**2026-03-20 12:21 | Разговор про собаку папика**\n**Источник:** личка.\n**Теги:** #собака #прогулка\n**Importance score:** 0.8 – важная тема\n**Retrieval cues:** [\"собака Рекс\", \"прогулка вечером\"]"

func TestAddSearchUsageAndPlagiarism(t *testing.T) {
	s := Open(t.TempDir())
	cur := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	s.Now = func() time.Time { return cur }
	if ok, err := s.Add(page1); !ok || err != nil {
		t.Fatal(ok, err)
	}
	if ok, _ := s.Add(page1 + " "); ok {
		t.Fatal("копия страницы не должна записываться")
	}
	if ok, _ := s.Add("**Работа:** папик жаловался на дедлайны, я поддержала его и предложила перерыв, настроение тревожное."); !ok {
		t.Fatal("другая страница должна записаться")
	}
	got := s.Search("как там собаки на прогулке?", 2)
	if len(got) != 1 || !strings.Contains(got[0].Body, "Рекс") {
		t.Fatalf("поиск: %+v", got)
	}
	if got[0].Meta.Score != 0.8 {
		t.Fatalf("важность из текста: %v", got[0].Meta.Score)
	}
	again := s.Search("собака", 1)
	if again[0].Meta.UsageCount != 1 {
		t.Fatalf("счётчик использования: %d", again[0].Meta.UsageCount)
	}
	if s.Count() != 2 {
		t.Fatal(s.Count())
	}
}

func TestSplitPages(t *testing.T) {
	p := Split("страница номер один, достаточно длинная\n---\nстраница номер два, тоже длинная\n---\nкоротко")
	if len(p) != 2 {
		t.Fatalf("%q", p)
	}
}

func TestSameSecondDoesNotOverwrite(t *testing.T) {
	s := Open(t.TempDir())
	s.Now = func() time.Time { return time.Unix(1000, 0) }
	s.Add("первая запись про кофе утром и длинный текст чтобы пройти порог")
	s.Add("вторая совсем иная запись про футбол вечером с друзьями на поле")
	if s.Count() != 2 {
		t.Fatal("страницы затёрлись")
	}
}
