package agent

import (
	"context"
	"encoding/json"
	"os"
	"sort"
	"strings"
	"time"

	"reina/internal/llm"
)

type savedMsg struct {
	Role    string `json:"r"`
	Content string `json:"c"`
}

type savedSession struct {
	ID     string     `json:"id"`
	Sum    string     `json:"sum,omitempty"`
	LastAt time.Time  `json:"at"`
	Hist   []savedMsg `json:"h"`
}

const (
	persistKeep = 14                 // сколько последних реплик сессии хранится на диске
	persistAge  = 7 * 24 * time.Hour // сессии старше недели не сохраняются
)

// SaveSessions пишет разговоры на диск, чтобы после перезапуска она помнила, что было в каждом чате («одна Рейна»).
// Хранятся только реплики собеседника и её ответы; сессии, которые сейчас отвечают, пропускаются до следующего раза.
func (a *Agent) SaveSessions(path string) error {
	a.mu.Lock()
	list := make([]*Session, 0, len(a.sessions))
	for _, s := range a.sessions {
		list = append(list, s)
	}
	a.mu.Unlock()
	var out []savedSession
	for _, s := range list {
		if !s.mu.TryLock() {
			continue
		}
		ss := savedSession{ID: s.ID, Sum: s.sum, LastAt: s.lastAt}
		for _, m := range s.hist {
			if (m.Role == "user" || m.Role == "assistant") && m.Content != "" && len(m.ToolCalls) == 0 {
				ss.Hist = append(ss.Hist, savedMsg{m.Role, m.Content})
			}
		}
		s.mu.Unlock()
		if len(ss.Hist) > persistKeep {
			ss.Hist = ss.Hist[len(ss.Hist)-persistKeep:]
		}
		if len(ss.Hist) == 0 && ss.Sum == "" || !ss.LastAt.IsZero() && a.Now().Sub(ss.LastAt) > persistAge {
			continue
		}
		out = append(out, ss)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	raw, err := json.Marshal(out)
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// LoadSessions поднимает сохранённые разговоры; возвращает, сколько сессий вернулось. Уже существующие не трогает.
func (a *Agent) LoadSessions(path string) int {
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	var in []savedSession
	if json.Unmarshal(raw, &in) != nil {
		return 0
	}
	n := 0
	for _, ss := range in {
		a.mu.Lock()
		_, exists := a.sessions[ss.ID]
		a.mu.Unlock()
		if exists || a.Now().Sub(ss.LastAt) > persistAge && !ss.LastAt.IsZero() {
			continue
		}
		s := a.session(ss.ID)
		s.mu.Lock()
		s.sum, s.lastAt = ss.Sum, ss.LastAt
		for _, m := range ss.Hist {
			s.hist = append(s.hist, llm.Message{Role: m.Role, Content: m.Content})
		}
		s.mu.Unlock()
		n++
	}
	return n
}

// PersistLoop сохраняет разговоры раз в every и перед остановкой.
func (a *Agent) PersistLoop(ctx context.Context, path string, every time.Duration) {
	if every <= 0 {
		every = 90 * time.Second
	}
	t := time.NewTicker(every)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			a.SaveSessions(path)
			return
		case <-t.C:
			a.SaveSessions(path)
		}
	}
}

// SessionInfo: краткая карточка сессии для панели.
type SessionInfo struct {
	ID     string    `json:"id"`
	LastAt time.Time `json:"last_at"`
	Msgs   int       `json:"msgs"`
	Last   string    `json:"last"`
	Owner  bool      `json:"owner"`
}

func (a *Agent) Sessions() []SessionInfo {
	a.mu.Lock()
	list := make([]*Session, 0, len(a.sessions))
	for _, s := range a.sessions {
		list = append(list, s)
	}
	a.mu.Unlock()
	var out []SessionInfo
	for _, s := range list {
		info := SessionInfo{ID: s.ID, Owner: a.ownerIs(s.ID)}
		if s.mu.TryLock() {
			info.LastAt, info.Msgs = s.lastAt, len(s.hist)
			if n := len(s.hist); n > 0 {
				info.Last = Clip(strings.Join(strings.Fields(s.hist[n-1].Content), " "), 120)
			}
			s.mu.Unlock()
		}
		out = append(out, info)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].LastAt.After(out[j].LastAt) })
	return out
}

func (a *Agent) ownerIs(id string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.ownerSession != "" && a.ownerSession == id
}

// Dump: последние n реплик сессии для просмотра в панели.
func (a *Agent) Dump(id string, n int) []map[string]string {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	h := s.hist
	if len(h) > n {
		h = h[len(h)-n:]
	}
	var out []map[string]string
	for _, m := range h {
		if m.Role == "user" || m.Role == "assistant" {
			out = append(out, map[string]string{"role": m.Role, "text": m.Content})
		}
	}
	return out
}

// People: заметки об собеседниках (кто есть кто), по сессиям.
func (a *Agent) People() map[string][]string { return a.loadPeople() }

// PersonDelete убирает одну заметку (по номеру) или все заметки о человеке (idx < 0).
func (a *Agent) PersonDelete(session string, idx int) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	m := a.loadPeople()
	notes, ok := m[session]
	if !ok {
		return false
	}
	if idx < 0 || idx >= len(notes) {
		delete(m, session)
	} else {
		m[session] = append(notes[:idx:idx], notes[idx+1:]...)
		if len(m[session]) == 0 {
			delete(m, session)
		}
	}
	raw, err := json.Marshal(m)
	if err != nil {
		return false
	}
	return os.WriteFile(a.peoplePath(), raw, 0o600) == nil
}

// Thought: что она думала перед последним ответом в этой сессии (для панели).
func (a *Agent) Thought(id string) string {
	a.mu.Lock()
	s := a.sessions[id]
	a.mu.Unlock()
	if s == nil || !s.mu.TryLock() {
		return ""
	}
	defer s.mu.Unlock()
	return s.last
}

// DiaryPage: страница дневника для панели.
type DiaryPage struct {
	ID    string  `json:"id"`
	Score float64 `json:"score"`
	Uses  int     `json:"uses"`
	Body  string  `json:"body"`
}

// DiaryPages: последние n страниц или лучшие по запросу q.
func (a *Agent) DiaryPages(q string, n int) []DiaryPage {
	var src = a.pages.Recent(n)
	if strings.TrimSpace(q) != "" {
		src = a.pages.Search(q, n)
	}
	var out []DiaryPage
	for _, p := range src {
		out = append(out, DiaryPage{ID: p.ID, Score: p.Meta.Score, Uses: p.Meta.UsageCount, Body: Clip(p.Body, 1500)})
	}
	return out
}

func (a *Agent) DiaryRemove(id string) {
	if id == "" || strings.ContainsAny(id, `/\.`) {
		return
	}
	a.pages.Remove(id)
}

// Home: каталог данных.
func (a *Agent) Home() string { return a.cfg.Home }
