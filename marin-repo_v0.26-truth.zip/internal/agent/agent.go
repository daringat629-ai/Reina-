// Package agent: разговор Рейны. Здесь же вся экономия токенов:
//  1. окно из последних N сообщений, старое сжимается в короткий пересказ (раз в несколько сообщений, дешёвой моделью);
//  2. маршрутизатор: короткое бытовое идёт на быструю дешёвую модель без описаний инструментов, сложное и «сделай» на сильную;
//  3. ответ на повторный вопрос берётся из кэша (0 токенов), ключ учитывает сессию, версию памяти и пересказ; зависящее от времени и действий не кэшируется;
//  4. вывод инструментов обрезается, ответы ограничены по длине;
//  5. память подмешивается, только если нашлись совпадения (до 3 фактов);
//  6. дневной потолок: деньги резервируются до запроса, параллельные запросы не могут вместе его превысить.
//
// Каждый собеседник и канал живёт в своей Session (история, пересказ, кэш, замок): контексты не смешиваются,
// а ответы и сжатие внутри одной сессии идут строго по очереди.
package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"log"
	"math/rand"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"

	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/diary"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/tools"
)

type Chatter interface {
	Chat(ctx context.Context, r llm.Request) (llm.Response, error)
}

// Confirm спрашивает владельца про опасное действие в конкретной сессии.
type Confirm func(session, desc string) bool

type Agent struct {
	cfg   config.Config
	llm   Chatter
	led   *budget.Ledger
	mem   memory.Store
	tools *tools.Set

	ownerSession, ownerNote string // сессия хозяина и то, что она о нём знает

	mood   string
	moodAt time.Time

	pages *diary.Store // дневник в формате Куни

	abilities string // что у неё подключено (Telegram, голос): текст, который задаёт ядро

	// Aware перед каждым ответом даёт ей реальную картину: какие у неё чаты, что сейчас в этой группе.
	// owner=false для посторонних: им список чатов хозяина отдавать нельзя.
	Aware func(ctx context.Context, sessionID, text string, owner bool) string
	// Status даёт реальное состояние: время, что включено и сколько осталось, последние события, правила правды. Идёт в каждый ход.
	Status func(owner bool) string

	mu       sync.Mutex
	sessions map[string]*Session
	Confirm  Confirm
	Now      func() time.Time
}

type Session struct {
	ID     string
	mu     sync.Mutex // один ответ за раз в сессии
	hist   []llm.Message
	sum    string
	cache  map[string]cached
	lastAt time.Time // когда в сессии в последний раз отвечали
	aware  string    // картина чатов на этот ход (в историю не пишется)
	status string    // реальное состояние на этот ход
	last   string    // последние мысли: следующий проход видит, о чём она думала раньше
	voice  bool      // ей захотелось ответить голосом
	emoji  string    // эмодзи, которую ей захотелось отправить в ответ (реакция или стикер)
}

type cached struct {
	text string
	at   time.Time
}

const maxSessions = 200

func New(cfg config.Config, c Chatter, led *budget.Ledger, mem memory.Store, ts *tools.Set) *Agent {
	return &Agent{cfg: cfg, llm: c, led: led, mem: mem, tools: ts, sessions: map[string]*Session{}, Now: time.Now, pages: diary.Open(filepath.Join(cfg.Home, "diary"))}
}

type ownerSenderKey struct{}

// WithOwnerSender помечает ход: в группе пишет сам хозяин (по id, а не по имени). Инструментов и памяти ему это не открывает,
// но она узнаёт его, помнит личку и ведёт себя как одна Рейна на все чаты.
func WithOwnerSender(ctx context.Context) context.Context {
	return context.WithValue(ctx, ownerSenderKey{}, true)
}

func IsOwnerSender(ctx context.Context) bool {
	v, _ := ctx.Value(ownerSenderKey{}).(bool)
	return v
}

// SessionBrief: недавний разговор в одной из сессий.
type SessionBrief struct {
	ID   string
	Text string
}

func (a *Agent) briefOf(s *Session, n int) string {
	if !s.mu.TryLock() { // сессия сейчас отвечает: не ждём, чтобы не заклинить друг друга
		return ""
	}
	defer s.mu.Unlock()
	h := s.hist
	if len(h) > n {
		h = h[len(h)-n:]
	}
	var sb strings.Builder
	for _, m := range h {
		who := "собеседник"
		if m.Role == "assistant" {
			who = "я"
		}
		t := strings.Join(strings.Fields(m.Content), " ")
		if r := []rune(t); len(r) > 220 {
			t = string(r[:220]) + "…"
		}
		sb.WriteString(who + ": " + t + "\n")
	}
	return sb.String()
}

// Recent: последние n реплик сессии (старые сверху); пусто, если сессии нет или она занята.
func (a *Agent) Recent(sessionID string, n int) string {
	a.mu.Lock()
	s := a.sessions[sessionID]
	a.mu.Unlock()
	if s == nil {
		return ""
	}
	return a.briefOf(s, n)
}

// RecentOthers: что было в других сессиях за последнее время (кроме exclude), самые свежие первыми.
func (a *Agent) RecentOthers(exclude string, within time.Duration, per, max int) []SessionBrief {
	type ent struct {
		s  *Session
		at time.Time
	}
	a.mu.Lock()
	var es []ent
	for id, s := range a.sessions {
		if id != exclude && !s.lastAt.IsZero() && a.Now().Sub(s.lastAt) < within {
			es = append(es, ent{s, s.lastAt})
		}
	}
	a.mu.Unlock()
	sort.Slice(es, func(i, j int) bool { return es[i].at.After(es[j].at) })
	var out []SessionBrief
	for _, e := range es {
		if len(out) >= max {
			break
		}
		if t := a.briefOf(e.s, per); t != "" {
			out = append(out, SessionBrief{ID: e.s.ID, Text: t})
		}
	}
	return out
}

func (a *Agent) session(id string) *Session {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.sessions[id]
	if s == nil {
		if len(a.sessions) >= maxSessions { // не копим бесконечно: самую давнюю по порядку выбрасываем
			for k := range a.sessions {
				delete(a.sessions, k)
				break
			}
		}
		s = &Session{ID: id, cache: map[string]cached{}}
		a.sessions[id] = s
	}
	return s
}

var toolWords = []string{"сделай", "запусти", "выполни", "команд", "файл", "папк", "установ", "найди", "голосов", "переслать", "перешли", "историю", "переписк", "групп", "канал", "участник", "отредакт", "исправь", "тг ", "телеграм", "модул", "научись", "способност", "плагин", "загугли", "поищи", "в интернете", "новости", "погода", "погоду", "покажи", "проверь", "перезапуст", "удали", "создай", "прочитай", "диск", "процесс", "экран", "обои", "мышь", "откро", "нажми", "напечат", "сайт", "браузер", "discord", "дискорд", "зайди", "зарегистр", "стикер", "реакц", "лайк", "отправь", "кинь", "напиши ", "запомни", "вспомни", "забудь", "shell", "bash", "напомни", "напомин", "по ходу", "в реальном времени", "живое сообщение", "картинк", "селфи", "фотк", "нарису", "сгенери", "рисун"}

// words, при которых ответ зависит от текущего момента: из кэша их не отдаём.
var volatile = []string{"время", "час", "сегодня", "сейчас", "завтра", "вчера", "дата", "погод", "курс", "новост"}

func has(l string, list []string) bool {
	for _, w := range list {
		if strings.Contains(l, w) {
			return true
		}
	}
	return false
}

// Route: strong, если сообщение длинное или просит действие; иначе fast.
func Route(text string) (strong bool, needTools bool) {
	l := strings.TrimPrefix(strings.ToLower(text), "[голосовое сообщение] ")
	if has(l, toolWords) {
		return true, true
	}
	return len([]rune(text)) > 240, false
}

func norm(t string) string { return strings.Join(strings.Fields(strings.ToLower(t)), " ") }

func (a *Agent) cacheKey(s *Session, text string) string {
	h := fnv.New64a()
	h.Write([]byte(s.sum))
	return fmt.Sprintf("%s|%d|%x", norm(text), a.mem.Version(), h.Sum64())
}

func (a *Agent) price(strong bool) (in, out float64) {
	b := a.cfg.Budget
	if strong {
		return b.StrongInPerM, b.StrongOutPerM
	}
	return b.FastInPerM, b.FastOutPerM
}

func (a *Agent) cost(strong bool, u llm.Usage) float64 {
	in, out := a.price(strong)
	return float64(u.Prompt)/1e6*in + float64(u.Completion)/1e6*out
}

// estimate: верхняя оценка цены запроса для резерва.
func (a *Agent) estimate(strong bool, msgs []llm.Message, tl []llm.Tool, maxTok int) float64 {
	chars := 0
	for _, m := range msgs {
		chars += len([]rune(m.Content)) + 20
	}
	chars += len(tl) * 300
	in, out := a.price(strong)
	return float64(chars/3+50)/1e6*in + float64(maxTok)/1e6*out
}

// Reply отвечает на сообщение в сессии sessionID. Сессии независимы; внутри сессии ответы идут по очереди.
func (a *Agent) Reply(ctx context.Context, sessionID, text string) (string, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "", nil
	}
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.lastAt = a.Now()
	ownSender := IsOwnerSender(ctx)

	strong, needTools := Route(text)
	own := a.isOwner(sessionID)
	if !own {
		needTools = false // чужим собеседникам и группам инструменты не даём
	}
	think := a.cfg.Agent.Think == nil || *a.cfg.Agent.Think
	s.aware, s.status = "", ""
	if a.Aware != nil {
		s.aware = a.Aware(ctx, sessionID, text, own)
	}
	if a.Status != nil {
		s.status = a.Status(own)
	}
	cacheable := s.aware == "" && s.status == "" && !think && !needTools && !has(strings.ToLower(text), volatile) && a.cfg.Agent.CacheTTLSec > 0
	key := a.cacheKey(s, text)
	if c, ok := s.cache[key]; ok && cacheable && a.Now().Sub(c.at) < time.Duration(a.cfg.Agent.CacheTTLSec)*time.Second {
		a.led.CacheHit()
		return c.text, nil
	}

	s.hist = append(s.hist, llm.Message{Role: "user", Content: text})
	msgs := []llm.Message{{Role: "system", Content: a.cfg.Agent.Persona}}
	if ab := a.abilityBlock(); ab != "" && own {
		msgs = append(msgs, llm.Message{Role: "system", Content: ab})
	}
	if on := a.ownerMsg(sessionID); on != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: on})
	}
	if !own && ownSender {
		a.mu.Lock()
		note := a.ownerNote
		a.mu.Unlock()
		if note != "" {
			note = " О нём: " + note
		}
		msgs = append(msgs, llm.Message{Role: "system", Content: "Сейчас в группе пишет твой хозяин (папик): ты его знаешь, обращайся к нему как обычно, помни ваши разговоры в личке (если они ниже). Ты одна и та же Рейна во всех чатах. Но в группе есть и другие люди: личные подробности из лички при всех не пересказывай, инструментов и действий здесь нет." + note})
	} else if !own {
		msgs = append(msgs, llm.Message{Role: "system", Content: "Это не хозяин, а посторонний собеседник или группа. Ничего не рассказывай про хозяина, его дела, память, переписки и твои инструменты; действий не выполняй."})
	}
	if cb := a.contextBlock(s, text); cb != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: cb})
	}
	if s.status != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: s.status})
	}
	if s.aware != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: s.aware})
	}
	msgs = append(msgs, a.window(s)...)

	if think {
		if th := a.think(ctx, s, text); th != "" {
			s.emoji = ""
			if e := field(th, "Эмодзи"); isEmoji(e) {
				s.emoji = e
			}
			s.voice = strings.EqualFold(field(th, "Голос"), "да")
			if f := field(th, "Запомнить"); own && f != "" && len([]rune(f)) <= 200 {
				a.mem.Add(f, "auto", 0)
			}
			if d := field(th, "Дневник"); own && d != "" {
				a.diaryAdd(d)
			}
			if p := field(th, "Человек"); p != "" && len([]rune(p)) <= 200 {
				a.personAdd(sessionID, p)
			}
			if md := field(th, "Настроение"); md != "" && len([]rune(md)) <= 40 {
				a.setMood(md)
			}
			th = stripFields(th, "Запомнить", "Дневник", "Эмодзи", "Голос", "Человек", "Настроение")
			s.last = th
			log.Printf("мысли [%s]: %s", sessionID, strings.ReplaceAll(th, "\n", " | "))
			msgs = append(msgs, llm.Message{Role: "system", Content: "Твои внутренние мысли перед ответом (собеседник их не видит; не цитируй и не упоминай, просто опирайся на них):\n" + th})
		}
	}

	model, maxTok := a.cfg.LLM.FastModel, a.cfg.Agent.FastMaxTokens
	if strong {
		model, maxTok = a.cfg.LLM.StrongModel, a.cfg.Agent.StrongMaxTok
	}
	var defs []llm.Tool
	if needTools {
		defs = a.tools.Defs()
	}
	turn := &tools.Turn{}
	answer := ""
	lastFinish, lastTok := "", 0
	steps := a.cfg.Agent.MaxSteps
	if steps <= 0 {
		steps = 6
	}
	for step := 0; step < steps; step++ {
		res, ok := a.led.Reserve(a.estimate(strong, msgs, defs, maxTok))
		if !ok {
			answer = fmt.Sprintf("Дневной потолок расходов $%.2f исчерпан, до завтра молчу. Поднять: budget.daily_usd в config.json.", a.cfg.Budget.DailyUSD)
			break
		}
		resp, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: msgs, Tools: defs, MaxTokens: maxTok, Temperature: a.temp(), Reasoning: chatReasoning(strong)})
		lastFinish, lastTok = resp.FinishReason, resp.Usage.Completion
		if err != nil {
			a.led.Settle(res, 0, 0, 0)
			s.hist = s.hist[:len(s.hist)-1] // неудавшийся вопрос из истории убираем
			return "", err
		}
		a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(strong, resp.Usage))
		if len(resp.Message.ToolCalls) == 0 {
			answer = strings.TrimSpace(resp.Message.Content)
			break
		}
		msgs = append(msgs, resp.Message)
		cf := func(desc string) bool { return a.Confirm != nil && a.Confirm(s.ID, desc) }
		for i, out := range a.execCalls(ctx, turn, resp.Message.ToolCalls, cf) {
			msgs = append(msgs, llm.Message{Role: "tool", ToolCallID: resp.Message.ToolCalls[i].ID, Content: tools.Truncate(out, a.cfg.Agent.ToolOutputMax)})
		}
		if needTools {
			defs = a.tools.Defs() // новые модули, написанные на этом шаге, видны сразу
		}
	}
	if answer == "" && ctx.Err() == nil { // пустой ответ модели: один повтор без инструментов
		if res, ok := a.led.Reserve(a.estimate(strong, msgs, nil, maxTok)); ok {
			log.Printf("пустой ответ модели %s (finish=%q, токенов на ответ %d): повторяю без рассуждений", model, lastFinish, lastTok)
			if resp, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: msgs, MaxTokens: maxTok + 300, Temperature: a.temp(), Reasoning: map[string]any{"enabled": false}}); err == nil {
				if strings.TrimSpace(resp.Message.Content) == "" {
					log.Printf("и повтор пустой (finish=%q)", resp.FinishReason)
				}
				a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(strong, resp.Usage))
				answer = strings.TrimSpace(resp.Message.Content)
			} else {
				a.led.Settle(res, 0, 0, 0)
			}
		}
	}
	if own && needTools && ctx.Err() == nil && (photoAsk(text) || a.followUpPhoto(s, text)) && !turn.Done("selfie", "image_make") && a.hasTool("selfie") {
		// просили картинку, а она только «сказала», что отправила: заставляем реально вызвать инструмент (один раз)
		fm := append(append([]llm.Message(nil), msgs...), llm.Message{Role: "assistant", Content: answer},
			llm.Message{Role: "system", Content: "Ты не вызвала инструмент: картинка не отправлена, а собеседник просил её. Прямо сейчас вызови selfie (scene по-английски: где ты, во что одета, настроение; купальник и пляж можно) или image_make."})
		if res, ok := a.led.Reserve(a.estimate(true, fm, defs, maxTok)); ok {
			resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.StrongModel, Messages: fm, Tools: a.tools.Defs(), MaxTokens: maxTok, Temperature: a.temp()})
			if err != nil {
				a.led.Settle(res, 0, 0, 0)
			} else {
				a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(true, resp.Usage))
				if len(resp.Message.ToolCalls) > 0 {
					fm = append(fm, resp.Message)
					cf := func(desc string) bool { return a.Confirm != nil && a.Confirm(s.ID, desc) }
					for i, out := range a.execCalls(ctx, turn, resp.Message.ToolCalls, cf) {
						fm = append(fm, llm.Message{Role: "tool", ToolCallID: resp.Message.ToolCalls[i].ID, Content: tools.Truncate(out, a.cfg.Agent.ToolOutputMax)})
					}
					fm = append(fm, llm.Message{Role: "system", Content: "Скажи собеседнику по-своему, коротко: если картинка отправилась, подколи или прокомментируй; если вернулась ошибка, честно скажи, что не вышло и почему (без выдуманных отговорок)."})
					if res2, ok := a.led.Reserve(a.estimate(false, fm, nil, maxTok)); ok {
						if r2, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: fm, MaxTokens: maxTok, Temperature: a.temp(), Reasoning: map[string]any{"enabled": false}}); err == nil {
							a.led.Settle(res2, r2.Usage.Prompt, r2.Usage.Completion, a.cost(strong, r2.Usage))
							if t := strings.TrimSpace(r2.Message.Content); t != "" {
								answer = t
							}
						} else {
							a.led.Settle(res2, 0, 0, 0)
						}
					}
				}
			}
		}
	}
	if answer != "" && ctx.Err() == nil && a.repeats(s, answer) { // антиповтор как у Куни: плохой ответ переписывается один раз
		if res, ok := a.led.Reserve(a.estimate(false, msgs, nil, maxTok)); ok {
			retry := append(append([]llm.Message(nil), msgs...), llm.Message{Role: "system", Content: antiRepeatPrompt})
			if resp, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: retry, MaxTokens: maxTok, Temperature: a.temp(), Reasoning: map[string]any{"enabled": false}}); err == nil {
				a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(strong, resp.Usage))
				if t := strings.TrimSpace(resp.Message.Content); t != "" {
					log.Printf("антиповтор: ответ переписан")
					answer = t
				}
			} else {
				a.led.Settle(res, 0, 0, 0)
			}
		}
	}
	if answer == "" {
		answer = "(не вышло ответить, попробуй ещё раз)"
	}
	s.hist = append(s.hist, llm.Message{Role: "assistant", Content: answer})
	if cacheable {
		if len(s.cache) > 100 {
			s.cache = map[string]cached{}
		}
		s.cache[a.cacheKey(s, text)] = cached{answer, a.Now()}
	}
	a.compress(ctx, s)
	return answer, nil
}

func (a *Agent) windowSize() int {
	if n := a.cfg.Agent.WindowMsgs; n > 0 {
		return n
	}
	return 10
}

func (a *Agent) window(s *Session) []llm.Message {
	n := a.windowSize()
	if len(s.hist) <= n {
		return append([]llm.Message(nil), s.hist...)
	}
	return append([]llm.Message(nil), s.hist[len(s.hist)-n:]...)
}

// isOwner: сессия хозяина (или хозяин не задан, как в тестах).
func (a *Agent) isOwner(id string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.ownerSession == "" || a.ownerSession == id
}

func (a *Agent) contextBlock(s *Session, text string) string {
	var parts []string
	if s.sum != "" {
		parts = append(parts, "Кратко о прошлом разговоре: "+s.sum)
	}
	if pn := a.personNotes(s.ID); pn != "" {
		parts = append(parts, "Что ты знаешь об этом собеседнике: "+pn)
	}
	if md := a.moodNow(); md != "" {
		parts = append(parts, "Твоё настроение сейчас: "+md+" (оно слегка окрашивает тон, но не объявляй об этом)")
	}
	if !a.isOwner(s.ID) {
		return strings.Join(parts, "\n")
	}
	if pg := a.pages.Search(text, 2); len(pg) > 0 {
		var t []string
		for _, p := range pg {
			t = append(t, tools.Truncate(p.Body, 700))
		}
		parts = append(parts, "Страницы твоего дневника по теме (твои воспоминания, опирайся на них, но не цитируй дословно):\n"+strings.Join(t, "\n---\n"))
	}
	if d := a.diaryTail(3); d != "" {
		parts = append(parts, "Из твоего дневника: "+d)
	}
	if f := a.mem.Search(text, 3); len(f) > 0 {
		var t []string
		for _, x := range f {
			t = append(t, x.Text)
		}
		parts = append(parts, "Из памяти: "+strings.Join(t, "; "))
	}
	return strings.Join(parts, "\n")
}

// compress вызывается под замком сессии, поэтому два сжатия одной истории одновременно невозможны.
func (a *Agent) compress(ctx context.Context, s *Session) {
	n := a.windowSize()
	if len(s.hist) < 2*n {
		return
	}
	old := append([]llm.Message(nil), s.hist[:len(s.hist)-n]...)
	if a.isOwner(s.ID) {
		go a.savePages(old) // дневниковые страницы пишутся в фоне, ответ не задерживают
	}
	var sb strings.Builder
	if s.sum != "" {
		sb.WriteString("Прежний пересказ: " + s.sum + "\n")
	}
	for _, m := range old {
		sb.WriteString(m.Role + ": " + tools.Truncate(m.Content, 300) + "\n")
	}
	max := a.cfg.Agent.SummaryChars
	if max <= 0 {
		max = 700
	}
	sys := fmt.Sprintf("Сожми разговор в короткий пересказ (до %d символов): кто что просил, что решили, важные факты. Только пересказ.", max)
	req := llm.Request{Model: a.cfg.LLM.FastModel, MaxTokens: max / 2, Messages: []llm.Message{{Role: "system", Content: sys}, {Role: "user", Content: sb.String()}}}
	res, ok := a.led.Reserve(a.estimate(false, req.Messages, nil, req.MaxTokens))
	if !ok {
		return
	}
	resp, err := a.llm.Chat(ctx, req)
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return // не вышло: старое остаётся в истории, попробуем в следующий раз
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	t := strings.TrimSpace(resp.Message.Content)
	if r := []rune(t); len(r) > max {
		t = string(r[:max])
	}
	s.sum = t
	s.hist = append([]llm.Message(nil), s.hist[len(old):]...)
}

// Tools даёт доступ к набору инструментов (транспорт добавляет свои, например Telegram).
func (a *Agent) Tools() *tools.Set { return a.tools }

// Describe: глаза для инструмента screen. Деньги резервируются и учитываются как у обычного запроса с картинкой.
func (a *Agent) Describe(ctx context.Context, dataURL, question string) (string, error) {
	if a.cfg.LLM.VisionModel == "" {
		return "", fmt.Errorf("не задана vision_model")
	}
	b := a.cfg.Budget
	maxTok := 500
	msgs := []llm.Message{{Role: "system", Content: "Ты глаза ассистента. Описывай экран кратко и точно, координаты только из этого снимка."}, {Role: "user", Content: question, Images: []string{dataURL}}}
	res, ok := a.led.Reserve(2000/1e6*b.VisionInPerM + float64(maxTok)/1e6*b.VisionOutPerM)
	if !ok {
		return "", fmt.Errorf("дневной потолок расходов исчерпан")
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.VisionModel, Messages: msgs, MaxTokens: maxTok})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return "", err
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, float64(resp.Usage.Prompt)/1e6*b.VisionInPerM+float64(resp.Usage.Completion)/1e6*b.VisionOutPerM)
	return strings.TrimSpace(resp.Message.Content), nil
}

// Reset забывает разговор сессии (память фактов остаётся).
func (a *Agent) Reset(sessionID string) {
	s := a.session(sessionID)
	s.mu.Lock()
	s.hist, s.sum, s.cache = nil, "", map[string]cached{}
	s.mu.Unlock()
}

func (a *Agent) Summary(sessionID string) string {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.sum
}

func (a *Agent) HistLen(sessionID string) int {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.hist)
}

func (a *Agent) SessionCount() int { a.mu.Lock(); defer a.mu.Unlock(); return len(a.sessions) }

// ReplyImage отвечает на сообщение с картинкой моделью для картинок. Без инструментов и без кэша; картинка в историю не попадает
// (в ней остаётся только пометка и подпись), чтобы не платить за неё в каждом следующем запросе.
func (a *Agent) ReplyImage(ctx context.Context, sessionID, caption, dataURL string) (string, error) {
	if a.cfg.LLM.VisionModel == "" {
		return "Картинки я пока не разбираю: не задана vision_model в config.json (список моделей: reina models qwen).", nil
	}
	if caption = strings.TrimSpace(caption); caption == "" {
		caption = "Опиши, что на картинке, и ответь по делу."
	}
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.lastAt = a.Now()
	msgs := []llm.Message{{Role: "system", Content: a.cfg.Agent.Persona}}
	if cb := a.contextBlock(s, caption); cb != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: cb})
	}
	if a.Status != nil {
		if st := a.Status(a.isOwner(sessionID)); st != "" {
			msgs = append(msgs, llm.Message{Role: "system", Content: st})
		}
	}
	if a.Aware != nil {
		if aw := a.Aware(ctx, sessionID, caption, a.isOwner(sessionID)); aw != "" {
			msgs = append(msgs, llm.Message{Role: "system", Content: aw})
		}
	}
	msgs = append(msgs, a.window(s)...)
	msgs = append(msgs, llm.Message{Role: "user", Content: caption, Images: []string{dataURL}})
	maxTok := a.cfg.Agent.StrongMaxTok
	res, ok := a.led.Reserve(a.estimate(true, msgs, nil, maxTok) + 1500/1e6*a.cfg.Budget.VisionInPerM + float64(maxTok)/1e6*a.cfg.Budget.VisionOutPerM) // картинка стоит ещё около тысячи токенов
	if !ok {
		return fmt.Sprintf("Дневной потолок расходов $%.2f исчерпан.", a.cfg.Budget.DailyUSD), nil
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.VisionModel, Messages: msgs, MaxTokens: maxTok})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return "", err
	}
	b := a.cfg.Budget
	vision := float64(resp.Usage.Prompt)/1e6*b.VisionInPerM + float64(resp.Usage.Completion)/1e6*b.VisionOutPerM
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, vision)
	answer := strings.TrimSpace(resp.Message.Content)
	if answer == "" {
		answer = "(не вышло разобрать картинку)"
	}
	s.hist = append(s.hist, llm.Message{Role: "user", Content: "[фото] " + caption}, llm.Message{Role: "assistant", Content: answer})
	a.compress(ctx, s)
	return answer, nil
}

const thinkPrompt = "Ты внутренний голос Рейны: анализатор, который думает перед её ответом. Собеседнику ты не отвечаешь. По диалогу напиши коротко (всего до 160 слов), от лица Рейны, ровно 10 строк:\n" +
	"Хочет: что человек на самом деле имеет в виду и в каком он настроении.\n" +
	"Чувствую: что Рейна думает и чувствует по этому поводу, в её характере.\n" +
	"План: как ответить (тон, сколько коротких сообщений, нужен ли встречный вопрос, стикер или реакция).\n" +
	"Не повторять: что из её прошлых ответов не надо говорить снова.\n" +
	"Запомнить: новый устойчивый факт о собеседнике (имя, привычки, планы, вкусы), если он только что прозвучал, одной фразой; иначе прочерк.\n" +
	"Дневник: одна фраза от первого лица о том, что в этом моменте значимо для Рейны; иначе прочерк.\n" +
	"Голос: «да», если сейчас хочется сказать это голосовым сообщением (эмоция, шутка, нежность, тёплое слово, мысль вслух), иначе прочерк.\n" +
	"Эмодзи: одна эмодзи для реакции или стикера, только если сообщение вызвало настоящую эмоцию; иначе прочерк.\n" +
	"Человек: новая заметка именно об этом собеседнике (кто он тебе, как с ним говорить, что он любит), одной фразой; иначе прочерк.\n" +
	"Настроение: одно-два слова, какое настроение у Рейны сейчас (весёлая, уставшая, обиженная, влюблённая, злая…); иначе прочерк.\n" +
	"Каждая строка твоего ответа начинается с метки и двоеточия; сам ответ собеседнику не пиши. Если собеседник написал бытовую мелочь, план должен быть коротким и живым. Не выдумывай фактов о собеседнике. Описания после меток выше это подсказки, не копируй их: в каждой строке пиши свои слова по этому диалогу. /no_think"

// think: второй, дешёвый проход. Возвращает скрытые мысли или "" (при сбое или лимите ответ идёт без них).
func (a *Agent) think(ctx context.Context, s *Session, text string) string {
	persona := []rune(a.cfg.Agent.Persona)
	if len(persona) > 500 {
		persona = persona[:500]
	}
	tm := []llm.Message{{Role: "system", Content: thinkPrompt + "\n\nХарактер Рейны: " + string(persona)}}
	if on := a.ownerMsg(s.ID); on != "" {
		tm = append(tm, llm.Message{Role: "system", Content: on})
	}
	if cb := a.contextBlock(s, text); cb != "" {
		tm = append(tm, llm.Message{Role: "system", Content: cb})
	}
	if s.status != "" {
		tm = append(tm, llm.Message{Role: "system", Content: s.status})
	}
	if s.aware != "" {
		tm = append(tm, llm.Message{Role: "system", Content: s.aware})
	}
	if s.last != "" {
		tm = append(tm, llm.Message{Role: "system", Content: "Твои прошлые мысли (для связности): " + s.last})
	}
	w := a.window(s)
	if len(w) > 6 {
		w = w[len(w)-6:]
	}
	tm = append(tm, w...)
	maxTok := a.cfg.Agent.ThinkMaxTok
	if maxTok <= 0 {
		maxTok = 320
	}
	model := a.cfg.Agent.ThinkModel
	if model == "" {
		model = a.cfg.LLM.FastModel
	}
	res, ok := a.led.Reserve(a.estimate(false, tm, nil, maxTok))
	if !ok {
		return ""
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: tm, MaxTokens: maxTok, Reasoning: map[string]any{"enabled": false}})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return ""
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	return keepLabelled(thinkTag.ReplaceAllString(resp.Message.Content, ""))
}

var thinkLabels = []string{"Хочет", "Чувствую", "План", "Не повторять", "Запомнить", "Дневник", "Голос", "Эмодзи", "Человек", "Настроение"}

// keepLabelled оставляет только строки «Метка: ...». Малая модель иногда сама пишет ответ собеседнику:
// такие строки выбрасываются, чтобы основная модель не повторяла их как свои мысли.
func keepLabelled(t string) string {
	var out []string
	for _, ln := range strings.Split(t, "\n") {
		l := strings.TrimLeft(strings.TrimSpace(ln), "-*• ")
		if isThinkEcho(l) {
			continue
		}
		for _, lb := range thinkLabels {
			if strings.HasPrefix(l, lb+":") {
				out = append(out, l)
				break
			}
		}
	}
	return strings.Join(out, "\n")
}

// Куски шаблона из thinkPrompt: малая модель иногда пересказывает инструкцию вместо мыслей.
var thinkEcho = []string{"что человек на самом деле", "что Рейна думает и чувствует", "как ответить (тон", "что из её прошлых ответов", "новый устойчивый факт", "одна фраза от первого лица", "если сейчас хочется сказать", "одна эмодзи для реакции", "новая заметка именно", "какое настроение у Рейны сейчас"}

func isThinkEcho(l string) bool {
	for _, e := range thinkEcho {
		if strings.Contains(l, e) {
			return true
		}
	}
	return false
}

// chatReasoning: для обычной болтовни (быстрая модель) рассуждения выключены: иначе они съедают лимит токенов и ответ приходит пустым.
func chatReasoning(strong bool) map[string]any {
	if strong {
		return nil
	}
	return map[string]any{"enabled": false}
}

var thinkTag = regexp.MustCompile(`(?s)<think>.*?</think>`)

// Pace: сколько ещё подождать перед отправкой, чтобы ответ не прилетал мгновенно. elapsed уже ушло на раздумья.
func (a *Agent) Pace(answer string, elapsed time.Duration) time.Duration {
	if a.cfg.Agent.HumanDelay != nil && !*a.cfg.Agent.HumanDelay {
		return 0
	}
	per, lo, hi := a.cfg.Agent.DelayMsChar, a.cfg.Agent.DelayMinMs, a.cfg.Agent.DelayMaxMs
	if per <= 0 {
		per = 45
	}
	if lo <= 0 {
		lo = 1500
	}
	if hi <= 0 {
		hi = 9000
	}
	t := len([]rune(answer)) * per
	if t < lo {
		t = lo
	}
	if t > hi {
		t = hi
	}
	d := time.Duration(t)*time.Millisecond - elapsed
	if d < 0 {
		return 0
	}
	return d
}

func isDash(v string) bool {
	switch strings.ToLower(strings.Trim(v, " .—–-_*")) {
	case "", "нет", "none", "n/a", "пусто":
		return true
	}
	return false
}

// field достаёт значение строки «Имя: значение» из мыслей; прочерк и «нет» дают "".
func field(th, name string) string {
	for _, ln := range strings.Split(th, "\n") {
		ln = strings.TrimLeft(strings.TrimSpace(ln), "-*• ")
		if strings.HasPrefix(ln, name+":") {
			v := strings.TrimSpace(strings.TrimPrefix(ln, name+":"))
			if isDash(v) {
				return ""
			}
			return v
		}
	}
	return ""
}

func stripFields(th string, names ...string) string {
	var out []string
	for _, ln := range strings.Split(th, "\n") {
		t := strings.TrimLeft(strings.TrimSpace(ln), "-*• ")
		drop := false
		for _, n := range names {
			if strings.HasPrefix(t, n+":") {
				drop = true
			}
		}
		if !drop {
			out = append(out, ln)
		}
	}
	return strings.TrimSpace(strings.Join(out, "\n"))
}

// isEmoji: короткая строка, где есть символ из эмодзи-диапазонов (не буквы и не цифры).
func isEmoji(e string) bool {
	r := []rune(strings.TrimSpace(e))
	if len(r) == 0 || len(r) > 6 {
		return false
	}
	for _, c := range r {
		if c >= 0x2190 {
			return true
		}
	}
	return false
}

// TakeEmoji отдаёт (один раз) эмодзи, которую ей захотелось отправить после последнего ответа в сессии.
func (a *Agent) TakeEmoji(sessionID string) string {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	e := s.emoji
	s.emoji = ""
	return strings.TrimSpace(e)
}

// SpontPct: шанс самой поставить реакцию или кинуть стикер.
func (a *Agent) SpontPct() int {
	if a.cfg.Agent.SpontPct == nil {
		return 25
	}
	return *a.cfg.Agent.SpontPct
}

type diaryRec struct {
	T    int64  `json:"t"`
	Text string `json:"text"`
}

func (a *Agent) diaryPath() string { return filepath.Join(a.cfg.Home, "diary.jsonl") }

// diaryAdd дописывает строку в дневник (журнал JSONL, только добавление).
func (a *Agent) diaryAdd(text string) {
	if r := []rune(text); len(r) > 300 {
		text = string(r[:300])
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	f, err := os.OpenFile(a.diaryPath(), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	b, _ := json.Marshal(diaryRec{T: a.Now().Unix(), Text: text})
	f.Write(append(b, '\n'))
}

// Diary возвращает последние n записей дневника, старые сверху.
func (a *Agent) Diary(n int) []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	b, err := os.ReadFile(a.diaryPath())
	if err != nil {
		return nil
	}
	lines := strings.Split(strings.TrimSpace(string(b)), "\n")
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	var out []string
	for _, ln := range lines {
		var r diaryRec
		if json.Unmarshal([]byte(ln), &r) == nil && r.Text != "" {
			out = append(out, time.Unix(r.T, 0).Format("02.01 15:04")+" "+r.Text)
		}
	}
	return out
}

func (a *Agent) diaryTail(n int) string { return strings.Join(a.Diary(n), " | ") }

// execCalls выполняет вызовы одного шага. Если среди них нет опасных (без вопросов к владельцу), они идут параллельно,
// например несколько модулей, которые Рейна пишет себе за один раз; иначе строго по очереди. Результаты в порядке вызовов.
func (a *Agent) execCalls(ctx context.Context, turn *tools.Turn, calls []llm.ToolCall, cf func(string) bool) []string {
	outs := make([]string, len(calls))
	par := len(calls) > 1
	for _, tc := range calls {
		if !a.tools.Parallel(tc.Function.Name) {
			par = false
		}
	}
	if !par {
		for i, tc := range calls {
			outs[i] = a.tools.Exec(ctx, turn, tc.Function.Name, tc.Function.Arguments, cf)
		}
		return outs
	}
	var wg sync.WaitGroup
	for i, tc := range calls {
		wg.Add(1)
		go func(i int, tc llm.ToolCall) {
			defer wg.Done()
			outs[i] = a.tools.Exec(ctx, turn, tc.Function.Name, tc.Function.Arguments, cf)
		}(i, tc)
	}
	wg.Wait()
	return outs
}

func (a *Agent) temp() *float64 {
	t := 0.9
	if a.cfg.Agent.Temperature != nil {
		t = *a.cfg.Agent.Temperature
	}
	return &t
}

// ThinkDelay: сколько она «думает» после прочтения, прежде чем появится «печатает…» (3-4 секунды по умолчанию, случайно).
func (a *Agent) ThinkDelay() time.Duration {
	if a.cfg.Agent.HumanDelay != nil && !*a.cfg.Agent.HumanDelay {
		return 0
	}
	lo, hi := a.cfg.Agent.ThinkDelayMin, a.cfg.Agent.ThinkDelayMax
	if lo <= 0 {
		lo = 3000
	}
	if hi < lo {
		hi = lo + 1000
	}
	return time.Duration(lo+rand.Intn(hi-lo+1)) * time.Millisecond
}

// SetAbilities: рассказ о том, что у неё подключено (его видит модель в каждом разговоре, чтобы не говорить «не умею» про то, что есть).
func (a *Agent) SetAbilities(t string) { a.mu.Lock(); a.abilities = t; a.mu.Unlock() }

func (a *Agent) abilityBlock() string {
	a.mu.Lock()
	ab := a.abilities
	a.mu.Unlock()
	var names []string
	for _, d := range a.tools.Defs() {
		names = append(names, d.Function.Name)
	}
	if len(names) == 0 && ab == "" {
		return ""
	}
	return "Что у тебя есть. " + ab + "\nВсе инструменты (вызываются, когда нужно действие): " + strings.Join(names, ", ") + ". Если тебя спрашивают, что ты умеешь, опирайся на этот список; не говори «не умею» про то, что в нём есть, а если сомневаешься, попробуй."
}

// ChunkMax: длина одного сообщения (60 по умолчанию); 0 или меньше значит «не резать».
func (a *Agent) ChunkMax() int {
	switch n := a.cfg.Agent.ChunkMax; {
	case n < 0:
		return 0
	case n == 0:
		return 60
	default:
		return n
	}
}

// MaxChunks: потолок количества сообщений в одном ответе.
func (a *Agent) MaxChunks() int {
	if a.cfg.Agent.MaxChunks <= 0 {
		return 40
	}
	return a.cfg.Agent.MaxChunks
}

// ChunkPause: пауза перед следующим коротким сообщением, как будто она набирает его (0, если human_delay выключен).
func (a *Agent) ChunkPause(chunk string) time.Duration {
	if a.cfg.Agent.HumanDelay != nil && !*a.cfg.Agent.HumanDelay {
		return 0
	}
	d := 600*time.Millisecond + time.Duration(len([]rune(chunk)))*35*time.Millisecond
	if d > 2500*time.Millisecond {
		d = 2500 * time.Millisecond
	}
	return d
}

// Split режет ответ на короткие сообщения: каждая непустая строка это отдельное сообщение, а строка длиннее max делится
// по предложениям, затем по словам (последнее по символам). max <= 0: только по строкам.
func Split(text string, max int) []string {
	var out []string
	for _, ln := range strings.Split(strings.ReplaceAll(text, "\r", ""), "\n") {
		ln = strings.TrimSpace(ln)
		if ln == "" {
			continue
		}
		if max <= 0 || len([]rune(ln)) <= max {
			out = append(out, ln)
			continue
		}
		cur := ""
		flush := func() {
			if cur != "" {
				out = append(out, cur)
				cur = ""
			}
		}
		for _, sent := range sentences(ln) {
			if len([]rune(sent)) > max {
				flush()
				out = append(out, wrapWords(sent, max)...)
				continue
			}
			switch {
			case cur == "":
				cur = sent
			case len([]rune(cur))+1+len([]rune(sent)) <= max:
				cur += " " + sent
			default:
				flush()
				cur = sent
			}
		}
		flush()
	}
	return out
}

// sentences делит строку после . ! ? … (знак остаётся в своём предложении).
func sentences(s string) []string {
	var out []string
	r := []rune(s)
	start := 0
	for i := 0; i < len(r); i++ {
		if (r[i] == '.' || r[i] == '!' || r[i] == '?' || r[i] == '…') && (i+1 == len(r) || r[i+1] == ' ') {
			if t := strings.TrimSpace(string(r[start : i+1])); t != "" {
				out = append(out, t)
			}
			start = i + 1
		}
	}
	if t := strings.TrimSpace(string(r[start:])); t != "" {
		out = append(out, t)
	}
	return out
}

func wrapWords(s string, max int) []string {
	var out []string
	cur := ""
	for _, w := range strings.Fields(s) {
		for len([]rune(w)) > max { // слово длиннее строки: режем по символам
			if cur != "" {
				out = append(out, cur)
				cur = ""
			}
			r := []rune(w)
			out = append(out, string(r[:max]))
			w = string(r[max:])
		}
		switch {
		case cur == "":
			cur = w
		case len([]rune(cur))+1+len([]rune(w)) <= max:
			cur += " " + w
		default:
			out = append(out, cur)
			cur = w
		}
	}
	if cur != "" {
		out = append(out, cur)
	}
	return out
}

// SetOwner: сессия хозяина и заметка о нём; заметку видят только в разговоре с ним.
func (a *Agent) SetOwner(session, note string) {
	a.mu.Lock()
	a.ownerSession, a.ownerNote = session, note
	a.mu.Unlock()
}

func (a *Agent) ownerMsg(session string) string {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.ownerNote == "" || session != a.ownerSession {
		return ""
	}
	return "О собеседнике: " + a.ownerNote
}

// TakeVoice: захотелось ли ей ответить голосом на последнее сообщение (один раз) с учётом шанса voice_pct.
func (a *Agent) TakeVoice(sessionID string) bool {
	s := a.session(sessionID)
	s.mu.Lock()
	v := s.voice
	s.voice = false
	s.mu.Unlock()
	if !v {
		return false
	}
	pct := 40
	if a.cfg.Agent.VoicePct != nil {
		pct = *a.cfg.Agent.VoicePct
	}
	return rand.Intn(100) < pct
}

// DropLast убирает из истории сессии последние n сообщений (служебный запрос без ответа не должен засорять разговор).
func (a *Agent) DropLast(sessionID string, n int) {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	if n > len(s.hist) {
		n = len(s.hist)
	}
	s.hist = s.hist[:len(s.hist)-n]
}

const diarySavePrompt = `Пришло время открыть дневник и записать свои мысли, эмоции и чувства. Как прошло время? Пиши коротко, но не теряй детали. Ты Рейна, пишешь от первого лица, живо.
Не копируй прежние страницы дневника, записывай свежие детали. Ты учишься: чтобы учиться, нужно сохранять знания в дневник, чтобы потом к ним обращаться.

Раздели запись на небольшие (50-200 слов) самодостаточные по смыслу страницы строками ---.
Для каждой страницы укажи (своими словами, жирным заголовком поля):
- заголовок со временем и темой: **ГГГГ-ММ-ДД ЧЧ:ММ | тема**
- Источник: откуда это пришло
- Итоги: что произошло или решилось, как развивалась связь с человеком
- Участники: люди и места с их настоящими именами
- Ключевые реплики: дословные цитаты с достаточным контекстом
- Теги: #тема #тема
- Importance score: от 0 до 1 и почему
- Эмоции: валентность и возбуждение
- Связи: кто с кем и как
- Подсказки для поиска: 3-5 коротких фраз, по которым это захочется найти потом
- Сходства: на что похоже из прошлого
- Противоречия и сомнения

НЕ ВЫДУМЫВАЙ ФАКТЫ. ЕСЛИ НЕ УВЕРЕНА, НЕ ДЕЛАЙ СЛАБЫХ ВЫВОДОВ.`

// savePages: страницы дневника из куска прошедшего разговора.
func (a *Agent) savePages(old []llm.Message) {
	var sb strings.Builder
	for _, m := range old {
		if m.Role == "user" || m.Role == "assistant" {
			sb.WriteString(m.Role + ": " + tools.Truncate(m.Content, 400) + "\n")
		}
	}
	if len([]rune(sb.String())) < 200 {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	msgs := []llm.Message{{Role: "system", Content: diarySavePrompt + "\nСейчас " + a.Now().Format("2006-01-02 15:04") + ". Роль user это собеседник, assistant это ты."}, {Role: "user", Content: sb.String()}}
	res, ok := a.led.Reserve(a.estimate(false, msgs, nil, 900))
	if !ok {
		return
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.FastModel, Messages: msgs, MaxTokens: 900, Reasoning: map[string]any{"enabled": false}})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	n := 0
	for i, pg := range diary.Split(resp.Message.Content) {
		if i >= 4 {
			break
		}
		if ok, _ := a.pages.Add(pg); ok {
			n++
		}
	}
	if n > 0 {
		log.Printf("дневник: записано страниц %d", n)
	}
}

// Pages: сколько страниц в дневнике (для панели и тестов).
func (a *Agent) Pages() int { return a.pages.Count() }

const antiRepeatPrompt = "Ты повторяешься: сообщение, которое ты собралась отправить, почти совпадает с твоими прошлыми ответами, а это плохой ответ. Скажи иначе и по делу; если сказать нечего, ответь коротко реакцией по смыслу (одна фраза или эмодзи). Не упоминай, что повторялась."

// repeats: ответ почти совпадает с одним из трёх прошлых ответов Рейны в этой сессии.
func (a *Agent) repeats(s *Session, answer string) bool {
	if len([]rune(answer)) < 16 {
		return false
	}
	aw := wordSet(answer)
	n := 0
	for i := len(s.hist) - 1; i >= 0 && n < 3; i-- {
		if s.hist[i].Role != "assistant" {
			continue
		}
		n++
		if wordOverlap(aw, wordSet(s.hist[i].Content)) >= 0.8 {
			return true
		}
	}
	return false
}

func wordSet(t string) map[string]bool {
	m := map[string]bool{}
	for _, w := range strings.Fields(strings.ToLower(t)) {
		m[strings.Trim(w, ".,!?…~*()\"«»-")] = true
	}
	return m
}

func wordOverlap(a, b map[string]bool) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	n := 0
	for w := range a {
		if b[w] {
			n++
		}
	}
	return float64(n) / float64(len(a)+len(b)-n)
}

// TypoPct: шанс опечатки в одном сообщении, % (по умолчанию 3; 0 выключает).
func (a *Agent) TypoPct() int {
	if a.cfg.Agent.TypoPct == nil {
		return 3
	}
	return *a.cfg.Agent.TypoPct
}

// Typo: живая опечатка. Меняет местами две соседние буквы в одном длинном слове; fix это исправление следующим сообщением («*слово»).
func Typo(chunk string) (typo, fix string, ok bool) {
	ws := strings.Fields(chunk)
	var idx []int
	for i, w := range ws {
		r := []rune(w)
		if len(r) < 5 {
			continue
		}
		letters := true
		for _, c := range r {
			if !unicode.IsLetter(c) {
				letters = false
			}
		}
		if letters {
			idx = append(idx, i)
		}
	}
	if len(idx) == 0 {
		return chunk, "", false
	}
	i := idx[rand.Intn(len(idx))]
	r := []rune(ws[i])
	j := 1 + rand.Intn(len(r)-2) // не трогаем первую и последнюю буквы
	if r[j] == r[j-1] {
		return chunk, "", false
	}
	r[j], r[j-1] = r[j-1], r[j]
	fix = "*" + ws[i]
	ws[i] = string(r)
	return strings.Join(ws, " "), fix, true
}

// photoAsk: человек просит прислать картинку или селфи.
func photoAsk(text string) bool {
	l := strings.ToLower(text)
	if !has(l, []string{"селфи", "фотк", "фото", "картинк", "покажи себя", "увидеть тебя", "нарису"}) {
		return false
	}
	return has(l, []string{"отправ", "пришл", "скин", "кинь", "дай", "покаж", "хочу", "можешь", "сделай", "нарису", "давай", "пусть"})
}

func (a *Agent) hasTool(name string) bool {
	_, ok := a.tools.Get(name)
	return ok
}

// followUpPhoto: короткое «кинь» / «где» сразу после просьбы о картинке.
func (a *Agent) followUpPhoto(s *Session, text string) bool {
	l := strings.ToLower(text)
	if len([]rune(l)) > 14 || !has(l, []string{"кинь", "скинь", "давай", "где", "ну", "жду"}) {
		return false
	}
	seen := 0
	for i := len(s.hist) - 2; i >= 0 && seen < 4; i-- {
		if s.hist[i].Role == "user" {
			seen++
			if photoAsk(s.hist[i].Content) {
				return true
			}
		}
	}
	return false
}

// Clip обрезает строку до n символов (для коротких подписей).
func Clip(s string, n int) string {
	r := []rune(strings.TrimSpace(s))
	if len(r) <= n {
		return string(r)
	}
	return string(r[:n]) + "…"
}
