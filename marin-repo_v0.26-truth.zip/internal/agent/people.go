package agent

// Память о людях и настроение. Заметки о человеке (или о группе) хранятся отдельно по сессиям и видны только в их же разговоре,
// поэтому знание о хозяине не утекает к чужим.

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"time"

	"reina/internal/diary"
	"reina/internal/llm"
	"reina/internal/tools"
)

const maxPeopleNotes = 8

func (a *Agent) peoplePath() string { return filepath.Join(a.cfg.Home, "people.json") }

func (a *Agent) loadPeople() map[string][]string {
	m := map[string][]string{}
	if b, err := os.ReadFile(a.peoplePath()); err == nil {
		_ = json.Unmarshal(b, &m)
	}
	return m
}

// personAdd дописывает заметку о собеседнике сессии (дубли пропускает, старые вытесняются).
func (a *Agent) personAdd(session, note string) {
	note = strings.TrimSpace(note)
	if note == "" {
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	m := a.loadPeople()
	for _, x := range m[session] {
		if strings.EqualFold(x, note) {
			return
		}
	}
	m[session] = append(m[session], note)
	if n := len(m[session]); n > maxPeopleNotes {
		m[session] = m[session][n-maxPeopleNotes:]
	}
	b, _ := json.MarshalIndent(m, "", " ")
	tmp := a.peoplePath() + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, a.peoplePath())
	}
}

func (a *Agent) personNotes(session string) string {
	a.mu.Lock()
	defer a.mu.Unlock()
	return strings.Join(a.loadPeople()[session], "; ")
}

// Настроение живёт 6 часов, потом считается нейтральным.
func (a *Agent) setMood(m string) {
	a.mu.Lock()
	a.mood, a.moodAt = m, a.Now()
	a.mu.Unlock()
}

func (a *Agent) moodNow() string {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.mood == "" || a.Now().Sub(a.moodAt) > 6*time.Hour {
		return ""
	}
	return a.mood
}

// WeeklyDigest: раз в неделю она подводит итог по своим дневниковым записям и пишет его в дневник.
func (a *Agent) WeeklyDigest(ctx context.Context) bool {
	recs := a.Diary(60)
	if len(recs) < 3 {
		return false
	}
	msgs := []llm.Message{
		{Role: "system", Content: "Ты Рейна. Ниже твои дневниковые записи за неделю. Напиши итог недели от первого лица: что было главным, что чувствуешь, чего хочется дальше. 2-3 предложения, живо, без списков."},
		{Role: "user", Content: strings.Join(recs, "\n")},
	}
	res, ok := a.led.Reserve(a.estimate(false, msgs, nil, 300))
	if !ok {
		return false
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.FastModel, Messages: msgs, MaxTokens: 300, Reasoning: map[string]any{"enabled": false}})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return false
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	t := strings.TrimSpace(resp.Message.Content)
	if t == "" {
		return false
	}
	page := "**" + a.Now().Format("2006-01-02 15:04") + " | Итог недели**\n**Итоги:** " + t + "\n**Теги:** #итог_недели\n**Importance score:** 0.7 – подведение итогов\n**Подсказки для поиска:** [\"итог недели\", \"что было на неделе\"]"
	ok2, _ := a.pages.Add(page)
	return ok2
}

const sleepPrompt = `Ты Рейна и сейчас «спишь»: наводишь порядок в дневнике. Ниже несколько старых страниц. Склей их в одну страницу, сохранив главное: людей, события, ключевые реплики, эмоции, договорённости. Выкинь повторы и мелочи. Формат тот же: заголовок **ГГГГ-ММ-ДД | тема**, поля Итоги, Участники, Ключевые реплики, Теги, Importance score, Эмоции, Подсказки для поиска. Не выдумывай новых фактов. До 250 слов.`

// Sleep: ночная уборка дневника. Если страниц больше 40, самые старые (старше 3 суток, не особо важные и не твёрдые факты) склеиваются в одну.
func (a *Agent) Sleep(ctx context.Context) bool {
	all := a.pages.All()
	if len(all) <= 40 {
		return false
	}
	var pick []diary.Page
	for _, p := range all {
		if len(pick) >= 8 {
			break
		}
		if a.pages.Age(p) > 72*time.Hour && p.Meta.Score < 0.8 && p.Meta.Confidence < 1 {
			pick = append(pick, p)
		}
	}
	if len(pick) < 4 {
		return false
	}
	var sb strings.Builder
	var ids []string
	for _, p := range pick {
		sb.WriteString(p.Body + "\n=====\n")
		ids = append(ids, p.ID)
	}
	msgs := []llm.Message{{Role: "system", Content: sleepPrompt}, {Role: "user", Content: tools.Truncate(sb.String(), 9000)}}
	res, ok := a.led.Reserve(a.estimate(false, msgs, nil, 700))
	if !ok {
		return false
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.FastModel, Messages: msgs, MaxTokens: 700, Reasoning: map[string]any{"enabled": false}})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return false
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	t := strings.TrimSpace(resp.Message.Content)
	if len([]rune(t)) < 80 {
		return false
	}
	if ok, _ := a.pages.Add(t); !ok {
		return false
	}
	a.pages.Remove(ids...) // старые удаляем, только когда новая страница записана
	return true
}

// RecentPages: последние n страниц дневника (заголовок и начало) для панели.
func (a *Agent) RecentPages(n int) []string {
	var out []string
	pg := a.pages.Recent(n)
	for i := len(pg) - 1; i >= 0; i-- {
		out = append(out, Clip(pg[i].Body, 600))
	}
	return out
}

// Mood: текущее настроение (пусто, если нейтральное).
func (a *Agent) Mood() string { return a.moodNow() }
