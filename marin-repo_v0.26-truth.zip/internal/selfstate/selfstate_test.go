package selfstate

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"reina/internal/budget"
	"reina/internal/events"
	"reina/internal/supervisor"
	"reina/internal/tools"
)

func TestOwnerGetsTheFullPictureOthersOnlyTimeAndRules(t *testing.T) {
	loc, _ := time.LoadLocation("Asia/Bishkek")
	dir := t.TempDir()
	ev := events.Open(filepath.Join(dir, "e.json"))
	ev.Add("написала первой: «привет»")
	rem := tools.NewReminders(filepath.Join(dir, "r.json"), "Asia/Bishkek")
	rem.Add(time.Date(2026, 10, 19, 10, 0, 0, 0, loc), "купить хлеб")
	led := budget.Open(dir, 1)
	led.Add(100, 50, 0.0123)
	s := &State{
		Loc: loc, Now: func() time.Time { return time.Date(2026, 10, 18, 5, 40, 0, 0, loc) },
		Started: time.Date(2026, 10, 18, 2, 30, 0, 0, loc),
		Events:  ev, Led: led, Rem: rem, Sup: supervisor.New(),
		Voice:      func() string { return "по настроению" },
		STT:        func() bool { return true },
		ImagesLeft: func() (int, int, bool) { return 17, 20, true },
		Initiative: func() (int, int, bool) { return 1, 3, true },
		Groups:     func() []string { return []string{"«клуб любителей куни»"} },
		OpenDM:     func() (bool, int, int) { return true, 40, 2 },
		Cap:        func() float64 { return 1 },
	}
	own := s.Block(true)
	for _, want := range []string{"Правила правды", "воскресенье, 18 октября 2026, 05:40", "работаешь 3 ч 10 мин", "по настроению", "осталось 17 из 20", "из потолка $1.00", "сегодня написала 1 из 3", "«клуб любителей куни»", "до 40 сообщений", "заблокировано людей: 2", "купить хлеб", "написала первой: «привет»"} {
		if !strings.Contains(own, want) {
			t.Errorf("в состоянии хозяина нет %q:\n%s", want, own)
		}
	}
	other := s.Block(false)
	if !strings.Contains(other, "Правила правды") || !strings.Contains(other, "05:40") {
		t.Fatalf("чужим нужны время и правила: %s", other)
	}
	for _, leak := range []string{"клуб", "хлеб", "Расходы", "первой", "Модули", "заблокировано"} {
		if strings.Contains(other, leak) {
			t.Errorf("чужому видно %q:\n%s", leak, other)
		}
	}
}

func TestExecHookLogsActionsAndFailuresButNotReads(t *testing.T) {
	ev := events.Open("")
	h := ExecHook(ev)
	h("tg_voice", true, "готово")
	h("selfie", false, "ошибка: дневной лимит картинок (20) исчерпан")
	h("recall", true, "секретный факт")
	h("shell", true, "echo пароль123")
	var all []string
	for _, it := range ev.Last(10) {
		all = append(all, it.Text)
	}
	j := strings.Join(all, "|")
	if !strings.Contains(j, "tg_voice: сделано") || !strings.Contains(j, "selfie: ошибка: дневной лимит") {
		t.Fatalf("%s", j)
	}
	if strings.Contains(j, "recall") || strings.Contains(j, "секретный") || strings.Contains(j, "пароль123") {
		t.Fatalf("в журнал попало лишнее: %s", j)
	}
}
