// Package selfstate собирает для неё картину «что у меня есть и что со мной происходит» на текущий момент.
// Блок идёт в каждый ход вместе с правилами правды: говорить о себе только по фактам и не выдумывать остальное.
package selfstate

import (
	"fmt"
	"strings"
	"time"

	"reina/internal/budget"
	"reina/internal/events"
	"reina/internal/supervisor"
	"reina/internal/tools"
)

// TruthRules идут первыми и важнее остального: это защита от выдумок.
const TruthRules = "Правила правды (важнее всего остального). Про себя, свою жизнь, свои чаты и всё, что «было», говори только то, что есть в этом блоке, в памяти, дневнике, истории чата или в результатах инструментов. Нет данных: так и скажи по-своему («не помню», «не знаю», «не вижу», «ща гляну»), но не выдумывай имена, места, события, числа, ссылки и «что было вчера». Не говори, что что-то сделала (отправила, запомнила, поставила, нарисовала), пока инструмент не вернул успех; вернул ошибку: скажи, что не вышло и почему. Если поймали на неточности, признай это без обид."

var weekdays = [...]string{"воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"}
var months = [...]string{"", "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"}

type State struct {
	Loc     *time.Location
	Now     func() time.Time
	Started time.Time
	Events  *events.Log
	Led     *budget.Ledger
	Rem     *tools.Reminders
	Sup     *supervisor.Supervisor

	Voice      func() string                   // как сейчас с голосом: «по настроению», «выключен»…
	STT        func() bool                     // понимает ли голосовые
	ImagesLeft func() (left, max int, on bool) // картинки на сегодня
	Initiative func() (sent, max int, on bool) // писала первой сегодня
	Groups     func() []string                 // группы, где ей разрешено отвечать
	OpenDM     func() (open bool, limit, blocked int)
	Cap        func() float64 // дневной потолок расходов
}

func (s *State) now() time.Time {
	t := time.Now()
	if s.Now != nil {
		t = s.Now()
	}
	if s.Loc != nil {
		t = t.In(s.Loc)
	}
	return t
}

func dur(d time.Duration) string {
	h, m := int(d.Hours()), int(d.Minutes())%60
	if h >= 24 {
		return fmt.Sprintf("%d д %d ч", h/24, h%24)
	}
	if h > 0 {
		return fmt.Sprintf("%d ч %d мин", h, m)
	}
	return fmt.Sprintf("%d мин", m)
}

// Block: owner=true даёт полную картину, остальным только время и правила (про хозяина, расходы и чаты чужим знать нечего).
func (s *State) Block(owner bool) string {
	now := s.now()
	var sb strings.Builder
	sb.WriteString(TruthRules + "\n")
	zone := ""
	if s.Loc != nil {
		zone = " (" + s.Loc.String() + ")"
	}
	fmt.Fprintf(&sb, "Сейчас: %s, %d %s %d, %s%s.\n", weekdays[now.Weekday()], now.Day(), months[now.Month()], now.Year(), now.Format("15:04"), zone)
	if !owner {
		return sb.String()
	}
	sb.WriteString("Твоё реальное состояние (знай это, остального не выдумывай):\n")
	if !s.Started.IsZero() {
		fmt.Fprintf(&sb, "- Запущена в %s, работаешь %s.\n", s.Started.In(now.Location()).Format("15:04"), dur(now.Sub(s.Started)))
	}
	if s.Voice != nil {
		stt := ""
		if s.STT != nil {
			stt = ", голосовые собеседников не понимаешь"
			if s.STT() {
				stt = ", голосовые собеседников понимаешь"
			}
		}
		fmt.Fprintf(&sb, "- Голос: %s%s.\n", s.Voice(), stt)
	}
	if s.ImagesLeft != nil {
		if left, max, on := s.ImagesLeft(); on {
			fmt.Fprintf(&sb, "- Картинки и селфи: включены, на сегодня осталось %d из %d.\n", left, max)
		} else {
			sb.WriteString("- Картинки и селфи: выключены.\n")
		}
	}
	if s.Led != nil {
		d := s.Led.Today()
		cp := ""
		if s.Cap != nil && s.Cap() > 0 {
			cp = fmt.Sprintf(" из потолка $%.2f", s.Cap())
		}
		fmt.Fprintf(&sb, "- Расходы сегодня: $%.4f%s, запросов %d.\n", d.USD, cp, d.Requests)
	}
	if s.Initiative != nil {
		if sent, max, on := s.Initiative(); on {
			fmt.Fprintf(&sb, "- Писать первой: можно, сегодня написала %d из %d.\n", sent, max)
		} else {
			sb.WriteString("- Писать первой: выключено.\n")
		}
	}
	if s.Groups != nil {
		if g := s.Groups(); len(g) > 0 {
			fmt.Fprintf(&sb, "- Группы, где тебе разрешено отвечать: %s. В остальных молчишь, пока хозяин не разрешит.\n", strings.Join(g, "; "))
		} else {
			sb.WriteString("- Групп, где тебе разрешено отвечать, пока нет.\n")
		}
	}
	if s.OpenDM != nil {
		open, limit, blocked := s.OpenDM()
		if open {
			fmt.Fprintf(&sb, "- Личка: чужим отвечаешь (до %d сообщений в сутки на человека), заблокировано людей: %d.\n", limit, blocked)
		} else {
			sb.WriteString("- Личка: чужим не отвечаешь, только разрешённым.\n")
		}
	}
	if s.Rem != nil {
		list := s.Rem.List()
		if len(list) == 0 {
			sb.WriteString("- Напоминаний нет.\n")
		} else {
			loc := s.Rem.Loc
			if loc == nil {
				loc = now.Location()
			}
			fmt.Fprintf(&sb, "- Напоминаний %d, ближайшее: %s «%s».\n", len(list), list[0].At.In(loc).Format("02.01 15:04"), list[0].Text)
		}
	}
	if s.Sup != nil {
		var parts []string
		for _, m := range s.Sup.Status() {
			st := m.State
			if m.LastErr != "" && m.State != "running" {
				st += ", ошибка: " + m.LastErr
			}
			parts = append(parts, m.Name+": "+st)
		}
		if len(parts) > 0 {
			sb.WriteString("- Модули: " + strings.Join(parts, "; ") + ".\n")
		}
	}
	if ev := s.Events.Format(10, now.Location()); ev != "" {
		sb.WriteString("Последние события с тобой (реальные, новые снизу):\n" + ev)
	}
	return sb.String()
}

// actions: инструменты, которые что-то делают (их следы попадают в журнал); чтение и поиск не пишем, чтобы не засорять.
var actions = map[string]bool{"image_make": true, "selfie": true, "live_update": true, "module_write": true, "module_delete": true, "module_toggle": true, "mouse": true, "open_app": true, "remember": true, "forget": true, "remind_add": true, "remind_cancel": true, "set_wallpaper": true, "shell": true, "tg_delete": true, "tg_edit": true, "tg_react": true, "tg_send": true, "tg_send_file": true, "tg_sticker": true, "tg_voice": true, "type": true, "write_file": true, "key": true}

// ExecHook пишет в журнал результат действий: «tg_voice: ок» или «tg_voice: ошибка ...». Аргументы не пишутся (там бывают секреты).
func ExecHook(l *events.Log) func(name string, ok bool, out string) {
	return func(name string, ok bool, out string) {
		if l == nil || !actions[name] {
			return
		}
		if ok {
			l.Add("%s: сделано", name)
		} else {
			l.Add("%s: %s", name, out)
		}
	}
}
