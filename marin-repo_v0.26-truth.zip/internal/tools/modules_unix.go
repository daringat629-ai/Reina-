//go:build !windows

package tools

import (
	"os/exec"
	"syscall"
)

// own: модуль живёт в своей группе процессов, по таймауту убивается вся группа (вместе с детьми).
func own(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	c.Cancel = func() error { return syscall.Kill(-c.Process.Pid, syscall.SIGKILL) }
}
