// Package tools: инструменты Рейны и политика их выполнения.
// Решение «можно ли выполнить» принимает код, а не модель: список разрешённых инструментов, проверка аргументов,
// корни для чтения файлов, запрет на секреты, лимиты на длину команды, число опасных вызовов за ход, таймауты и обрезка вывода.
// Подтверждение владельца относится к тем самым аргументам, которые будут выполнены (они показываются в вопросе дословно).
package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"reina/internal/llm"
	"reina/internal/memory"
)

type Tool struct {
	Name, Desc string
	Params     map[string]any
	Dangerous  bool
	Run        func(ctx context.Context, args map[string]any) (string, error)
}

// Policy задаётся конфигом.
type Policy struct {
	Allowed      map[string]bool // nil: разрешены все встроенные
	Shell        string          // ask | always | never
	ModulesDir   string          // папка модулей (~/.reina/modules); пусто: модули выключены
	Desktop      bool            // инструменты управления ПК (screen, mouse, type, key, open_app, set_wallpaper, write_file, web, wait)
	ReadRoots    []string        // откуда можно читать файлы; пусто: домашний каталог пользователя
	Deny         []string        // файлы и каталоги, которые читать нельзя никогда (секреты)
	MaxCommand   int
	MaxDangerous int // опасных вызовов за один ход
	ShellTimeout time.Duration
	ReadMax      int
}

func DefaultPolicy(home string) Policy {
	return Policy{Shell: "ask", MaxCommand: 1000, MaxDangerous: 3, ShellTimeout: 60 * time.Second, ReadMax: 20000, Deny: []string{home}}
}

// Turn: состояние одного хода (сколько опасных вызовов уже было).
type Turn struct {
	dangerous int
	mu        sync.Mutex
	ok        map[string]bool // какие инструменты в этом ходе отработали без ошибки
}

func (t *Turn) mark(name string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.ok == nil {
		t.ok = map[string]bool{}
	}
	t.ok[name] = true
}

// Done: отработал ли без ошибки хотя бы один из инструментов в этом ходе.
func (t *Turn) Done(names ...string) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	for _, n := range names {
		if t.ok[n] {
			return true
		}
	}
	return false
}

type Set struct {
	list   []Tool
	Policy Policy
	desk   *desk
	mods   *modules

	// OnExec вызывается после каждого выполненного инструмента (журнал событий): ok=false значит, что он вернул ошибку.
	OnExec func(name string, ok bool, out string)
}

// SetVision подключает модель для картинок инструменту screen.
func (s *Set) SetVision(v Vision) {
	if s.desk != nil {
		s.desk.Vision = v
	}
}

func obj(props map[string]any, req ...string) map[string]any {
	return map[string]any{"type": "object", "properties": props, "required": req}
}

func str(desc string) map[string]any { return map[string]any{"type": "string", "description": desc} }

func argStr(a map[string]any, k string) string { s, _ := a[k].(string); return s }

func argInt(a map[string]any, k string) int64 {
	switch v := a[k].(type) {
	case float64:
		return int64(v)
	case string:
		var n int64
		fmt.Sscan(v, &n)
		return n
	}
	return 0
}

func Default(mem memory.Store, p Policy) *Set {
	s := &Set{Policy: p}
	s.list = []Tool{
		{Name: "time", Desc: "Текущие дата и время", Params: obj(map[string]any{}), Run: func(context.Context, map[string]any) (string, error) {
			return time.Now().Format("2006-01-02 15:04 Monday MST"), nil
		}},
		{Name: "remember", Desc: "Запомнить короткий факт о хозяине или делах надолго", Params: obj(map[string]any{"fact": str("факт одной фразой")}, "fact"), Run: func(_ context.Context, a map[string]any) (string, error) {
			f := argStr(a, "fact")
			if strings.TrimSpace(f) == "" {
				return "", fmt.Errorf("пустой факт")
			}
			id, added := mem.Add(f, "tool", 0)
			if !added {
				return fmt.Sprintf("уже помню (№%d)", id), nil
			}
			return fmt.Sprintf("запомнила (№%d)", id), nil
		}},
		{Name: "recall", Desc: "Найти в долгой памяти факты по словам (с номерами)", Params: obj(map[string]any{"query": str("слова для поиска")}, "query"), Run: func(_ context.Context, a map[string]any) (string, error) {
			r := mem.Search(argStr(a, "query"), 5)
			if len(r) == 0 {
				return "ничего не найдено", nil
			}
			var sb strings.Builder
			for _, f := range r {
				fmt.Fprintf(&sb, "№%d: %s\n", f.ID, f.Text)
			}
			return sb.String(), nil
		}},
		{Name: "forget", Desc: "Забыть факт из памяти по номеру (номер из recall)", Params: obj(map[string]any{"id": map[string]any{"type": "integer"}}, "id"), Run: func(_ context.Context, a map[string]any) (string, error) {
			if !mem.Delete(argInt(a, "id")) {
				return "", fmt.Errorf("такого факта нет")
			}
			return "забыла", nil
		}},
		{Name: "read_file", Desc: "Прочитать текстовый файл (до 20 КБ)", Params: obj(map[string]any{"path": str("путь")}, "path"), Run: func(_ context.Context, a map[string]any) (string, error) {
			p, err := s.checkRead(argStr(a, "path"))
			if err != nil {
				return "", err
			}
			b, err := os.ReadFile(p)
			if err != nil {
				return "", err
			}
			if len(b) > s.Policy.ReadMax {
				b = b[:s.Policy.ReadMax]
			}
			return string(b), nil
		}},
		{Name: "shell", Desc: "Выполнить команду bash на ноутбуке (таймаут 60 с)", Dangerous: true, Params: obj(map[string]any{"command": str("команда")}, "command"), Run: func(ctx context.Context, a map[string]any) (string, error) {
			ctx, cancel := context.WithTimeout(ctx, s.Policy.ShellTimeout)
			defer cancel()
			out, err := exec.CommandContext(ctx, "bash", "-c", argStr(a, "command")).CombinedOutput()
			if ctx.Err() == context.DeadlineExceeded {
				return string(out) + "\n[остановлено по таймауту]", nil
			}
			if err != nil {
				return string(out) + "\n[ошибка: " + err.Error() + "]", nil
			}
			return string(out), nil
		}},
	}
	if p.Desktop {
		s.desk = &desk{scale: 1}
		s.list = append(s.list, s.desk.tools(s)...)
	}
	if p.ModulesDir != "" {
		if err := os.MkdirAll(p.ModulesDir, 0o755); err == nil {
			s.mods = &modules{dir: p.ModulesDir}
			s.list = append(s.list, s.mods.tools()...)
		}
	}
	return s
}

// checkRead: путь должен после раскрытия ссылок лежать внутри разрешённых корней и вне запретных мест.
func (s *Set) checkRead(p string) (string, error) {
	if strings.TrimSpace(p) == "" || strings.ContainsRune(p, 0) {
		return "", fmt.Errorf("путь не задан")
	}
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	real, err := filepath.EvalSymlinks(abs)
	if err != nil {
		return "", err
	}
	in := func(root string) bool {
		r, err := filepath.EvalSymlinks(root)
		if err != nil {
			r = root
		}
		rel, err := filepath.Rel(r, real)
		return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
	}
	for _, d := range s.Policy.Deny {
		if d != "" && in(d) {
			return "", fmt.Errorf("этот файл закрыт политикой (секреты)")
		}
	}
	roots := s.Policy.ReadRoots
	if len(roots) == 0 {
		if h, err := os.UserHomeDir(); err == nil {
			roots = []string{h}
		}
	}
	for _, r := range roots {
		if in(r) {
			return real, nil
		}
	}
	return "", fmt.Errorf("чтение вне разрешённых каталогов запрещено")
}

func (s *Set) allowed(name string) bool { return s.Policy.Allowed == nil || s.Policy.Allowed[name] }

func (s *Set) Get(name string) (Tool, bool) {
	if s.mods != nil && strings.HasPrefix(name, "m_") { // модули подхватываются на лету
		return s.mods.get(name)
	}
	if !s.allowed(name) {
		return Tool{}, false
	}
	for _, t := range s.list {
		if t.Name == name {
			return t, true
		}
	}
	return Tool{}, false
}

// Defs описания для модели: только разрешённые политикой. Отправляются, когда они нужны (экономия токенов).
func (s *Set) Defs() []llm.Tool {
	var out []llm.Tool
	for _, t := range s.list {
		if !s.allowed(t.Name) || (t.Dangerous && s.Policy.Shell == "never") {
			continue
		}
		var d llm.Tool
		d.Type = "function"
		d.Function.Name, d.Function.Description, d.Function.Parameters = t.Name, t.Desc, t.Params
		out = append(out, d)
	}
	if s.mods != nil {
		out = append(out, s.mods.defs()...)
	}
	return out
}

// Parallel: можно ли выполнять этот вызов одновременно с другими (известный инструмент без подтверждения владельца).
func (s *Set) Parallel(name string) bool {
	t, ok := s.Get(name)
	return ok && !t.Dangerous
}

// Exec выполняет вызов инструмента по политике. confirm спрашивает владельца (nil: спросить нельзя, значит опасное не выполняется).
func (s *Set) Exec(ctx context.Context, turn *Turn, name, rawArgs string, confirm func(desc string) bool) string {
	t, ok := s.Get(name)
	if !ok {
		return "отказ: такого инструмента нет или он выключен политикой"
	}
	args := map[string]any{}
	if strings.TrimSpace(rawArgs) != "" {
		if err := json.Unmarshal([]byte(rawArgs), &args); err != nil {
			return "отказ: аргументы не похожи на JSON-объект"
		}
	}
	maxArgs := 8000
	if name == "module_write" {
		maxArgs = modCodeMax + 4000
	}
	if len(rawArgs) > maxArgs {
		return "отказ: слишком длинные аргументы"
	}
	if t.Dangerous {
		if cmd := argStr(args, "command"); t.Name == "shell" && (strings.TrimSpace(cmd) == "" || len(cmd) > s.Policy.MaxCommand || strings.ContainsRune(cmd, 0)) {
			return fmt.Sprintf("отказ: команда пустая или длиннее %d символов", s.Policy.MaxCommand)
		}
		if turn.dangerous >= s.Policy.MaxDangerous {
			return "отказ: за один ответ можно сделать не больше опасных действий, чем разрешено политикой"
		}
		switch s.Policy.Shell {
		case "never":
			return "отказ: опасные действия запрещены настройками"
		case "always":
		default:
			if confirm == nil || !confirm(describe(t.Name, args)) {
				return "отказ: владелец не разрешил"
			}
		}
		turn.dangerous++
	}
	out, err := t.Run(ctx, args)
	if err != nil {
		out = "ошибка: " + err.Error()
	} else {
		turn.mark(name)
	}
	if s.OnExec != nil {
		s.OnExec(name, err == nil, out)
	}
	return out
}

func describe(name string, args map[string]any) string {
	b, _ := json.Marshal(args)
	return name + " " + Truncate(string(b), 400)
}

// Truncate: голова и хвост вывода, середина заменяется пометкой.
func Truncate(s string, max int) string {
	r := []rune(s)
	if max <= 0 || len(r) <= max {
		return s
	}
	h := max * 2 / 3
	return string(r[:h]) + fmt.Sprintf("\n…[скрыто %d символов]…\n", len(r)-max) + string(r[len(r)-(max-h):])
}
