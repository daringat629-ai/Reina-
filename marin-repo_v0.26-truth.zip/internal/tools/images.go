package tools

import (
	"context"
	"fmt"
	"strings"
)

// Painter рисует картинки (пакет images).
type Painter interface {
	Make(ctx context.Context, prompt string) (string, error)
	Selfie(ctx context.Context, scene string) (string, error)
	MakeHer(ctx context.Context, prompt string) (string, error)
}

// SetImages подключает image_make и selfie: готовая картинка уходит в текущий чат.
func (s *Set) SetImages(p Painter, m Messenger) {
	send := func(ctx context.Context, path, caption string, a map[string]any) (string, error) {
		c, err := chatArg(ctx, a)
		if err != nil {
			return "", err
		}
		if err := m.SendFile(ctx, c, path, caption); err != nil {
			return "", err
		}
		return "картинка отправлена", nil
	}
	s.Add(Tool{Name: "image_make", Desc: "Нарисовать картинку по описанию (лучше по-английски, подробно) и отправить в текущий чат. Занимает до минуты и стоит денег, не злоупотребляй",
		Params: obj(map[string]any{"prompt": str("что нарисовать"), "caption": str("подпись (можно пусто)"), "her": map[string]any{"type": "boolean", "description": "true: на картинке ты сама (внешность берётся с референса)"}}, "prompt"),
		Run: func(ctx context.Context, a map[string]any) (string, error) {
			pr := strings.TrimSpace(argStr(a, "prompt"))
			if pr == "" {
				return "", fmt.Errorf("нужен prompt")
			}
			make := p.Make
			if h, _ := a["her"].(bool); h {
				make = p.MakeHer
			}
			path, err := make(ctx, pr)
			if err != nil {
				return "", err
			}
			return send(ctx, path, argStr(a, "caption"), a)
		}})
	s.Add(Tool{Name: "selfie", Desc: "Сделать своё селфи (ты в кадре, внешность всегда одна) и отправить в текущий чат. scene: где ты, что на тебе, настроение, по-английски",
		Params: obj(map[string]any{"scene": str("сцена селфи"), "caption": str("подпись (можно пусто)")}, "scene"),
		Run: func(ctx context.Context, a map[string]any) (string, error) {
			sc := strings.TrimSpace(argStr(a, "scene"))
			if sc == "" {
				return "", fmt.Errorf("нужна scene")
			}
			path, err := p.Selfie(ctx, sc)
			if err != nil {
				return "", err
			}
			return send(ctx, path, argStr(a, "caption"), a)
		}})
}
