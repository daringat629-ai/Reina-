package tools

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"reina/internal/memory"
)

func deskSet(t *testing.T) (*Set, string) {
	t.Helper()
	home := t.TempDir()
	p := DefaultPolicy(filepath.Join(home, ".marin"))
	p.Shell, p.Desktop = "always", true
	return Default(memory.Open(home), p), home
}

func call(s *Set, name, args string) string {
	return s.Exec(context.Background(), &Turn{}, name, args, nil)
}

func TestDesktopToolsListed(t *testing.T) {
	s, _ := deskSet(t)
	got := map[string]bool{}
	for _, d := range s.Defs() {
		got[d.Function.Name] = true
	}
	for _, n := range []string{"screen", "mouse", "type", "key", "open_app", "set_wallpaper", "write_file", "web", "wait"} {
		if !got[n] {
			t.Errorf("нет инструмента %s", n)
		}
	}
	p := DefaultPolicy("x")
	if len(Default(memory.Open(t.TempDir()), p).Defs()) >= len(s.Defs()) {
		t.Error("без Desktop инструментов быть не должно")
	}
}

func TestDesktopNeverBlocksHands(t *testing.T) {
	s, _ := deskSet(t)
	s.Policy.Shell = "never"
	if r := call(s, "mouse", `{"action":"click","x":1,"y":1}`); !strings.HasPrefix(r, "отказ") {
		t.Errorf("при never мышь должна быть запрещена: %s", r)
	}
}

func TestDesktopAskNeedsConfirm(t *testing.T) {
	s, _ := deskSet(t)
	s.Policy.Shell = "ask"
	if r := call(s, "type", `{"text":"x"}`); !strings.Contains(r, "владелец не разрешил") {
		t.Errorf("без подтверждения нельзя: %s", r)
	}
}

func TestNoDisplayHonest(t *testing.T) {
	t.Setenv("DISPLAY", "")
	t.Setenv("WAYLAND_DISPLAY", "")
	s, _ := deskSet(t)
	for _, c := range [][2]string{{"screen", `{}`}, {"key", `{"keys":"Return"}`}, {"open_app", `{"target":"firefox"}`}} {
		if r := call(s, c[0], c[1]); !strings.Contains(r, "графического экрана") {
			t.Errorf("%s: ожидали объяснение про экран, получили %q", c[0], r)
		}
	}
}

func TestWriteFileRules(t *testing.T) {
	s, home := deskSet(t)
	p := filepath.Join(home, "a", "b.txt")
	if r := call(s, "write_file", `{"path":"`+p+`","content":"привет"}`); !strings.Contains(r, "записала") {
		t.Fatal(r)
	}
	if b, _ := os.ReadFile(p); string(b) != "привет" {
		t.Error("содержимое не то")
	}
	sec := filepath.Join(home, ".marin", "config.json")
	if r := call(s, "write_file", `{"path":"`+sec+`","content":"x"}`); !strings.Contains(r, "закрыт политикой") {
		t.Errorf("секреты Рейны писать нельзя: %s", r)
	}
}

func TestWebFetchAndBadURL(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte("<html><script>bad()</script><body><h1>Привет</h1> мир</body></html>"))
	}))
	defer srv.Close()
	s, _ := deskSet(t)
	r := call(s, "web", `{"url":"`+srv.URL+`"}`)
	if !strings.Contains(r, "Привет мир") || strings.Contains(r, "bad()") {
		t.Errorf("html не очищен: %q", r)
	}
	if r := call(s, "web", `{"url":"file:///etc/passwd"}`); !strings.Contains(r, "http") {
		t.Errorf("file:// должен быть отклонён: %s", r)
	}
}

func TestKeyAndOpenAppRejectInjection(t *testing.T) {
	t.Setenv("DISPLAY", ":99")
	s, _ := deskSet(t)
	if r := call(s, "key", `{"keys":"a; rm -rf /"}`); strings.Contains(r, "нажала") {
		t.Errorf("инъекция в key: %s", r)
	}
	if r := call(s, "open_app", `{"target":"firefox; rm -rf ~"}`); !strings.Contains(r, "странная цель") {
		t.Errorf("инъекция в open_app: %s", r)
	}
}

func TestMouseScaling(t *testing.T) {
	d := &desk{scale: 1.5}
	if x, y := d.toReal(100, 200); x != 150 || y != 300 {
		t.Errorf("масштаб: %d,%d", x, y)
	}
}

func TestSearchParsesResults(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("q") != "кошки мем" {
			t.Errorf("запрос: %q", r.URL.RawQuery)
		}
		w.Write([]byte(`<div class="result"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fa%3Fx%3D1&rut=zz">Кошки &amp; <b>мемы</b></a>
<a class="result__snippet" href="x">Лучшие <b>мемы</b> про кошек</a></div>
<div class="result"><a class="result__a" href="https://b.test/">Вторая</a><a class="result__snippet" href="y">снип 2</a></div>`))
	}))
	defer srv.Close()
	old := SearchURL
	SearchURL = srv.URL
	defer func() { SearchURL = old }()
	s, _ := deskSet(t)
	r := call(s, "search", `{"query":"кошки мем"}`)
	for _, w := range []string{"1. Кошки & мемы", "https://example.com/a?x=1", "Лучшие мемы про кошек", "2. Вторая", "https://b.test/"} {
		if !strings.Contains(r, w) {
			t.Errorf("нет %q в %q", w, r)
		}
	}
	if r := call(s, "search", `{"query":""}`); !strings.Contains(r, "пуст") {
		t.Errorf("пустой запрос: %s", r)
	}
}
