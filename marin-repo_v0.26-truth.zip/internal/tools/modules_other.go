//go:build windows

package tools

import "os/exec"

func own(c *exec.Cmd) {}
