package tools

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"reina/internal/memory"
)

type fakeMsgr struct{ log []string }

func (f *fakeMsgr) SendText(_ context.Context, t, x string) error {
	f.log = append(f.log, "send:"+t+":"+x)
	return nil
}
func (f *fakeMsgr) Chats(_ context.Context, q string, _ int) (string, error) {
	return "42 | Аня | @anya\n", nil
}
func (f *fakeMsgr) React(_ context.Context, c int64, id int, e string) error {
	f.log = append(f.log, fmt.Sprintf("react:%d:%d:%s", c, id, e))
	return nil
}
func (f *fakeMsgr) SendSticker(_ context.Context, c int64, e string) error {
	f.log = append(f.log, fmt.Sprintf("sticker:%d:%s", c, e))
	return nil
}
func (f *fakeMsgr) History(_ context.Context, c int64, n int) (string, error) {
	f.log = append(f.log, fmt.Sprintf("history:%d:%d", c, n))
	return "7 | 11:00 | я | привет\n", nil
}
func (f *fakeMsgr) Edit(_ context.Context, c int64, id int, t string) error {
	f.log = append(f.log, fmt.Sprintf("edit:%d:%d:%s", c, id, t))
	return nil
}
func (f *fakeMsgr) Delete(_ context.Context, c int64, id int) error {
	f.log = append(f.log, fmt.Sprintf("delete:%d:%d", c, id))
	return nil
}
func (f *fakeMsgr) SendFile(_ context.Context, c int64, p, cap string) error {
	f.log = append(f.log, fmt.Sprintf("file:%d:%s:%s", c, filepath.Base(p), cap))
	return nil
}
func (f *fakeMsgr) StickerEmojis(context.Context) (string, error) { return "😏×2 ❤×1", nil }

func msgrSet(t *testing.T) (*Set, *fakeMsgr) {
	t.Helper()
	s, _ := deskSet(t)
	s.Policy.Shell = "always"
	f := &fakeMsgr{}
	s.SetMessenger(f)
	s.SetMessenger(f) // повторный вызов не дублирует инструменты
	return s, f
}

func TestTelegramToolsListedOnceAndOnlyWithMessenger(t *testing.T) {
	s, _ := msgrSet(t)
	n := 0
	for _, d := range s.Defs() {
		if d.Function.Name == "tg_send" {
			n++
		}
	}
	if n != 1 {
		t.Fatalf("tg_send должен быть один раз, а их %d", n)
	}
	p := DefaultPolicy("x")
	for _, d := range Default(memory.Open(t.TempDir()), p).Defs() {
		if strings.HasPrefix(d.Function.Name, "tg_") {
			t.Fatalf("без транспорта нет %s", d.Function.Name)
		}
	}
}

func TestReactAndStickerUseTheCurrentChat(t *testing.T) {
	s, f := msgrSet(t)
	ctx := WithChat(context.Background(), 777, 55)
	if r := s.Exec(ctx, &Turn{}, "tg_react", `{"emoji":"👍"}`, nil); !strings.Contains(r, "поставила") {
		t.Fatal(r)
	}
	if r := s.Exec(ctx, &Turn{}, "tg_sticker", `{"emoji":"😏"}`, nil); !strings.Contains(r, "отправлен") {
		t.Fatal(r)
	}
	if got := strings.Join(f.log, ","); got != "react:777:55:👍,sticker:777:😏" {
		t.Fatalf("не то: %s", got)
	}
	if r := s.Exec(context.Background(), &Turn{}, "tg_sticker", `{"emoji":"😏"}`, nil); !strings.Contains(r, "нет чата") {
		t.Errorf("вне чата стикер не должен уйти: %s", r)
	}
}

func TestSendToOthersNeedsOwnerApproval(t *testing.T) {
	s, f := msgrSet(t)
	s.Policy.Shell = "ask"
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"@anya","text":"привет"}`, nil); !strings.Contains(r, "владелец не разрешил") || len(f.log) != 0 {
		t.Fatalf("без разрешения писать другим нельзя: %s %v", r, f.log)
	}
	asked := ""
	ok := func(d string) bool { asked = d; return true }
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"@anya","text":"привет"}`, ok); r != "отправила" || !strings.Contains(asked, "@anya") {
		t.Fatalf("с разрешением должно уйти: %s / %s", r, asked)
	}
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"","text":"x"}`, ok); !strings.Contains(r, "ошибка") {
		t.Errorf("пустой адресат: %s", r)
	}
}

func TestMoreTelegramToolsAndVoice(t *testing.T) {
	s, f := msgrSet(t)
	ctx := WithChat(context.Background(), 42, 9)
	run := func(name, args string) string { return s.Exec(ctx, &Turn{}, name, args, nil) }
	if r := run("tg_history", `{"limit":5}`); !strings.Contains(r, "привет") || f.log[len(f.log)-1] != "history:42:5" {
		t.Fatalf("история текущего чата: %s %v", r, f.log)
	}
	run("tg_history", `{"chat":-100500,"limit":500}`)
	if f.log[len(f.log)-1] != "history:-100500:15" {
		t.Fatalf("чужой чат по id, лимит по умолчанию: %v", f.log)
	}
	run("tg_edit", `{"message_id":7,"text":"поправила"}`)
	run("tg_delete", `{"message_id":7}`)
	if got := strings.Join(f.log[len(f.log)-2:], ","); got != "edit:42:7:поправила,delete:42:7" {
		t.Fatalf("правка и удаление: %s", got)
	}
	// файл: только из разрешённых мест
	file := filepath.Join(filepath.Dir(t.TempDir()), "x.txt")
	_ = os.WriteFile(file, []byte("x"), 0o644)
	if r := run("tg_send_file", `{"path":"/etc/shadow"}`); !strings.HasPrefix(r, "ошибка") {
		t.Fatalf("секреты не отправляются: %s", r)
	}
	// опасные требуют подтверждения владельца
	s.Policy.Shell = "ask"
	for _, n := range []string{"tg_edit", "tg_delete", "tg_send_file"} {
		if r := s.Exec(ctx, &Turn{}, n, `{"message_id":1,"text":"x","path":"x"}`, nil); !strings.Contains(r, "не разрешил") {
			t.Fatalf("%s должен спрашивать владельца: %s", n, r)
		}
	}
	// голосовое: отправляет и помечает ход
	var said string
	s.SetVoice(func(_ context.Context, chat int64, text string) error { said = fmt.Sprint(chat, ":", text); return nil })
	if Spoke(ctx) {
		t.Fatal("ещё не говорила")
	}
	if r := run("tg_voice", `{"text":"привет, это я"}`); !strings.Contains(r, "отправлено") || said != "42:привет, это я" || !Spoke(ctx) {
		t.Fatalf("голосовое: %s %q", r, said)
	}
	if r := run("tg_voice", `{"text":""}`); !strings.HasPrefix(r, "ошибка") {
		t.Fatal(r)
	}
}

func TestReactionsAreMappedToWhatTelegramAccepts(t *testing.T) {
	for in, want := range map[string]string{"🔥": "🔥", "❤️": "❤", "🔪": "😈", "🤫": "🙈", "😏": "😈", "🙄": "🤨", "🦖": "🤔", " 👍 ": "👍"} {
		if got := ReactionFor(in); got != want {
			t.Errorf("%q -> %q, ждали %q", in, got, want)
		}
	}
	s, f := msgrSet(t)
	ctx := WithChat(context.Background(), 42, 9)
	s.Exec(ctx, &Turn{}, "tg_react", `{"emoji":"🔪"}`, nil)
	if f.log[len(f.log)-1] != "react:42:9:😈" {
		t.Fatalf("tg_react шлёт допустимую реакцию: %v", f.log)
	}
}
