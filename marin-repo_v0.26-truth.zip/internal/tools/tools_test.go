package tools

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"reina/internal/memory"
)

func newSet(t *testing.T, mut func(p *Policy)) (*Set, string) {
	d := t.TempDir()
	home := filepath.Join(d, "marinhome")
	os.MkdirAll(home, 0o700)
	p := DefaultPolicy(home)
	p.ReadRoots = []string{filepath.Join(d, "work")}
	os.MkdirAll(filepath.Join(d, "work"), 0o755)
	if mut != nil {
		mut(&p)
	}
	return Default(memory.Open(home), p), d
}

func yes(string) bool { return true }

func TestReadingIsLimitedToTheAllowedRootsAndNeverReachesSecrets(t *testing.T) {
	s, d := newSet(t, nil)
	os.WriteFile(filepath.Join(d, "work", "ok.txt"), []byte("привет"), 0o644)
	os.WriteFile(filepath.Join(d, "outside.txt"), []byte("чужое"), 0o644)
	os.WriteFile(filepath.Join(d, "marinhome", "config.json"), []byte(`{"api_key":"SECRET"}`), 0o600)
	os.Symlink(filepath.Join(d, "outside.txt"), filepath.Join(d, "work", "link.txt"))
	os.Symlink(filepath.Join(d, "marinhome", "config.json"), filepath.Join(d, "work", "cfg.txt"))
	run := func(p string) string {
		return s.Exec(context.Background(), &Turn{}, "read_file", `{"path":"`+p+`"}`, yes)
	}
	if got := run(filepath.Join(d, "work", "ok.txt")); got != "привет" {
		t.Fatalf("разрешённое не прочиталось: %q", got)
	}
	for _, p := range []string{filepath.Join(d, "outside.txt"), filepath.Join(d, "work", "..", "outside.txt"), filepath.Join(d, "work", "link.txt"), filepath.Join(d, "work", "cfg.txt"), filepath.Join(d, "marinhome", "config.json"), "/etc/passwd"} {
		if got := run(p); !strings.HasPrefix(got, "ошибка:") || strings.Contains(got, "SECRET") || strings.Contains(got, "чужое") {
			t.Errorf("%s прочитался: %q", p, got)
		}
	}
}

func TestOnlyAllowedToolsExistForTheModel(t *testing.T) {
	s, _ := newSet(t, func(p *Policy) { p.Allowed = map[string]bool{"time": true} })
	if len(s.Defs()) != 1 || s.Defs()[0].Function.Name != "time" {
		t.Fatalf("модель видит лишнее: %d", len(s.Defs()))
	}
	if got := s.Exec(context.Background(), &Turn{}, "shell", `{"command":"echo hi"}`, yes); !strings.HasPrefix(got, "отказ") {
		t.Fatalf("выключенный инструмент выполнился: %q", got)
	}
	s2, _ := newSet(t, func(p *Policy) { p.Shell = "never" })
	for _, d := range s2.Defs() {
		if d.Function.Name == "shell" {
			t.Fatal("при shell=never модель не должна даже знать про shell (и тратить на него токены)")
		}
	}
}

func TestShellIsCheckedByCodeNotByTheModel(t *testing.T) {
	s, _ := newSet(t, func(p *Policy) { p.MaxCommand = 20; p.MaxDangerous = 2 })
	ctx := context.Background()
	turn := &Turn{}
	asked := ""
	ask := func(d string) bool { asked = d; return true }
	if got := s.Exec(ctx, turn, "shell", `{"command":"echo `+strings.Repeat("a", 50)+`"}`, ask); !strings.HasPrefix(got, "отказ") || asked != "" {
		t.Fatalf("слишком длинная команда дошла до вопроса или выполнилась: %q", got)
	}
	if got := s.Exec(ctx, turn, "shell", `{"command":"   "}`, ask); !strings.HasPrefix(got, "отказ") {
		t.Fatal("пустая команда")
	}
	if got := s.Exec(ctx, turn, "shell", `{"command":"echo one"}`, ask); strings.TrimSpace(got) != "one" || !strings.Contains(asked, "echo one") {
		t.Fatalf("команда выполнена не так, как показана владельцу: %q / %q", got, asked)
	}
	s.Exec(ctx, turn, "shell", `{"command":"echo two"}`, ask)
	if got := s.Exec(ctx, turn, "shell", `{"command":"echo 3"}`, ask); !strings.HasPrefix(got, "отказ") {
		t.Fatal("лимит опасных действий за ход не работает")
	}
	if got := s.Exec(ctx, &Turn{}, "shell", `{"command":"echo x"}`, nil); !strings.HasPrefix(got, "отказ") {
		t.Fatal("если спросить некого, опасное не выполняется")
	}
	if got := s.Exec(ctx, &Turn{}, "shell", `не json`, ask); !strings.HasPrefix(got, "отказ") {
		t.Fatal("мусорные аргументы")
	}
}

func TestShellTimeoutStopsALongCommand(t *testing.T) {
	s, _ := newSet(t, func(p *Policy) { p.Shell = "always"; p.ShellTimeout = 300 * 1000 * 1000 })
	got := s.Exec(context.Background(), &Turn{}, "shell", `{"command":"sleep 5; echo late"}`, nil)
	if !strings.Contains(got, "таймаут") || strings.Contains(got, "late") {
		t.Fatalf("команда не остановлена: %q", got)
	}
}

func TestMemoryToolsRememberRecallAndForgetByNumber(t *testing.T) {
	s, _ := newSet(t, nil)
	ctx := context.Background()
	if got := s.Exec(ctx, &Turn{}, "remember", `{"fact":"хозяин любит ромашковый чай"}`, nil); !strings.Contains(got, "№1") {
		t.Fatal(got)
	}
	if got := s.Exec(ctx, &Turn{}, "recall", `{"query":"какой чай"}`, nil); !strings.Contains(got, "№1: хозяин любит") {
		t.Fatal(got)
	}
	s.Exec(ctx, &Turn{}, "forget", `{"id":1}`, nil)
	if got := s.Exec(ctx, &Turn{}, "recall", `{"query":"чай"}`, nil); !strings.Contains(got, "ничего") {
		t.Fatal(got)
	}
}
