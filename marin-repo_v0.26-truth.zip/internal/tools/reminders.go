package tools

// Напоминания: «напомни через час», «в пятницу в 18:00». Хранятся в файле, срабатывают из планировщика (пакет initiative).

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
	_ "time/tzdata" // часовые пояса есть и на минимальных системах
)

type Reminder struct {
	ID   int       `json:"id"`
	At   time.Time `json:"at"`
	Text string    `json:"text"`
}

type Reminders struct {
	mu   sync.Mutex
	path string
	Loc  *time.Location
	Now  func() time.Time
	list []Reminder
	next int
}

// NewReminders открывает (или создаёт) хранилище; tz пустой: Asia/Bishkek.
func NewReminders(path, tz string) *Reminders {
	if tz == "" {
		tz = "Asia/Bishkek"
	}
	loc, err := time.LoadLocation(tz)
	if err != nil {
		loc = time.UTC
	}
	r := &Reminders{path: path, Loc: loc, Now: time.Now, next: 1}
	if b, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(b, &r.list)
	}
	for _, x := range r.list {
		if x.ID >= r.next {
			r.next = x.ID + 1
		}
	}
	return r
}

func (r *Reminders) save() {
	b, _ := json.MarshalIndent(r.list, "", " ")
	tmp := r.path + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, r.path)
	}
}

func (r *Reminders) Add(at time.Time, text string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	id := r.next
	r.next++
	r.list = append(r.list, Reminder{ID: id, At: at, Text: text})
	sort.Slice(r.list, func(i, j int) bool { return r.list[i].At.Before(r.list[j].At) })
	r.save()
	return id
}

func (r *Reminders) Cancel(id int) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i, x := range r.list {
		if x.ID == id {
			r.list = append(r.list[:i], r.list[i+1:]...)
			r.save()
			return true
		}
	}
	return false
}

// Due отдаёт и убирает сработавшие.
func (r *Reminders) Due() []Reminder {
	r.mu.Lock()
	defer r.mu.Unlock()
	var due, keep []Reminder
	now := r.Now()
	for _, x := range r.list {
		if !x.At.After(now) {
			due = append(due, x)
		} else {
			keep = append(keep, x)
		}
	}
	if len(due) > 0 {
		r.list = keep
		r.save()
	}
	return due
}

func (r *Reminders) List() []Reminder {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]Reminder(nil), r.list...)
}

// ParseWhen: in_minutes (через сколько) или at «2006-01-02 15:04» в часовом поясе хозяина.
func (r *Reminders) ParseWhen(inMin int64, at string) (time.Time, error) {
	now := r.Now()
	if inMin > 0 {
		if inMin > 60*24*365 {
			return time.Time{}, fmt.Errorf("слишком далеко")
		}
		return now.Add(time.Duration(inMin) * time.Minute), nil
	}
	at = strings.TrimSpace(at)
	if at == "" {
		return time.Time{}, fmt.Errorf("нужен in_minutes или at (ГГГГ-ММ-ДД ЧЧ:ММ)")
	}
	t, err := time.ParseInLocation("2006-01-02 15:04", at, r.Loc)
	if err != nil {
		return time.Time{}, fmt.Errorf("at должен быть в виде 2006-01-02 15:04")
	}
	if t.Before(now) {
		return time.Time{}, fmt.Errorf("это время уже прошло (сейчас %s)", now.In(r.Loc).Format("2006-01-02 15:04"))
	}
	return t, nil
}

// Add добавляет инструменты в набор.
func (s *Set) Add(t Tool) { s.list = append(s.list, t) }

// SetReminders подключает инструменты remind_add, remind_list, remind_cancel.
func (s *Set) SetReminders(r *Reminders) {
	s.Add(Tool{Name: "remind_add", Desc: "Поставить напоминание хозяину (в нужное время ты сама напишешь ему первой). Укажи in_minutes (через сколько минут) или at (дата и время по его часам: ГГГГ-ММ-ДД ЧЧ:ММ). Текущее время смотри в tool remind_list",
		Params: obj(map[string]any{"text": str("о чём напомнить"), "in_minutes": map[string]any{"type": "integer"}, "at": str("ГГГГ-ММ-ДД ЧЧ:ММ")}, "text"),
		Run: func(ctx context.Context, a map[string]any) (string, error) {
			t := strings.TrimSpace(argStr(a, "text"))
			if t == "" || len([]rune(t)) > 300 {
				return "", fmt.Errorf("нужен text до 300 символов")
			}
			when, err := r.ParseWhen(argInt(a, "in_minutes"), argStr(a, "at"))
			if err != nil {
				return "", err
			}
			id := r.Add(when, t)
			return fmt.Sprintf("напоминание №%d на %s", id, when.In(r.Loc).Format("2006-01-02 15:04")), nil
		}})
	s.Add(Tool{Name: "remind_list", Desc: "Показать текущее время хозяина и все ожидающие напоминания", Params: obj(map[string]any{}),
		Run: func(ctx context.Context, a map[string]any) (string, error) {
			out := "сейчас " + r.Now().In(r.Loc).Format("2006-01-02 15:04 Mon") + "\\n"
			out = strings.ReplaceAll(out, "\\n", "\n")
			for _, x := range r.List() {
				out += fmt.Sprintf("№%d | %s | %s\n", x.ID, x.At.In(r.Loc).Format("2006-01-02 15:04"), x.Text)
			}
			return out, nil
		}})
	s.Add(Tool{Name: "remind_cancel", Desc: "Отменить напоминание по номеру", Params: obj(map[string]any{"id": map[string]any{"type": "integer"}}, "id"),
		Run: func(ctx context.Context, a map[string]any) (string, error) {
			if !r.Cancel(int(argInt(a, "id"))) {
				return "", fmt.Errorf("такого напоминания нет")
			}
			return "отменила", nil
		}})
}
