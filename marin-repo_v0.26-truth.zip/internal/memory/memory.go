// Package memory: долгая память Рейны. Журнал JSONL только дописывается (добавление факта не переписывает файл),
// удаление и правка записываются как новые строки, файл сжимается при открытии. Поиск по словам без модели (ноль токенов).
// Store описан интерфейсом: позже его можно заменить на SQLite, не трогая агента.
package memory

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"
)

// Store: что нужно агенту и инструментам от памяти.
type Store interface {
	Add(text, source string, ttlDays int) (id int64, added bool)
	Update(id int64, text string) bool
	Delete(id int64) bool
	Search(q string, k int) []Fact
	List(limit int) []Fact
	Len() int
	Version() int64 // растёт при любом изменении (ключ кэша ответов учитывает его)
}

type Fact struct {
	ID      int64  `json:"id"`
	T       int64  `json:"t"`
	Text    string `json:"text"`
	Source  string `json:"source,omitempty"`  // откуда: user, tool, ...
	Expires int64  `json:"expires,omitempty"` // 0 = бессрочно
}

type rec struct {
	Op string `json:"op"` // add | del | upd
	Fact
}

type File struct {
	mu      sync.Mutex
	path    string
	facts   map[int64]Fact
	next    int64
	version int64
	Now     func() time.Time
}

const MaxFacts = 2000

func Open(home string) *File {
	s := &File{path: filepath.Join(home, "memory.jsonl"), facts: map[int64]Fact{}, next: 1, Now: time.Now}
	f, err := os.Open(s.path)
	if err != nil {
		return s
	}
	lines := 0
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		var r rec
		if json.Unmarshal(sc.Bytes(), &r) != nil {
			continue
		}
		lines++
		switch {
		case r.Op == "del":
			delete(s.facts, r.ID)
		case r.Op == "upd":
			if old, ok := s.facts[r.ID]; ok {
				old.Text = r.Text
				s.facts[r.ID] = old
			}
		case r.Text != "": // add; строки старого формата без op тоже читаются
			if r.ID == 0 {
				r.ID = s.next
			}
			s.facts[r.ID] = r.Fact
		}
		if r.ID >= s.next {
			s.next = r.ID + 1
		}
	}
	f.Close()
	if lines > 2*len(s.facts)+50 {
		s.compact()
	}
	return s
}

func (s *File) live(f Fact) bool { return f.Expires == 0 || f.Expires > s.Now().Unix() }

func (s *File) append(r rec) {
	f, err := os.OpenFile(s.path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	b, _ := json.Marshal(r)
	f.Write(append(b, '\n'))
	s.version++
}

// compact переписывает журнал в виде только живых фактов (редко: при открытии, если мусора много).
func (s *File) compact() {
	var sb strings.Builder
	for _, f := range s.sorted() {
		b, _ := json.Marshal(rec{Op: "add", Fact: f})
		sb.Write(b)
		sb.WriteByte('\n')
	}
	_ = os.WriteFile(s.path+".tmp", []byte(sb.String()), 0o600)
	_ = os.Rename(s.path+".tmp", s.path)
}

func (s *File) sorted() []Fact {
	out := make([]Fact, 0, len(s.facts))
	for _, f := range s.facts {
		if s.live(f) {
			out = append(out, f)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func clip(t string) string {
	t = strings.TrimSpace(t)
	if r := []rune(t); len(r) > 400 {
		return string(r[:400])
	}
	return t
}

func (s *File) Add(text, source string, ttlDays int) (int64, bool) {
	text = clip(text)
	if text == "" {
		return 0, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, f := range s.facts {
		if f.Text == text && s.live(f) {
			return f.ID, false
		}
	}
	if len(s.facts) >= MaxFacts { // место кончилось: уходит самый старый
		old := s.sorted()
		if len(old) > 0 {
			delete(s.facts, old[0].ID)
			s.append(rec{Op: "del", Fact: Fact{ID: old[0].ID}})
		}
	}
	f := Fact{ID: s.next, T: s.Now().Unix(), Text: text, Source: source}
	if ttlDays > 0 {
		f.Expires = s.Now().AddDate(0, 0, ttlDays).Unix()
	}
	s.next++
	s.facts[f.ID] = f
	s.append(rec{Op: "add", Fact: f})
	return f.ID, true
}

func (s *File) Update(id int64, text string) bool {
	text = clip(text)
	s.mu.Lock()
	defer s.mu.Unlock()
	f, ok := s.facts[id]
	if !ok || text == "" {
		return false
	}
	f.Text = text
	s.facts[id] = f
	s.append(rec{Op: "upd", Fact: Fact{ID: id, Text: text}})
	return true
}

func (s *File) Delete(id int64) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.facts[id]; !ok {
		return false
	}
	delete(s.facts, id)
	s.append(rec{Op: "del", Fact: Fact{ID: id}})
	return true
}

func (s *File) Len() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.sorted()) }

func (s *File) Version() int64 { s.mu.Lock(); defer s.mu.Unlock(); return s.version }

func (s *File) List(limit int) []Fact {
	s.mu.Lock()
	defer s.mu.Unlock()
	all := s.sorted()
	if limit > 0 && len(all) > limit {
		all = all[len(all)-limit:]
	}
	return all
}

func words(t string) map[string]bool {
	m := map[string]bool{}
	for _, w := range strings.FieldsFunc(strings.ToLower(t), func(r rune) bool { return !unicode.IsLetter(r) && !unicode.IsDigit(r) }) {
		r := []rune(w)
		if len(r) >= 3 {
			if len(r) > 5 {
				r = r[:5] // грубая основа: «ткань», «ткани», «тканью» совпадают
			}
			m[string(r)] = true
		}
	}
	return m
}

// Search возвращает до k самых подходящих фактов; без совпадений по словам не возвращает ничего.
func (s *File) Search(q string, k int) []Fact {
	qw := words(q)
	s.mu.Lock()
	defer s.mu.Unlock()
	type sc struct {
		f Fact
		n int
	}
	var hits []sc
	for _, f := range s.sorted() {
		n := 0
		for w := range words(f.Text) {
			if qw[w] {
				n++
			}
		}
		if n > 0 {
			hits = append(hits, sc{f, n})
		}
	}
	sort.Slice(hits, func(a, b int) bool {
		if hits[a].n != hits[b].n {
			return hits[a].n > hits[b].n
		}
		return hits[a].f.ID > hits[b].f.ID
	})
	var out []Fact
	for _, h := range hits {
		if len(out) >= k {
			break
		}
		out = append(out, h.f)
	}
	return out
}
