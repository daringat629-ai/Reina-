package telegram

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"sync"
	"time"
)

// BotAPI: транспорт «бот» (токен от BotFather), long polling, только стандартная библиотека.
type BotAPI struct {
	Token string
	API   string
	HTTP  *http.Client

	mu     sync.Mutex
	lastOK time.Time
}

func NewBotAPI(token string) *BotAPI {
	api := os.Getenv("REINA_TG_API")
	if api == "" {
		api = "https://api.telegram.org"
	}
	return &BotAPI{Token: token, API: api, HTTP: &http.Client{Timeout: 70 * time.Second}, lastOK: time.Now()}
}

func (t *BotAPI) Send(chat int64, text string) error {
	body, _ := json.Marshal(map[string]any{"chat_id": chat, "text": text})
	resp, err := t.HTTP.Post(fmt.Sprintf("%s/bot%s/sendMessage", t.API, t.Token), "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != 200 {
		return fmt.Errorf("sendMessage: %d", resp.StatusCode)
	}
	return nil
}

// Health: долгая тишина при живом цикле (больше 3 минут без успешного опроса) считается зависанием.
func (t *BotAPI) Health() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if time.Since(t.lastOK) > 3*time.Minute {
		return fmt.Errorf("Telegram не отвечает уже %s", time.Since(t.lastOK).Round(time.Second))
	}
	return nil
}

type update struct {
	UpdateID int `json:"update_id"`
	Message  *struct {
		Text    string `json:"text"`
		Caption string `json:"caption"`
		Photo   []struct {
			FileID string `json:"file_id"`
			Size   int    `json:"file_size"`
		} `json:"photo"`
		Chat struct {
			ID   int64  `json:"id"`
			Type string `json:"type"`
		} `json:"chat"`
	} `json:"message"`
}

// download скачивает файл по file_id (Bot API: getFile, потом файл по адресу).
func (t *BotAPI) download(ctx context.Context, fileID string) ([]byte, error) {
	req, _ := http.NewRequestWithContext(ctx, "GET", fmt.Sprintf("%s/bot%s/getFile?file_id=%s", t.API, t.Token, url.QueryEscape(fileID)), nil)
	resp, err := t.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	var gf struct {
		Result struct {
			Path string `json:"file_path"`
		} `json:"result"`
	}
	err = json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&gf)
	resp.Body.Close()
	if err != nil || gf.Result.Path == "" {
		return nil, fmt.Errorf("getFile не вернул путь")
	}
	req, _ = http.NewRequestWithContext(ctx, "GET", fmt.Sprintf("%s/file/bot%s/%s", t.API, t.Token, gf.Result.Path), nil)
	resp, err = t.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("скачивание: %d", resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 9<<20))
}

func (t *BotAPI) Run(ctx context.Context, in func(Incoming)) error {
	offset := 0
	for ctx.Err() == nil {
		var res struct {
			Result []update `json:"result"`
		}
		q := url.Values{"timeout": {"50"}, "offset": {fmt.Sprint(offset)}}
		req, _ := http.NewRequestWithContext(ctx, "GET", fmt.Sprintf("%s/bot%s/getUpdates?%s", t.API, t.Token, q.Encode()), nil)
		resp, err := t.HTTP.Do(req)
		if err == nil {
			data, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
			resp.Body.Close()
			if resp.StatusCode != 200 {
				err = fmt.Errorf("getUpdates: %d", resp.StatusCode)
			} else {
				err = json.Unmarshal(data, &res)
			}
		}
		if err != nil {
			if ctx.Err() == nil {
				log.Printf("telegram: %v", err)
			}
			select {
			case <-time.After(5 * time.Second):
			case <-ctx.Done():
			}
			continue
		}
		t.mu.Lock()
		t.lastOK = time.Now()
		t.mu.Unlock()
		for _, u := range res.Result {
			offset = u.UpdateID + 1
			m := u.Message
			if m == nil || (m.Chat.Type != "private" && m.Chat.Type != "") {
				continue
			}
			if len(m.Photo) > 0 { // последний размер в списке самый большой
				img, err := t.download(ctx, m.Photo[len(m.Photo)-1].FileID)
				if err != nil {
					log.Printf("telegram: фото не скачалось: %v", err)
					continue
				}
				in(Incoming{Chat: m.Chat.ID, Text: m.Caption, Image: img, Mime: "image/jpeg"})
			} else if m.Text != "" {
				in(Incoming{Chat: m.Chat.ID, Text: m.Text})
			}
		}
	}
	return nil
}
