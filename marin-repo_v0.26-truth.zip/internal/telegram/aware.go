package telegram

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"reina/internal/agent"
)

// Lister: транспорт умеет показать список чатов и последние сообщения (аккаунт умеет, бот нет).
type Lister interface {
	Chats(ctx context.Context, query string, limit int) (string, error)
	History(ctx context.Context, chat int64, limit int) (string, error)
}

type awEntry struct {
	text string
	at   time.Time
}

var (
	awMu    sync.Mutex
	awCache = map[string]awEntry{}
)

// awCached: результат fn не чаще раза в ttl (ошибки не кэшируются).
func awCached(key string, ttl time.Duration, fn func() (string, error)) string {
	awMu.Lock()
	e, ok := awCache[key]
	awMu.Unlock()
	if ok && time.Since(e.at) < ttl {
		return e.text
	}
	t, err := fn()
	if err != nil {
		return e.text // старое лучше, чем ничего
	}
	awMu.Lock()
	awCache[key] = awEntry{t, time.Now()}
	awMu.Unlock()
	return t
}

type awRow struct {
	id     int64
	kind   string
	name   string
	unread int
}

func parseRows(list string) []awRow {
	var out []awRow
	for _, ln := range strings.Split(list, "\n") {
		p := strings.Split(ln, " | ")
		if len(p) < 3 {
			continue
		}
		id, err := strconv.ParseInt(strings.TrimSpace(p[0]), 10, 64)
		if err != nil {
			continue
		}
		r := awRow{id: id, kind: strings.TrimSpace(p[1]), name: strings.TrimSpace(p[2])}
		if i := strings.LastIndex(ln, "непрочитано:"); i >= 0 {
			r.unread, _ = strconv.Atoi(strings.TrimSpace(ln[i+len("непрочитано:"):]))
		}
		out = append(out, r)
	}
	return out
}

func hasAny(l string, w ...string) bool {
	for _, x := range w {
		if strings.Contains(l, x) {
			return true
		}
	}
	return false
}

// aware собирает для неё картину происходящего перед ответом (в историю разговора она не попадает). Она одна на все чаты:
//   - в группе: последние сообщения этой группы; если пишет хозяин, ещё и что было у них в личке;
//   - у хозяина: реальный список её чатов, что было в других чатах, и содержимое названного чата или самых живых групп.
//
// Посторонним (в том числе в группе) ничего из личных разговоров и списка чатов хозяина не отдаётся.
func (b *Bot) aware(ctx context.Context, session, text string, owner bool) string {
	if !strings.HasPrefix(session, "tg:") {
		return ""
	}
	chat, err := strconv.ParseInt(strings.TrimPrefix(session, "tg:"), 10, 64)
	if err != nil {
		return ""
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	ownSession := fmt.Sprintf("tg:%d", b.OwnerID)
	l, hasList := b.tr.(Lister)
	var sb strings.Builder
	if chat < 0 && hasList {
		if h := awCached(fmt.Sprintf("h:%d", chat), 20*time.Second, func() (string, error) { return l.History(ctx, chat, 15) }); strings.TrimSpace(h) != "" && h != "сообщений нет" {
			sb.WriteString("Что сейчас происходит в этой группе (последние сообщения, старые сверху, формат: id | время | кто | текст; «я» это ты). Прежде чем отвечать, пойми, о чём идёт разговор и кто с кем; не выдумывай того, чего здесь не писали:\n" + h + "\n")
		}
	}
	if chat < 0 && agent.IsOwnerSender(ctx) { // хозяин пишет в группе: она помнит, о чём они говорили в личке
		if r := b.Agent.Recent(ownSession, 10); r != "" {
			sb.WriteString("\nЧто было у тебя с хозяином в личке перед этим (в личке «собеседник» это он; ты одна и та же Рейна, помни это; при всех не пересказывай, но учитывай):\n" + r)
		}
	}
	if !owner {
		return sb.String()
	}
	names := map[int64]string{}
	var rows []awRow
	if hasList {
		list := awCached("chats", 5*time.Minute, func() (string, error) { return l.Chats(ctx, "", 20) })
		if strings.TrimSpace(list) != "" {
			sb.WriteString("Твои настоящие чаты в Telegram (id | тип | название | @ник | участников | непрочитано). Других чатов и групп у тебя нет: названия не выдумывай. Если спрашивают про чат, которого тут нет или про который не знаешь деталей, скажи честно или посмотри через tg_chats/tg_history:\n" + list + "\n")
			rows = parseRows(list)
			for _, r := range rows {
				names[r.id] = r.name
			}
		}
	}
	// что было в других чатах за сутки: она не забывает ни группы, ни другие лички, пока говорит с хозяином
	if others := b.Agent.RecentOthers(session, 24*time.Hour, 6, 4); len(others) > 0 {
		sb.WriteString("\nЧто было у тебя в других чатах за последнее время (ты одна Рейна на все чаты, помни это и можешь ссылаться, если к месту):\n")
		for _, o := range others {
			title := o.ID
			if id, err := strconv.ParseInt(strings.TrimPrefix(o.ID, "tg:"), 10, 64); err == nil {
				if n := names[id]; n != "" {
					title = n
				} else if id < 0 {
					title = "группа " + o.ID
				} else {
					title = "личка " + o.ID
				}
			}
			sb.WriteString("— " + title + ":\n" + o.Text)
		}
	}
	if !hasList {
		return sb.String()
	}
	lt := strings.ToLower(text)
	shown := map[int64]bool{chat: true}
	add := func(r awRow, n int) {
		if shown[r.id] {
			return
		}
		shown[r.id] = true
		if h := awCached(fmt.Sprintf("h:%d", r.id), 60*time.Second, func() (string, error) { return l.History(ctx, r.id, n) }); strings.TrimSpace(h) != "" && h != "сообщений нет" {
			sb.WriteString(fmt.Sprintf("\nПоследние сообщения чата «%s» (старые сверху):\n%s", r.name, h))
		}
	}
	named := 0
	for _, r := range rows { // он назвал чат: показываем, что там
		if n := strings.ToLower(r.name); len([]rune(n)) >= 3 && strings.Contains(lt, n) && named < 2 {
			add(r, 12)
			named++
		}
	}
	if named == 0 && hasAny(lt, "групп", "чат", "что там", "что в ", "что нового", "канал", "переписк") { // спрашивает вообще: самые живые группы
		k := 0
		for _, r := range rows {
			if r.kind != "лс" && r.kind != "канал" && r.unread > 0 && k < 3 {
				add(r, 8)
				k++
			}
		}
	}
	return sb.String()
}

// ChatTitle: название чата по его сессии «tg:id» (для панели); пусто, если не нашлось.
func (b *Bot) ChatTitle(session string) string {
	l, ok := b.tr.(Lister)
	if !ok || !strings.HasPrefix(session, "tg:") {
		return ""
	}
	id, err := strconv.ParseInt(strings.TrimPrefix(session, "tg:"), 10, 64)
	if err != nil {
		return ""
	}
	ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second)
	defer cancel()
	list := awCached("chats60", 5*time.Minute, func() (string, error) { return l.Chats(ctx, "", 60) })
	for _, r := range parseRows(list) {
		if r.id == id {
			return r.name
		}
	}
	return ""
}
