//go:build tguser

package telegram

// Возможности аккаунта сверх «получить и ответить»: две галочки, «печатает…», реакции, стикеры, письма другим людям, поиск чатов.

import (
	"context"
	"fmt"
	"log"
	mrand "math/rand"
	"strconv"
	"strings"
	"time"

	"github.com/gotd/td/tg"
)

// dialogUsers читает последние диалоги, запоминает адреса собеседников, групп и каналов и возвращает людей.
// Список всех чатов (с типом, числом участников и непрочитанными) остаётся в u.rows.
func (u *User) dialogUsers(ctx context.Context) ([]*tg.User, error) {
	u.mu.Lock()
	api := u.api
	u.mu.Unlock()
	if api == nil {
		return nil, fmt.Errorf("Telegram ещё не подключён")
	}
	res, err := api.MessagesGetDialogs(ctx, &tg.MessagesGetDialogsRequest{OffsetPeer: &tg.InputPeerEmpty{}, Limit: 100})
	if err != nil {
		return nil, err
	}
	us, rows := u.absorb(res)
	u.mu.Lock()
	u.rows = rows
	u.mu.Unlock()
	return us, nil
}

// peerFor возвращает адрес собеседника; если его ещё нет, подтягивает из списка диалогов.
func (u *User) peerFor(ctx context.Context, chat int64) (tg.InputPeerClass, error) {
	u.mu.Lock()
	p := u.peers[chat]
	u.mu.Unlock()
	if p == nil {
		u.refresh(ctx)
		u.mu.Lock()
		p = u.peers[chat]
		u.mu.Unlock()
	}
	if p == nil {
		return nil, fmt.Errorf("собеседник %d неизвестен: пусть сначала напишет", chat)
	}
	return p, nil
}

func (u *User) apiCtx() (*tg.Client, context.Context) {
	u.mu.Lock()
	defer u.mu.Unlock()
	return u.api, u.runCtx
}

// MarkRead: две галочки у собеседника, с небольшой человеческой задержкой.
func (u *User) MarkRead(chat int64, msgID int) {
	api, ctx := u.apiCtx()
	if api == nil || ctx == nil {
		return
	}
	time.Sleep(time.Duration(500+mrand.Intn(900)) * time.Millisecond)
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return
	}
	if _, err := api.MessagesReadHistory(ctx, &tg.MessagesReadHistoryRequest{Peer: p, MaxID: msgID}); err != nil {
		log.Printf("telegram: не отметила прочитанным: %v", err)
	}
}

// Typing показывает «печатает…».
func (u *User) Typing(chat int64) {
	api, ctx := u.apiCtx()
	if api == nil || ctx == nil {
		return
	}
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return
	}
	if _, err := api.MessagesSetTyping(ctx, &tg.MessagesSetTypingRequest{Peer: p, Action: &tg.SendMessageTypingAction{}}); err != nil {
		log.Printf("telegram: «печатает» не вышло: %v", err)
	}
}

func userName(x *tg.User) string {
	n := strings.TrimSpace(x.FirstName + " " + x.LastName)
	if n == "" {
		n = x.Username
	}
	return n
}

// SendText пишет другому человеку: числовой id, @username или часть имени из недавних диалогов.
func (u *User) SendText(ctx context.Context, target, text string) error {
	u.mu.Lock()
	sender := u.sender
	u.mu.Unlock()
	if sender == nil {
		return fmt.Errorf("Telegram ещё не подключён")
	}
	target = strings.TrimSpace(target)
	if id, err := strconv.ParseInt(target, 10, 64); err == nil {
		p, err := u.peerFor(ctx, id)
		if err != nil {
			return err
		}
		_, err = sender.To(p).Text(ctx, text)
		return err
	}
	if strings.HasPrefix(target, "@") {
		_, err := sender.Resolve(strings.TrimPrefix(target, "@")).Text(ctx, text)
		return err
	}
	us, err := u.dialogUsers(ctx)
	if err != nil {
		return err
	}
	var found []*tg.User
	for _, x := range us {
		if !x.Bot && !x.Self && strings.Contains(strings.ToLower(userName(x)), strings.ToLower(target)) {
			found = append(found, x)
		}
	}
	if len(found) != 1 {
		return fmt.Errorf("по имени %q найдено %d, нужен ровно один: уточни через tg_chats", target, len(found))
	}
	_, err = sender.To(found[0].AsInputPeer()).Text(ctx, text)
	return err
}

// React ставит реакцию на сообщение собеседника.
func (u *User) React(ctx context.Context, chat int64, msgID int, emoji string) error {
	api, _ := u.apiCtx()
	if api == nil {
		return fmt.Errorf("Telegram ещё не подключён")
	}
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return err
	}
	_, err = api.MessagesSendReaction(ctx, &tg.MessagesSendReactionRequest{Peer: p, MsgID: msgID, Reaction: []tg.ReactionClass{&tg.ReactionEmoji{Emoticon: emoji}}})
	return err
}

// loadStickers собирает стикеры из установленных наборов (до 8 наборов), кэш на час.
func (u *User) loadStickers(ctx context.Context) (map[string][]*tg.Document, error) {
	u.mu.Lock()
	if u.stk != nil && time.Since(u.stkAt) < time.Hour {
		m := u.stk
		u.mu.Unlock()
		return m, nil
	}
	api := u.api
	u.mu.Unlock()
	if api == nil {
		return nil, fmt.Errorf("Telegram ещё не подключён")
	}
	all, err := api.MessagesGetAllStickers(ctx, 0)
	if err != nil {
		return nil, err
	}
	sets, ok := all.(*tg.MessagesAllStickers)
	if !ok || len(sets.Sets) == 0 {
		return nil, fmt.Errorf("на аккаунте нет установленных наборов стикеров: добавь любой набор в Telegram")
	}
	m := map[string][]*tg.Document{}
	for i, st := range sets.Sets {
		if i >= 8 {
			break
		}
		res, err := api.MessagesGetStickerSet(ctx, &tg.MessagesGetStickerSetRequest{Stickerset: &tg.InputStickerSetID{ID: st.ID, AccessHash: st.AccessHash}})
		if err != nil {
			continue
		}
		set, ok := res.(*tg.MessagesStickerSet)
		if !ok {
			continue
		}
		byID := map[int64]*tg.Document{}
		for _, dc := range set.Documents {
			if d, ok := dc.(*tg.Document); ok {
				byID[d.ID] = d
			}
		}
		for _, pk := range set.Packs {
			e := strings.ReplaceAll(pk.Emoticon, "️", "")
			for _, id := range pk.Documents {
				if d := byID[id]; d != nil {
					m[e] = append(m[e], d)
				}
			}
		}
	}
	if len(m) == 0 {
		return nil, fmt.Errorf("стикеры не загрузились")
	}
	u.mu.Lock()
	u.stk, u.stkAt = m, time.Now()
	u.mu.Unlock()
	return m, nil
}

func (u *User) StickerEmojis(ctx context.Context) (string, error) {
	m, err := u.loadStickers(ctx)
	if err != nil {
		return "", err
	}
	var sb strings.Builder
	for e, d := range m {
		fmt.Fprintf(&sb, "%s×%d ", e, len(d))
	}
	return strings.TrimSpace(sb.String()), nil
}

// SendSticker отправляет случайный стикер с нужным эмодзи.
func (u *User) SendSticker(ctx context.Context, chat int64, emoji string) error {
	m, err := u.loadStickers(ctx)
	if err != nil {
		return err
	}
	docs := m[strings.ReplaceAll(emoji, "️", "")]
	if len(docs) == 0 {
		return fmt.Errorf("стикера с %s нет; посмотри список через tg_sticker_list", emoji)
	}
	d := docs[mrand.Intn(len(docs))]
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return err
	}
	api, _ := u.apiCtx()
	_, err = api.MessagesSendMedia(ctx, &tg.MessagesSendMediaRequest{
		Peer:     p,
		Media:    &tg.InputMediaDocument{ID: &tg.InputDocument{ID: d.ID, AccessHash: d.AccessHash, FileReference: d.FileReference}},
		RandomID: mrand.Int63(),
	})
	return err
}
