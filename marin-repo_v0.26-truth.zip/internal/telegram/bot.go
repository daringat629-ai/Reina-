// Package telegram: общение с хозяином. Логика (кому отвечать, подтверждения, «занята», /usage, /reset) не зависит от способа входа:
// Transport бывает «бот» (Bot API, токен от BotFather) и «аккаунт» (обычный пользовательский аккаунт по номеру телефона, как у прежней версии на TDLib).
package telegram

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/events"
	"reina/internal/tools"
	selfupd "reina/internal/update"
	"reina/internal/voice"
)

// Transport доставляет входящие сообщения и отправляет ответы.
type Incoming struct {
	Chat      int64
	Text      string // текст или подпись к картинке
	Image     []byte // jpeg/png, если пришло фото
	Mime      string
	Voice     []byte // голосовое сообщение (ogg/opus), если пришло
	VoiceMime string
	MsgID     int    // номер сообщения (для «прочитано» и реакций), 0 если неизвестен
	Group     bool   // сообщение из группы
	From      string // имя автора в группе
	FromID    int64  // id автора в группе (по нему узнаём хозяина)
	Mentioned bool   // в группе: её упомянули или ответили ей
	Title     string // название группы
	File      []byte // присланный хозяином zip для /update
	FileName  string
}

// Reader умеют не все транспорты: «прочитано» (две галочки) и «печатает…».
type Reader interface {
	MarkRead(chat int64, msgID int)
	Typing(chat int64)
}

// Presence: статус «в сети» (умеет аккаунт, не бот).
type Presence interface{ SetOnline(online bool) }

// VoiceSender умеют не все транспорты: отправить голосовое сообщение.
type VoiceSender interface {
	SendVoice(ctx context.Context, chat int64, audio []byte, mime string, seconds int) error
}

type Transport interface {
	// Run работает до отмены ctx и вызывает in для каждого входящего личного сообщения (не своего).
	Run(ctx context.Context, in func(Incoming)) error
	Send(chat int64, text string) error
	Health() error
}

type Bot struct {
	tr      Transport
	allowed map[int64]bool // кому вообще отвечаем; остальным молчим
	OwnerID int64          // кому задаём вопросы про опасные действия
	Agent   *agent.Agent
	Ledger  *budget.Ledger

	mu      sync.Mutex
	pending chan bool // ждём «да/нет» на опасное действие
	busy    map[int64]bool

	Voice      *voice.Client // nil: голосовые выключены
	VoiceReply string        // mirror | always | never
	VoiceMax   int           // длиннее: отвечать текстом

	GroupNames    []string      // на какие имена откликается в группе
	ChimePct      int           // шанс вклиниться в группе без обращения, % (по умолчанию 6)
	GroupCool     time.Duration // пауза между её ответами в одной группе
	groupAt       map[int64]time.Time
	offlineT      *time.Timer
	offered       map[int64]time.Time // когда уже спрашивали хозяина про неразрешённую группу
	OnAllow       func(chat int64)    // сохранить разрешение (config.json)
	PanelURL      func() string       // текущая публичная ссылка на панель
	ResetPassword func() string       // сгенерировать новый пароль панели (старый перестаёт работать)
	lastIn        map[int64]time.Time // когда в чате последний раз писали ей

	OpenDM      bool                    // отвечать чужим в личке
	DMDailyMax  int                     // сообщений в сутки от одного чужого
	NotifyNewDM bool                    // сообщать хозяину о новом собеседнике
	OnBlock     func(id int64, on bool) // сохранить блокировку (config.json)
	OnSeen      func(id int64)          // запомнить, что о новом человеке хозяину уже сказали
	blocked     map[int64]bool
	seen        map[int64]bool
	dmDay       map[int64]*dmCount
	OnRestart   func()      // перед перезапуском: сохранить состояние
	Events      *events.Log // что с ней на самом деле происходило (nil: не пишется)
}

// LastIncoming: когда хозяин (или любой собеседник чата) писал ей в последний раз.
func (b *Bot) LastIncoming(chat int64) time.Time {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.lastIn[chat]
}

// Initiate: она сама пишет в чат (напоминание, «соскучилась»): prompt служебный, модель отвечает как обычно.
// ok=false: чат занят разговором или она решила промолчать (ответ SKIP).
func (b *Bot) Initiate(ctx context.Context, chat int64, prompt string) (sent bool) {
	b.mu.Lock()
	if b.busy[chat] {
		b.mu.Unlock()
		return false
	}
	b.busy[chat] = true
	b.mu.Unlock()
	defer func() {
		b.mu.Lock()
		b.busy[chat] = false
		b.lastIn[chat] = time.Now() // чтобы не писать подряд снова
		b.mu.Unlock()
	}()
	session := fmt.Sprintf("tg:%d", chat)
	ctx = tools.WithChat(ctx, chat, 0)
	ans, err := b.Agent.Reply(ctx, session, prompt)
	trim := strings.TrimSpace(ans)
	if err != nil || trim == "" || strings.HasPrefix(strings.ToUpper(trim), "SKIP") || strings.HasPrefix(trim, "(не вышло") {
		if err == nil {
			b.Agent.DropLast(session, 2)
		}
		return false
	}
	b.Events.Add("написала первой: «%s»", agent.Clip(trim, 80))
	rd, _ := b.tr.(Reader)
	if rd != nil {
		rd.Typing(chat)
	}
	select {
	case <-time.After(b.Agent.ThinkDelay()):
	case <-ctx.Done():
		return false
	}
	if tools.Spoke(ctx) {
		return true
	}
	if b.sendVoice(ctx, chat, ans, b.Agent.TakeVoice(session)) {
		return true
	}
	b.sendChunks(ctx, chat, ans, rd)
	return true
}

// SetGroups: имена и пауза для групп (группа должна быть в allowed_ids).
func (b *Bot) SetGroups(names []string, cool time.Duration, chimePct int) {
	if chimePct != 0 {
		if chimePct < 0 {
			chimePct = 0
		}
		b.ChimePct = chimePct
	}
	if len(names) > 0 {
		b.GroupNames = names
	}
	if cool > 0 {
		b.GroupCool = cool
	}
}

// addressed: обратились ли к ней в группе.
func (b *Bot) addressed(m Incoming) bool {
	if m.Mentioned {
		return true
	}
	t := strings.ToLower(m.Text)
	for _, n := range b.GroupNames {
		if n != "" && strings.Contains(t, strings.ToLower(n)) {
			return true
		}
	}
	return false
}

// SetVoice включает голосовые: распознавание входящих и озвучку ответов.
func (b *Bot) SetVoice(c *voice.Client, reply string, maxChars int) {
	b.Voice, b.VoiceReply, b.VoiceMax = c, reply, maxChars
}

func NewBot(tr Transport, owner int64, allowed []int64, a *agent.Agent, l *budget.Ledger) *Bot {
	b := &Bot{tr: tr, OwnerID: owner, allowed: map[int64]bool{owner: true}, Agent: a, Ledger: l, busy: map[int64]bool{}, groupAt: map[int64]time.Time{}, offered: map[int64]time.Time{}, lastIn: map[int64]time.Time{}, GroupNames: []string{"рейна", "рейн", "reina"}, GroupCool: 15 * time.Second, ChimePct: 6, OpenDM: true, DMDailyMax: 40, NotifyNewDM: true, blocked: map[int64]bool{}, seen: map[int64]bool{}, dmDay: map[int64]*dmCount{}}
	for _, id := range allowed {
		b.allowed[id] = true
	}
	a.Confirm = func(session, desc string) bool { return b.ask(desc) }
	a.Aware = b.aware
	return b
}

func (b *Bot) Send(chat int64, text string) {
	r := []rune(text)
	for len(r) > 0 { // лимит Telegram 4096
		n := len(r)
		if n > 4000 {
			n = 4000
		}
		if err := b.tr.Send(chat, string(r[:n])); err != nil {
			log.Printf("telegram: не отправилось: %v", err)
			return
		}
		r = r[n:]
	}
}

// ask спрашивает владельца и ждёт ответ до двух минут. Отвечать «да» может только он сам.
func (b *Bot) ask(desc string) bool {
	ch := make(chan bool, 1)
	b.mu.Lock()
	b.pending = ch
	b.mu.Unlock()
	b.Send(b.OwnerID, "Выполнить? "+desc+"\nОтветьте «да» или «нет».")
	defer func() { b.mu.Lock(); b.pending = nil; b.mu.Unlock() }()
	select {
	case v := <-ch:
		return v
	case <-time.After(2 * time.Minute):
		return false
	}
}

// Handle обрабатывает одно входящее сообщение. Отдельно от транспорта, чтобы тестировать.
func (b *Bot) Handle(ctx context.Context, chat int64, text string) {
	b.HandleIncoming(ctx, Incoming{Chat: chat, Text: text})
}

func (b *Bot) HandleIncoming(ctx context.Context, m Incoming) {
	chat, text := m.Chat, m.Text
	if len(m.File) > 0 { // обновление принимаем только от хозяина в личке
		if chat == b.OwnerID && !m.Group {
			go b.selfUpdate(chat, m)
		}
		return
	}
	if b.isBlocked(chat) {
		return
	}
	if !b.isAllowed(chat) {
		if m.Group {
			if b.addressed(m) {
				go b.offerGroup(ctx, m) // позвали в неизвестной группе: спрашиваем хозяина, а не молчим вслепую
			}
			return
		}
		if !b.OpenDM || !b.admitStranger(chat, m) {
			return // чужим не отвечаем: личка закрыта, или на сегодня лимит
		}
	}
	say := func(s string) {
		if !m.Group { // в группах об ошибках молчим
			b.Send(chat, s)
		}
	}
	chime := false // в группе вклинивается сама, к ней не обращались
	if m.Group {
		if len(m.Voice) > 0 {
			return
		}
		if !b.addressed(m) {
			if len(m.Image) > 0 || len(strings.TrimSpace(m.Text)) < 4 || rand.Intn(100) >= b.ChimePct {
				return
			}
			chime = true
		}
		b.mu.Lock()
		last := b.groupAt[chat]
		if time.Since(last) < b.GroupCool {
			b.mu.Unlock()
			return
		}
		b.groupAt[chat] = time.Now()
		b.mu.Unlock()
		if chime {
			text = "[в группе, пишет " + m.From + "; к тебе не обращались. Вклинивайся, только если тебе правда есть что сказать (смешно, близко, возмутило), коротко; иначе ответь одним словом SKIP] " + text
		} else {
			text = "[в группе, пишет " + m.From + "] " + text
		}
		m.Text = text
	}
	if r, ok := b.tr.(Reader); ok && m.MsgID > 0 && !m.Group {
		go r.MarkRead(chat, m.MsgID) // две галочки только тем, кому она отвечает
	}
	t := strings.ToLower(strings.TrimSpace(text))
	if len(m.Image) > 0 {
		t = "" // подпись к фото не считается командой или ответом «да»
	}
	if chat == b.OwnerID && !m.Group && len(m.Image) == 0 && len(m.Voice) == 0 {
		b.mu.Lock()
		p := b.pending
		b.mu.Unlock()
		if p != nil {
			select {
			case p <- (t == "да" || t == "yes" || t == "y" || t == "ок"):
			default:
			}
			return
		}
	}
	b.mu.Lock()
	b.lastIn[chat] = time.Now()
	b.mu.Unlock()
	b.goOnline()
	session := fmt.Sprintf("tg:%d", chat)
	switch {
	case t == "/start":
		say("Привет! Я Рейна. Пиши как обычно. /usage покажет расходы.")
		return
	case t == "/reset":
		b.Agent.Reset(session)
		say("Разговор забыла, долгая память осталась.")
		return
	case t == "/usage" && (chat == b.OwnerID || b.isAllowed(chat)):
		d := b.Ledger.Today()
		say(fmt.Sprintf("Сегодня: запросов %d, токенов %d вход / %d выход, $%.4f, ответов из памяти без запроса: %d.", d.Requests, d.Prompt, d.Completion, d.USD, d.Saved))
		return
	case chat == b.OwnerID && !m.Group && strings.HasPrefix(t, "/") && b.ownerCommand(ctx, chat, strings.TrimSpace(text)):
		return
	}
	b.mu.Lock()
	if b.busy[chat] {
		b.mu.Unlock()
		say("Секунду, ещё отвечаю на прошлое.")
		return
	}
	b.busy[chat] = true
	b.mu.Unlock()
	go func() {
		defer func() {
			if r := recover(); r != nil { // одна ошибка не роняет бота
				log.Printf("паника в обработчике: %v", r)
				say("Что-то сломалось внутри, но я жива. Попробуй ещё раз.")
			}
			b.mu.Lock()
			b.busy[chat] = false
			b.mu.Unlock()
		}()
		cctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		defer cancel()
		cctx = tools.WithChat(cctx, chat, m.MsgID)
		if m.Group && m.FromID != 0 && m.FromID == b.OwnerID {
			cctx = agent.WithOwnerSender(cctx) // в группе пишет хозяин: она его узнаёт и помнит личку
		}
		askVoice := asksVoice(text)
		if askVoice && b.Voice != nil && !m.Group {
			text += " [служебное: просят голосовое. Твой ответ уйдёт голосом: напиши сразу то, что скажешь вслух, живой речью, без «держи» и без описания действий]"
		}
		rd, _ := b.tr.(Reader)
		heardVoice := false
		if len(m.Voice) > 0 {
			if b.Voice == nil {
				say("Голосовое получила, но распознавание не настроено. На сервере: ./reina voice <ключ ElevenLabs> <voice_id>")
				return
			}
			tx, terr := b.Voice.Transcribe(cctx, m.Voice, m.VoiceMime)
			if terr != nil || tx == "" {
				log.Printf("голосовое не распозналось: %v", terr)
				say("Не разобрала голосовое, напиши текстом или запиши ещё раз.")
				return
			}
			text, heardVoice = "[голосовое сообщение] "+tx, true
		}
		if len(m.Image) > 8<<20 {
			say("Картинка слишком большая (больше 8 МБ).")
			return
		}
		type result struct {
			ans string
			err error
		}
		done := make(chan result, 1)
		go func() { // мысли и ответ готовятся сразу, а «печатает…» появится позже
			var r result
			defer func() {
				if p := recover(); p != nil { // паника в ответе не роняет процесс
					log.Printf("паника в ответе: %v", p)
					r.err = fmt.Errorf("внутренняя ошибка")
				}
				done <- r
			}()
			if len(m.Image) > 0 {
				r.ans, r.err = b.Agent.ReplyImage(cctx, session, text, "data:"+m.Mime+";base64,"+base64.StdEncoding.EncodeToString(m.Image))
			} else {
				r.ans, r.err = b.Agent.Reply(cctx, session, text)
			}
		}()
		// сначала «прочитала и думает»: 3-4 секунды без «печатает…»
		select {
		case <-time.After(b.Agent.ThinkDelay()):
		case <-cctx.Done():
		}
		typingSince := time.Now()
		var res result
		for got := false; !got; {
			if rd != nil && !chime {
				rd.Typing(chat)
			}
			select {
			case res = <-done:
				got = true
			case <-time.After(4 * time.Second): // «печатает…» живёт около 5 секунд, обновляем
			case <-cctx.Done():
				say("Не получилось: слишком долго думала.")
				return
			}
		}
		ans, err := res.ans, res.err
		if chime {
			tr := strings.TrimSpace(ans)
			if err != nil || tr == "" || strings.HasPrefix(strings.ToUpper(tr), "SKIP") || strings.HasPrefix(tr, "(не вышло") {
				if err == nil {
					b.Agent.DropLast(session, 2)
				}
				return
			}
		}
		if err != nil {
			say("Не получилось: " + err.Error())
			return
		}
		// не мгновенно: «печатает…» по длине ответа, за вычетом уже напечатанного
		if rd != nil {
			for d := b.Agent.Pace(ans, time.Since(typingSince)); d > 0; d = b.Agent.Pace(ans, time.Since(typingSince)) {
				rd.Typing(chat)
				if d > 4*time.Second {
					d = 4 * time.Second
				}
				select {
				case <-time.After(d):
				case <-cctx.Done():
					d = 0
				}
				if cctx.Err() != nil {
					break
				}
			}
		}
		if tools.Spoke(cctx) { // она уже ответила голосовым через tg_voice: текстом не дублируем
			b.spontaneous(cctx, session, chat, m.MsgID)
			return
		}
		if b.sendVoice(cctx, chat, ans, heardVoice || askVoice || b.Agent.TakeVoice(session)) {
			b.spontaneous(cctx, session, chat, m.MsgID)
			return
		}
		b.sendChunks(cctx, chat, ans, rd)
		b.spontaneous(cctx, session, chat, m.MsgID)
	}()
}

func (b *Bot) Name() string  { return "telegram" }
func (b *Bot) Health() error { return b.tr.Health() }

func (b *Bot) Run(ctx context.Context) error {
	return b.tr.Run(ctx, func(m Incoming) { b.HandleIncoming(ctx, m) })
}

// spontaneous: иногда сама ставит реакцию на сообщение или кидает стикер, если после раздумий ей этого захотелось.
func (b *Bot) spontaneous(ctx context.Context, session string, chat int64, msgID int) {
	e := b.Agent.TakeEmoji(session)
	msgr, ok := b.tr.(tools.Messenger)
	if e == "" || !ok || rand.Intn(100) >= b.Agent.SpontPct() {
		return
	}
	var err error
	if msgID != 0 && rand.Intn(10) < 7 {
		err = msgr.React(ctx, chat, msgID, tools.ReactionFor(e))
	} else {
		err = msgr.SendSticker(ctx, chat, e)
	}
	if err != nil {
		log.Printf("сама не смогла отправить %s: %v", e, err)
	}
}

// sendVoice озвучивает ответ, если так настроено; при любой ошибке возвращает false и ответ уходит текстом.
func (b *Bot) sendVoice(ctx context.Context, chat int64, ans string, want bool) bool {
	vs, ok := b.tr.(VoiceSender)
	if !ok || b.Voice == nil || b.voiceMode() == "never" || (b.voiceMode() != "always" && !want) {
		return false
	}
	max := b.VoiceMax
	if max <= 0 {
		max = 600
	}
	say := voice.ForSpeech(ans)
	if say == "" || len([]rune(say)) > max {
		return false
	}
	audio, mime, err := b.Voice.Speak(ctx, say)
	if err != nil {
		log.Printf("озвучка не вышла, отвечаю текстом: %v", err)
		b.Events.Add("озвучка не вышла (%v), ответила текстом", err)
		return false
	}
	if err := vs.SendVoice(ctx, chat, audio, mime, voice.OggSeconds(audio)); err != nil {
		log.Printf("голосовое не отправилось, отвечаю текстом: %v", err)
		b.Events.Add("голосовое не отправилось (%v), ответила текстом", err)
		return false
	}
	return true
}

// SpeakTo озвучивает текст и отправляет голосовым (инструмент tg_voice).
func (b *Bot) SpeakTo(ctx context.Context, chat int64, text string) error {
	vs, ok := b.tr.(VoiceSender)
	if !ok || b.Voice == nil {
		return fmt.Errorf("голосовые не настроены")
	}
	say := voice.ForSpeech(text)
	if say == "" {
		return fmt.Errorf("пустой текст")
	}
	audio, mime, err := b.Voice.Speak(ctx, say)
	if err != nil {
		return err
	}
	return vs.SendVoice(ctx, chat, audio, mime, voice.OggSeconds(audio))
}

// sendChunks шлёт ответ короткими сообщениями (одна мысль это несколько сообщений подряд), перед каждым следующим «печатает…» и пауза.
func (b *Bot) sendChunks(ctx context.Context, chat int64, ans string, rd Reader) {
	parts := agent.Split(ans, b.Agent.ChunkMax())
	if len(parts) == 0 {
		return
	}
	if max := b.Agent.MaxChunks(); len(parts) > max { // хвост склеиваем в последнее сообщение, ничего не теряя
		parts = append(parts[:max-1], strings.Join(parts[max-1:], " "))
	}
	for i, p := range parts {
		if i > 0 {
			if d := b.Agent.ChunkPause(p); d > 0 {
				if rd != nil {
					rd.Typing(chat)
				}
				select {
				case <-time.After(d):
				case <-ctx.Done():
					b.Send(chat, strings.Join(parts[i:], " "))
					return
				}
			}
		}
		if tp := b.Agent.TypoPct(); tp > 0 && rand.Intn(100) < tp {
			if typo, fix, ok := agent.Typo(p); ok {
				b.Send(chat, typo)
				if d := b.Agent.ChunkPause(fix); d > 0 {
					select {
					case <-time.After(d):
					case <-ctx.Done():
					}
				}
				b.Send(chat, fix)
				continue
			}
		}
		b.Send(chat, p)
	}
}

// asksVoice: человек просит голосовое («отправь голосовое», «скажи голосом»).
func asksVoice(t string) bool {
	l := strings.ToLower(t)
	if !strings.Contains(l, "голосов") && !strings.Contains(l, "голосом") {
		return false
	}
	for _, w := range []string{"отправ", "пришл", "скин", "запиш", "скаж", "дай", "хочу", "можешь", "кинь", "давай", "пусть"} {
		if strings.Contains(l, w) {
			return true
		}
	}
	return false
}

// SetAllowed разрешает или запрещает чат (группу или человека) сразу; хозяина запретить нельзя.
func (b *Bot) SetAllowed(id int64, on bool) {
	if id == b.OwnerID {
		return
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if on {
		b.allowed[id] = true
	} else {
		delete(b.allowed, id)
	}
}

func (b *Bot) isAllowed(chat int64) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.allowed[chat]
}

// offerGroup: её позвали в группе, которой нет в allowed_ids. Хозяину в личку приходит вопрос; «да» запоминает группу навсегда.
func (b *Bot) offerGroup(ctx context.Context, m Incoming) {
	b.mu.Lock()
	if time.Since(b.offered[m.Chat]) < 10*time.Minute {
		b.mu.Unlock()
		return
	}
	b.offered[m.Chat] = time.Now()
	b.mu.Unlock()
	title := m.Title
	if title == "" {
		title = "без названия"
	}
	log.Printf("telegram: позвали в группе «%s» (id %d), её нет в allowed_ids; спрашиваю хозяина", title, m.Chat)
	if !b.ask(fmt.Sprintf("Меня позвали в группе «%s» (id %d): «%s». Разрешить отвечать там? Группа запомнится.", title, m.Chat, agent.Clip(m.Text, 120))) {
		return
	}
	b.mu.Lock()
	b.allowed[m.Chat] = true
	b.mu.Unlock()
	b.Events.Add("хозяин разрешил мне отвечать в группе «%s»", title)
	if b.OnAllow != nil {
		b.OnAllow(m.Chat)
	}
	b.HandleIncoming(ctx, m)
}

func (b *Bot) voiceMode() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.VoiceReply
}

const ownerHelp = "Команды (только тебе):\n/status: состояние\n/sh команда: выполнить в shell\n/file путь: прислать файл сюда\n/diary: последние записи дневника\n/panel: ссылка на веб-панель (/panel password: новый пароль)\n/remind: напоминания\n/voice on|off|auto: голосовые всегда, никогда, по настроению\n/block id, /unblock id, /blocked: чужие собеседники в личке\n/reset: забыть разговор\n/usage: расходы\nПришли zip сборки (marin-linux N.zip) с подписью /update: обновлюсь и перезапущусь"

// ownerCommand: явные команды хозяина. Раз он сам написал команду, это и есть разрешение; false: команда не наша, пусть идёт как обычное сообщение.
func (b *Bot) ownerCommand(ctx context.Context, chat int64, text string) bool {
	parts := strings.SplitN(text, " ", 2)
	cmd, arg := strings.ToLower(parts[0]), ""
	if len(parts) > 1 {
		arg = strings.TrimSpace(parts[1])
	}
	yes := func(string) bool { return true }
	exec := func(name string, args map[string]any) string {
		raw, _ := json.Marshal(args)
		return b.Agent.Tools().Exec(tools.WithChat(ctx, chat, 0), &tools.Turn{}, name, string(raw), yes)
	}
	switch cmd {
	case "/help":
		b.Send(chat, ownerHelp)
	case "/status":
		d := b.Ledger.Today()
		b.Send(chat, fmt.Sprintf("Жива. Сессий %d, страниц дневника %d, сегодня запросов %d, $%.4f.\nГолос: %s. Время сервера: %s.\n%s", b.Agent.SessionCount(), b.Agent.Pages(), d.Requests, d.USD, b.voiceMode(), time.Now().Format("15:04"), exec("remind_list", map[string]any{})))
	case "/sh":
		if arg == "" {
			b.Send(chat, "Использование: /sh команда")
			break
		}
		b.Send(chat, agent.Clip(exec("shell", map[string]any{"command": arg}), 3900))
	case "/file":
		if arg == "" {
			b.Send(chat, "Использование: /file /путь/к/файлу")
			break
		}
		if out := exec("tg_send_file", map[string]any{"path": arg, "chat": chat}); !strings.Contains(out, "отправлен") {
			b.Send(chat, out)
		}
	case "/diary":
		d := b.Agent.Diary(5)
		if len(d) == 0 {
			b.Send(chat, "Дневник пока пуст.")
		} else {
			b.Send(chat, "Последние мысли:\n"+strings.Join(d, "\n"))
		}
	case "/remind", "/reminders":
		b.Send(chat, exec("remind_list", map[string]any{}))
	case "/panel":
		if strings.EqualFold(arg, "password") || strings.EqualFold(arg, "пароль") {
			if b.ResetPassword == nil {
				b.Send(chat, "Панель не настроена.")
				break
			}
			b.Send(chat, "Новый пароль панели (старый не работает, все сессии сброшены). Сохрани в менеджере паролей:\n"+b.ResetPassword())
			break
		}
		if b.PanelURL != nil && b.PanelURL() != "" {
			b.Send(chat, "Панель: "+b.PanelURL()+"\nВход по паролю. Забыл пароль: /panel password")
		} else {
			b.Send(chat, "Публичная ссылка ещё не готова (туннель поднимается или выключен). Локально панель на сервере, пароль: /panel password")
		}
	case "/block", "/unblock":
		id, err := strconv.ParseInt(strings.TrimSpace(arg), 10, 64)
		if err != nil || id == 0 {
			b.Send(chat, "Использование: "+cmd+" id (число из сообщения «Новый собеседник» или из панели)")
			break
		}
		if id == b.OwnerID {
			b.Send(chat, "Себя блокировать не буду.")
			break
		}
		b.SetBlocked(id, cmd == "/block")
		b.Send(chat, map[string]string{"/block": "Заблокировала, ему больше не отвечаю. Вернуть: /unblock ", "/unblock": "Разблокировала: "}[cmd]+arg)
	case "/blocked":
		ids := b.BlockedList()
		if len(ids) == 0 {
			b.Send(chat, "Заблокированных нет.")
			break
		}
		b.Send(chat, "Заблокированы: "+fmt.Sprint(ids))
	case "/voice":
		mode := map[string]string{"on": "always", "off": "never", "auto": "mirror"}[strings.ToLower(arg)]
		if mode == "" {
			b.Send(chat, "Использование: /voice on|off|auto")
			break
		}
		b.mu.Lock()
		b.VoiceReply = mode
		b.mu.Unlock()
		b.Send(chat, "Голосовые: "+mode+" (до перезапуска; насовсем это voice.reply в config.json)")
	default:
		return false
	}
	return true
}

// selfUpdate: хозяин прислал zip с подписью /update: достаём бинарник, подменяем себя и перезапускаемся.
func (b *Bot) selfUpdate(chat int64, m Incoming) {
	exe, err := os.Executable()
	if err != nil {
		b.Send(chat, "Не знаю, где я лежу: "+err.Error())
		return
	}
	bin, name, err := selfupd.Extract(m.File, runtime.GOARCH)
	if err != nil {
		b.Send(chat, "Обновиться не вышло: "+err.Error())
		return
	}
	if err := selfupd.Install(exe, bin); err != nil {
		b.Send(chat, "Не смогла заменить себя: "+err.Error())
		return
	}
	b.Events.Add("обновилась из присланного архива (%s) и перезапускаюсь", name)
	b.Send(chat, fmt.Sprintf("Взяла %s (%d МБ), старая версия лежит как reina.old. Перезапускаюсь, вернусь через пару секунд.", name, len(bin)>>20))
	time.Sleep(2 * time.Second)
	if b.OnRestart != nil {
		b.OnRestart()
	}
	if err := selfupd.Restart(exe); err != nil {
		b.Send(chat, "Сама перезапуститься не смогла, перезапусти меня вручную: "+err.Error())
	}
}

// goOnline: при сообщении она «в сети», через 1-2 минуты тишины снова «была недавно»: как у человека, который не сидит в телеге вечно.
func (b *Bot) goOnline() {
	p, ok := b.tr.(Presence)
	if !ok {
		return
	}
	b.mu.Lock()
	if b.offlineT != nil {
		b.offlineT.Stop()
	}
	b.offlineT = time.AfterFunc(time.Duration(60+rand.Intn(60))*time.Second, func() { p.SetOnline(false) })
	b.mu.Unlock()
	go p.SetOnline(true)
}

// Notify отправляет хозяину текст и возвращает ошибку (нужно, когда сообщение важно и надо повторить).
func (b *Bot) Notify(chat int64, text string) error { return b.tr.Send(chat, text) }

// VoiceModeText: как сейчас с голосом (для панели).
func (b *Bot) VoiceModeText() string {
	if b.Voice == nil {
		return "выключен"
	}
	return map[string]string{"always": "всегда", "never": "никогда", "mirror": "по настроению"}[b.voiceMode()]
}
