package telegram

import (
	"context"
	"strings"
	"testing"

	"reina/internal/agent"
)

type listTransport struct{ fakeTransport }

func (l *listTransport) Chats(ctx context.Context, q string, n int) (string, error) {
	return "-1001 | супергруппа | клуб любителей куни | | участников: 40 | непрочитано: 26\n555 | лс | Асия |  | непрочитано: 1\n", nil
}
func (l *listTransport) History(ctx context.Context, chat int64, n int) (string, error) {
	return "1 | 17.10 17:40 | Jaabir | ты прав, спорим", nil
}

func awareBot(t *testing.T) *Bot {
	awMu.Lock()
	awCache = map[string]awEntry{}
	awMu.Unlock()
	b, _, _ := newBot(t)
	b.tr = &listTransport{}
	b.Agent.SetOwner("tg:42", "хозяин, зовёт её Рейна")
	return b
}

func TestAwareGivesRealChatsToOwnerOnly(t *testing.T) {
	b := awareBot(t)
	ctx := context.Background()
	own := b.aware(ctx, "tg:42", "какие у тебя группы", true)
	if !strings.Contains(own, "клуб любителей куни") || !strings.Contains(own, "ты прав, спорим") {
		t.Fatalf("хозяину нужны чаты и содержимое живой группы: %q", own)
	}
	named := b.aware(ctx, "tg:42", "что там в клуб любителей куни", true)
	if !strings.Contains(named, "Последние сообщения чата") {
		t.Fatalf("названный чат должен раскрыться: %q", named)
	}
	grp := b.aware(ctx, "tg:-1001", "рейна, а ты что думаешь", false)
	if !strings.Contains(grp, "ты прав, спорим") || strings.Contains(grp, "Асия") || strings.Contains(grp, "Твои настоящие чаты") {
		t.Fatalf("в группе только её история, список чатов хозяина не отдаём: %q", grp)
	}
	if got := b.aware(ctx, "tg:555", "привет", false); got != "" {
		t.Fatalf("постороннему в личке ничего: %q", got)
	}
}

func TestOneReinaAcrossChats(t *testing.T) {
	b := awareBot(t)
	ctx := context.Background()
	if _, err := b.Agent.Reply(ctx, "tg:42", "в личке секретно: у меня завтра экзамен"); err != nil {
		t.Fatal(err)
	}
	if _, err := b.Agent.Reply(ctx, "tg:-1001", "[в группе, пишет Jaabir] чего молчите"); err != nil {
		t.Fatal(err)
	}
	// хозяин пишет в группе: видит личку
	got := b.aware(agent.WithOwnerSender(ctx), "tg:-1001", "рейна привет", false)
	if !strings.Contains(got, "экзамен") {
		t.Fatalf("хозяин в группе: она должна помнить личку: %q", got)
	}
	// посторонний в той же группе: лички нет
	if g := b.aware(ctx, "tg:-1001", "рейна привет", false); strings.Contains(g, "экзамен") {
		t.Fatalf("утечка лички постороннему: %q", g)
	}
	// хозяин в личке: видит, что было в группе
	own := b.aware(ctx, "tg:42", "ну как там", true)
	if !strings.Contains(own, "чего молчите") || !strings.Contains(own, "клуб любителей куни") {
		t.Fatalf("в личке она должна помнить группу по имени: %q", own)
	}
}
