package telegram

import (
	"fmt"
	"log"
	"sort"
	"time"

	"reina/internal/agent"
)

// dmCount: сколько сообщений от этого человека сегодня.
type dmCount struct {
	day  string
	n    int
	told bool // про лимит уже сказали
}

func (b *Bot) isBlocked(chat int64) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.blocked[chat]
}

// SetBlocked блокирует или возвращает человека; решение сохраняется через OnBlock.
func (b *Bot) SetBlocked(id int64, on bool) {
	b.mu.Lock()
	if on {
		b.blocked[id] = true
	} else {
		delete(b.blocked, id)
	}
	cb := b.OnBlock
	b.mu.Unlock()
	if on {
		b.Events.Add("заблокировала человека %d", id)
	} else {
		b.Events.Add("разблокировала человека %d", id)
	}
	if cb != nil {
		cb(id, on)
	}
}

// LoadBlocked: список из config.json при старте.
func (b *Bot) LoadBlocked(ids []int64) {
	b.mu.Lock()
	for _, id := range ids {
		b.blocked[id] = true
	}
	b.mu.Unlock()
}

// LoadSeen: кому из чужих уже сообщали хозяину.
func (b *Bot) LoadSeen(ids []int64) {
	b.mu.Lock()
	for _, id := range ids {
		b.seen[id] = true
	}
	b.mu.Unlock()
}

func (b *Bot) BlockedList() []int64 {
	b.mu.Lock()
	defer b.mu.Unlock()
	out := make([]int64, 0, len(b.blocked))
	for id := range b.blocked {
		out = append(out, id)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}

// admitStranger: можно ли ответить чужому в личке. Считает суточный лимит и один раз сообщает хозяину о новом человеке.
// Чужие получают её как обычную собеседницу: инструментов, памяти, дневника и сведений о хозяине у них нет (это решает агент по сессии).
func (b *Bot) admitStranger(chat int64, m Incoming) bool {
	if chat <= 0 || chat == 777000 { // служебный аккаунт Telegram и всё, что не человек
		return false
	}
	cost := 1
	if len(m.Image) > 0 || len(m.Voice) > 0 {
		cost = 3
	}
	day := time.Now().Format("2006-01-02")
	limit := b.DMDailyMax
	if limit <= 0 {
		limit = 40
	}
	b.mu.Lock()
	c := b.dmDay[chat]
	if c == nil || c.day != day {
		if len(b.dmDay) > 2000 {
			b.dmDay = map[int64]*dmCount{}
		}
		c = &dmCount{day: day}
		b.dmDay[chat] = c
	}
	c.n += cost
	over := c.n > limit
	told := c.told
	if over {
		c.told = true
	}
	first := !b.seen[chat]
	if first {
		b.seen[chat] = true
	}
	notify := b.NotifyNewDM
	onSeen := b.OnSeen
	b.mu.Unlock()
	if first {
		if onSeen != nil {
			onSeen(chat)
		}
		if notify && b.OwnerID != 0 {
			who := m.From
			if who == "" {
				who = "без имени"
			}
			go b.Notify(b.OwnerID, fmt.Sprintf("Новый собеседник в личке: %s (id %d). Написал: «%s». Отвечаю ему сама, твоё и инструменты ему закрыты. Замолчать: /block %d", who, chat, agent.Clip(m.Text, 120), chat))
		}
		log.Printf("telegram: новый собеседник в личке %s (id %d)", who(m), chat)
		b.Events.Add("в личку написал новый человек: %s (id %d)", who(m), chat)
	}
	if over {
		if !told {
			go b.Send(chat, "на сегодня наболталась, давай завтра")
		}
		return false
	}
	return true
}

func who(m Incoming) string {
	if m.From != "" {
		return m.From
	}
	return "без имени"
}

// AllowedGroupNames: группы, где ей разрешено отвечать (названия, если удалось узнать).
func (b *Bot) AllowedGroupNames() []string {
	b.mu.Lock()
	var ids []int64
	for id := range b.allowed {
		if id < 0 {
			ids = append(ids, id)
		}
	}
	b.mu.Unlock()
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	var out []string
	for _, id := range ids {
		name := b.ChatTitle(fmt.Sprintf("tg:%d", id))
		if name == "" {
			name = fmt.Sprintf("группа %d", id)
		}
		out = append(out, "«"+name+"»")
	}
	return out
}

// DMInfo: открыта ли личка для чужих, дневной лимит и сколько заблокировано.
func (b *Bot) DMInfo() (open bool, limit, blocked int) {
	b.mu.Lock()
	defer b.mu.Unlock()
	limit = b.DMDailyMax
	if limit <= 0 {
		limit = 40
	}
	return b.OpenDM, limit, len(b.blocked)
}
