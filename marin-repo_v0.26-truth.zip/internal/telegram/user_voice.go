//go:build tguser

package telegram

import (
	"context"
	"fmt"
	mrand "math/rand"
	"strings"

	"github.com/gotd/td/telegram/uploader"
	"github.com/gotd/td/tg"
)

// SendVoice отправляет голосовое сообщение (ogg/opus показывается как голосовое, mp3 уходит обычным аудиофайлом).
func (u *User) SendVoice(ctx context.Context, chat int64, audio []byte, mime string, seconds int) error {
	p, err := u.peerFor(ctx, chat)
	if err != nil {
		return err
	}
	api, _ := u.apiCtx()
	name, voiceNote := "voice.ogg", strings.Contains(mime, "ogg")
	if !voiceNote {
		name = "voice.mp3"
	}
	f, err := uploader.NewUploader(api).FromBytes(ctx, name, audio)
	if err != nil {
		return fmt.Errorf("загрузка голосового: %w", err)
	}
	_, err = api.MessagesSendMedia(ctx, &tg.MessagesSendMediaRequest{
		Peer: p,
		Media: &tg.InputMediaUploadedDocument{
			File:     f,
			MimeType: mime,
			Attributes: []tg.DocumentAttributeClass{
				&tg.DocumentAttributeAudio{Voice: voiceNote, Duration: seconds},
				&tg.DocumentAttributeFilename{FileName: name},
			},
		},
		RandomID: mrand.Int63(),
	})
	return err
}
