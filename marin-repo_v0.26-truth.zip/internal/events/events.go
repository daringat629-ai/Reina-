// Package events: журнал того, что с ней на самом деле происходило (инструменты, сообщения первой, сбои, перезапуски).
// Он нужен, чтобы она говорила о своей жизни по фактам, а не выдумывала.
package events

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"
)

type Item struct {
	At   int64  `json:"at"`
	Text string `json:"t"`
}

type Log struct {
	mu    sync.Mutex
	path  string
	items []Item
	Max   int
	Now   func() time.Time
}

// Open читает журнал с диска (path пустой: только в памяти).
func Open(path string) *Log {
	l := &Log{path: path, Max: 80, Now: time.Now}
	if path != "" {
		if b, err := os.ReadFile(path); err == nil {
			_ = json.Unmarshal(b, &l.items)
		}
	}
	return l
}

// Add записывает событие. Безопасно вызывать на nil: тогда ничего не происходит.
func (l *Log) Add(format string, a ...any) {
	if l == nil {
		return
	}
	t := strings.Join(strings.Fields(fmt.Sprintf(format, a...)), " ")
	if r := []rune(t); len(r) > 200 {
		t = string(r[:200]) + "…"
	}
	if t == "" {
		return
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	l.items = append(l.items, Item{At: l.Now().Unix(), Text: t})
	if l.Max > 0 && len(l.items) > l.Max {
		l.items = l.items[len(l.items)-l.Max:]
	}
	if l.path != "" {
		if b, err := json.Marshal(l.items); err == nil {
			tmp := l.path + ".tmp"
			if os.WriteFile(tmp, b, 0o600) == nil {
				_ = os.Rename(tmp, l.path)
			}
		}
	}
}

// Last: последние n событий, старые первыми.
func (l *Log) Last(n int) []Item {
	if l == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	it := l.items
	if len(it) > n {
		it = it[len(it)-n:]
	}
	return append([]Item(nil), it...)
}

// Format: строки «ЧЧ:ММ текст» (для сегодняшних), «ДД.ММ ЧЧ:ММ текст» (для старых) в часовом поясе loc.
func (l *Log) Format(n int, loc *time.Location) string {
	if loc == nil {
		loc = time.Local
	}
	now := l.nowOr()
	var sb strings.Builder
	for _, it := range l.Last(n) {
		t := time.Unix(it.At, 0).In(loc)
		layout := "02.01 15:04"
		if t.Format("2006-01-02") == now.In(loc).Format("2006-01-02") {
			layout = "15:04"
		}
		sb.WriteString(t.Format(layout) + " " + it.Text + "\n")
	}
	return sb.String()
}

func (l *Log) nowOr() time.Time {
	if l == nil || l.Now == nil {
		return time.Now()
	}
	return l.Now()
}
