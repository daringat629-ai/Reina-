package events

import (
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestLogKeepsTheLastEventsAcrossRestartsAndToleratesNil(t *testing.T) {
	var nl *Log
	nl.Add("ничего") // не падает
	if nl.Last(3) != nil {
		t.Fatal("nil-журнал пуст")
	}
	p := filepath.Join(t.TempDir(), "events.json")
	l := Open(p)
	l.Max = 3
	for _, s := range []string{"раз", "два", "три", "четыре"} {
		l.Add("%s", s)
	}
	l2 := Open(p)
	got := l2.Last(10)
	if len(got) != 3 || got[0].Text != "два" || got[2].Text != "четыре" {
		t.Fatalf("%v", got)
	}
	loc, _ := time.LoadLocation("Asia/Bishkek")
	l2.Now = func() time.Time { return time.Unix(got[2].At, 0) }
	if f := l2.Format(2, loc); !strings.Contains(f, "три") || !strings.Contains(f, "четыре") || strings.Count(f, "\n") != 2 {
		t.Fatalf("%q", f)
	}
}
