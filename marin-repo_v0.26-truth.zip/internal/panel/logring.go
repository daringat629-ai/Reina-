package panel

import (
	"strings"
	"sync"
)

// LogRing хранит последние строки лога (log.SetOutput(io.MultiWriter(os.Stderr, ring))) для окна «Лог» в панели.
type LogRing struct {
	mu    sync.Mutex
	lines []string
	part  string
	Max   int
}

func (l *LogRing) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.Max <= 0 {
		l.Max = 200
	}
	s := l.part + string(p)
	parts := strings.Split(s, "\n")
	l.part = parts[len(parts)-1]
	for _, ln := range parts[:len(parts)-1] {
		if ln = strings.TrimSpace(ln); ln != "" {
			if len(ln) > 300 {
				ln = ln[:300]
			}
			l.lines = append(l.lines, ln)
		}
	}
	if n := len(l.lines); n > l.Max {
		l.lines = l.lines[n-l.Max:]
	}
	return len(p), nil
}

func (l *LogRing) Last(n int) []string {
	l.mu.Lock()
	defer l.mu.Unlock()
	if n > len(l.lines) {
		n = len(l.lines)
	}
	return append([]string(nil), l.lines[len(l.lines)-n:]...)
}
