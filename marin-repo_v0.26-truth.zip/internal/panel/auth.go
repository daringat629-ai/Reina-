package panel

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"
)

const pbkdfIter = 150000

func pbkdf2(pass, salt []byte, iter int) []byte {
	prf := hmac.New(sha256.New, pass)
	prf.Write(salt)
	prf.Write([]byte{0, 0, 0, 1})
	u := prf.Sum(nil)
	out := append([]byte(nil), u...)
	for i := 1; i < iter; i++ {
		prf.Reset()
		prf.Write(u)
		u = prf.Sum(u[:0])
		for j := range out {
			out[j] ^= u[j]
		}
	}
	return out
}

// HashPassword: "pbkdf2$итераций$соль$хеш". В конфиге хранится только он, сам пароль нигде не лежит.
func HashPassword(pw string) string {
	salt := make([]byte, 16)
	rand.Read(salt)
	return fmt.Sprintf("pbkdf2$%d$%s$%s", pbkdfIter, hex.EncodeToString(salt), hex.EncodeToString(pbkdf2([]byte(pw), salt, pbkdfIter)))
}

// CheckPassword проверяет пароль за постоянное время.
func CheckPassword(pw, stored string) bool {
	p := strings.Split(stored, "$")
	if len(p) != 4 || p[0] != "pbkdf2" {
		return false
	}
	iter, err := strconv.Atoi(p[1])
	if err != nil || iter < 1000 || iter > 5000000 {
		return false
	}
	salt, e1 := hex.DecodeString(p[2])
	want, e2 := hex.DecodeString(p[3])
	if e1 != nil || e2 != nil {
		return false
	}
	return subtle.ConstantTimeCompare(pbkdf2([]byte(pw), salt, iter), want) == 1
}

// NewPassword: случайный пароль из 20 символов (≈120 бит), читаемый и без похожих символов.
func NewPassword() string {
	const alpha = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, 20)
	rand.Read(b)
	for i := range b {
		b[i] = alpha[int(b[i])%len(alpha)]
	}
	s := string(b)
	return s[:5] + "-" + s[5:10] + "-" + s[10:15] + "-" + s[15:]
}

// sessions: вход по паролю даёт случайный токен в HttpOnly-cookie на 12 часов; хранится только в памяти.
type sess struct {
	exp time.Time
	fp  string // отпечаток хеша пароля: смена пароля выкидывает все сессии
}

type sessions struct {
	mu  sync.Mutex
	m   map[string]sess
	Now func() time.Time
}

func newSessions() *sessions { return &sessions{m: map[string]sess{}, Now: time.Now} }

func (s *sessions) New(fp string) string {
	b := make([]byte, 32)
	rand.Read(b)
	t := base64.RawURLEncoding.EncodeToString(b)
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.Now()
	for k, v := range s.m {
		if now.After(v.exp) {
			delete(s.m, k)
		}
	}
	if len(s.m) >= 20 { // не копим бесконечно: самые старые уходят
		for k := range s.m {
			delete(s.m, k)
			break
		}
	}
	s.m[t] = sess{now.Add(12 * time.Hour), fp}
	return t
}

func (s *sessions) Valid(t, fp string) bool {
	if t == "" {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	v, ok := s.m[t]
	if ok && (s.Now().After(v.exp) || v.fp != fp) {
		delete(s.m, t)
		return false
	}
	return ok
}

func (s *sessions) Drop(t string) { s.mu.Lock(); delete(s.m, t); s.mu.Unlock() }
