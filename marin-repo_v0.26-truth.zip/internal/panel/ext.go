package panel

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"time"

	"reina/internal/config"
	"reina/internal/events"
)

// Ext: то, что панели нужно от ядра сверх базового. Всё необязательное: нет функции, нет и окна.
type Ext struct {
	Home       string
	Version    string
	Started    time.Time
	ChatName   func(session string) string // «tg:-1001» → название чата
	LoadConfig func() (config.Config, error)
	SaveConfig func(config.Config) error
	Send       func(ctx context.Context, chat int64, text string) error // написать от её имени
	Blocked    func() []int64
	SetBlocked func(id int64, on bool)
	Allowed    func() []int64
	SetAllowed func(id int64, on bool)
	BackupNow  func() (string, error)
	Console    func(ctx context.Context, command string) string // nil: консоль выключена (panel.console в config.json)
	Restart    func()
	Events     *events.Log // журнал событий (что с ней происходило)
}

func out(w http.ResponseWriter, v any) { json.NewEncoder(w).Encode(v) }

func fail(w http.ResponseWriter, code int, msg string) {
	w.WriteHeader(code)
	out(w, map[string]any{"error": msg})
}

func readBody(w http.ResponseWriter, r *http.Request, v any) bool {
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(v); err != nil {
		fail(w, http.StatusBadRequest, "плохой запрос")
		return false
	}
	return true
}

var (
	imgName    = regexp.MustCompile(`^[A-Za-z0-9._-]{1,120}\.(png|jpe?g|webp|gif)$`)
	backupName = regexp.MustCompile(`^reina-[0-9-]{10}\.tar\.gz$`)
)

func (d Deps) registerExt(mux *http.ServeMux, auth func(http.HandlerFunc) http.HandlerFunc) {
	e := d.Ext
	if e == nil {
		return
	}
	title := func(id string) string {
		if e.ChatName != nil {
			if n := e.ChatName(id); n != "" {
				return n
			}
		}
		return ""
	}

	// События: что с ней происходило на самом деле.
	mux.HandleFunc("/api/events", auth(func(w http.ResponseWriter, r *http.Request) {
		var rows []map[string]any
		items := e.Events.Last(40)
		for i := len(items) - 1; i >= 0; i-- {
			rows = append(rows, map[string]any{"at": items[i].At, "text": items[i].Text})
		}
		out(w, map[string]any{"events": rows})
	}))

	// Чаты: живые разговоры, просмотр, забыть.
	mux.HandleFunc("/api/sessions", auth(func(w http.ResponseWriter, r *http.Request) {
		var rows []map[string]any
		for _, s := range d.Agent.Sessions() {
			rows = append(rows, map[string]any{"id": s.ID, "title": title(s.ID), "msgs": s.Msgs, "last": s.Last, "last_at": s.LastAt.Unix(), "owner": s.Owner})
		}
		out(w, map[string]any{"sessions": rows})
	}))
	mux.HandleFunc("/api/session", auth(func(w http.ResponseWriter, r *http.Request) {
		id := r.URL.Query().Get("id")
		if !strings.HasPrefix(id, "tg:") {
			fail(w, http.StatusBadRequest, "нет такого чата")
			return
		}
		if r.Method == http.MethodDelete {
			d.Agent.Reset(id)
		}
		out(w, map[string]any{"id": id, "title": title(id), "messages": d.Agent.Dump(id, 40), "thought": d.Agent.Thought(id)})
	}))

	// Люди: заметки о собеседниках.
	mux.HandleFunc("/api/people", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			idx := -1
			if v := r.URL.Query().Get("idx"); v != "" {
				idx, _ = strconv.Atoi(v)
			}
			d.Agent.PersonDelete(r.URL.Query().Get("session"), idx)
		}
		var rows []map[string]any
		for id, notes := range d.Agent.People() {
			rows = append(rows, map[string]any{"session": id, "title": title(id), "notes": notes})
		}
		sort.Slice(rows, func(i, j int) bool { return fmt.Sprint(rows[i]["session"]) < fmt.Sprint(rows[j]["session"]) })
		out(w, map[string]any{"people": rows})
	}))

	// Дневник: поиск, просмотр, удаление страниц.
	mux.HandleFunc("/api/diary", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			d.Agent.DiaryRemove(r.URL.Query().Get("id"))
		}
		n, _ := strconv.Atoi(r.URL.Query().Get("n"))
		if n <= 0 || n > 100 {
			n = 30
		}
		out(w, map[string]any{"pages": d.Agent.DiaryPages(r.URL.Query().Get("q"), n), "total": d.Agent.Pages(), "mood": d.Agent.Mood()})
	}))

	// Память: добавить факт руками.
	mux.HandleFunc("/api/fact", auth(func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Text string `json:"text"`
		}
		if r.Method != http.MethodPost || !readBody(w, r, &b) {
			fail(w, http.StatusBadRequest, "плохой запрос")
			return
		}
		t := strings.TrimSpace(b.Text)
		if t == "" || len([]rune(t)) > 400 {
			fail(w, http.StatusBadRequest, "факт от 1 до 400 символов")
			return
		}
		id, added := d.Mem.Add(t, "panel", 0)
		out(w, map[string]any{"id": id, "added": added})
	}))

	// Напоминания: добавить и отменить.
	mux.HandleFunc("/api/reminder", auth(func(w http.ResponseWriter, r *http.Request) {
		if d.Rem == nil {
			fail(w, http.StatusNotFound, "напоминания выключены")
			return
		}
		switch r.Method {
		case http.MethodPost:
			var b struct {
				At   string `json:"at"` // 2006-01-02 15:04 в часовом поясе хозяина
				Text string `json:"text"`
			}
			if !readBody(w, r, &b) {
				return
			}
			at, err := d.Rem.ParseWhen(0, strings.TrimSpace(b.At))
			if err != nil || strings.TrimSpace(b.Text) == "" {
				fail(w, http.StatusBadRequest, "нужны время ГГГГ-ММ-ДД ЧЧ:ММ и текст")
				return
			}
			out(w, map[string]any{"id": d.Rem.Add(at, strings.TrimSpace(b.Text))})
		case http.MethodDelete:
			id, _ := strconv.Atoi(r.URL.Query().Get("id"))
			out(w, map[string]any{"ok": d.Rem.Cancel(id)})
		default:
			fail(w, http.StatusMethodNotAllowed, "метод не тот")
		}
	}))

	// Настройки: только то, что в таблице.
	mux.HandleFunc("/api/settings", auth(func(w http.ResponseWriter, r *http.Request) {
		if e.LoadConfig == nil {
			fail(w, http.StatusNotFound, "настройки недоступны")
			return
		}
		c, err := e.LoadConfig()
		if err != nil {
			fail(w, http.StatusInternalServerError, err.Error())
			return
		}
		if r.Method == http.MethodPost {
			var b struct {
				Key   string `json:"key"`
				Value any    `json:"value"`
			}
			if !readBody(w, r, &b) {
				return
			}
			nc, err := applySetting(c, b.Key, b.Value)
			if err != nil {
				fail(w, http.StatusBadRequest, err.Error())
				return
			}
			if e.SaveConfig == nil || e.SaveConfig(nc) != nil {
				fail(w, http.StatusInternalServerError, "не удалось записать config.json")
				return
			}
			log.Printf("панель: изменена настройка %s", b.Key)
			c = nc
		}
		rows, err := settingsView(c)
		if err != nil {
			fail(w, http.StatusInternalServerError, err.Error())
			return
		}
		out(w, map[string]any{"settings": rows, "restart": r.Method == http.MethodPost, "can_restart": e.Restart != nil})
	}))
	mux.HandleFunc("/api/restart", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || e.Restart == nil {
			fail(w, http.StatusBadRequest, "перезапуск недоступен")
			return
		}
		out(w, map[string]any{"ok": true})
		go func() { time.Sleep(500 * time.Millisecond); e.Restart() }()
	}))

	// Расходы по дням.
	mux.HandleFunc("/api/usage", auth(func(w http.ResponseWriter, r *http.Request) {
		days, _ := strconv.Atoi(r.URL.Query().Get("days"))
		if days <= 0 || days > 60 {
			days = 14
		}
		out(w, map[string]any{"days": d.Led.History(days), "cap": d.Led.Cap})
	}))

	// Галерея сгенерированных картинок.
	imgDir := filepath.Join(e.Home, "images")
	mux.HandleFunc("/api/images", auth(func(w http.ResponseWriter, r *http.Request) {
		ents, _ := os.ReadDir(imgDir)
		type row struct {
			Name string `json:"name"`
			Size int64  `json:"size"`
			At   int64  `json:"at"`
		}
		var rows []row
		for _, en := range ents {
			if info, err := en.Info(); err == nil && !en.IsDir() && imgName.MatchString(en.Name()) {
				rows = append(rows, row{en.Name(), info.Size(), info.ModTime().Unix()})
			}
		}
		sort.Slice(rows, func(i, j int) bool { return rows[i].At > rows[j].At })
		if len(rows) > 60 {
			rows = rows[:60]
		}
		out(w, map[string]any{"images": rows})
	}))
	mux.HandleFunc("/api/image", auth(func(w http.ResponseWriter, r *http.Request) {
		name := r.URL.Query().Get("name")
		if !imgName.MatchString(name) {
			http.NotFound(w, r)
			return
		}
		f, err := os.Open(filepath.Join(imgDir, name))
		if err != nil {
			http.NotFound(w, r)
			return
		}
		defer f.Close()
		w.Header().Set("Content-Type", mime.TypeByExtension(strings.ToLower(filepath.Ext(name))))
		w.Header().Set("Cache-Control", "private, max-age=3600")
		if r.Method == http.MethodDelete {
			os.Remove(filepath.Join(imgDir, name))
			w.Header().Set("Content-Type", "application/json")
			out(w, map[string]any{"ok": true})
			return
		}
		io.Copy(w, f)
	}))

	// Резервные копии.
	mux.HandleFunc("/api/backups", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			if e.BackupNow == nil {
				fail(w, http.StatusNotFound, "резервные копии выключены")
				return
			}
			if _, err := e.BackupNow(); err != nil {
				fail(w, http.StatusInternalServerError, err.Error())
				return
			}
		}
		ents, _ := os.ReadDir(filepath.Join(e.Home, "backups"))
		type row struct {
			Name string `json:"name"`
			Size int64  `json:"size"`
			At   int64  `json:"at"`
		}
		var rows []row
		for _, en := range ents {
			if info, err := en.Info(); err == nil && backupName.MatchString(en.Name()) {
				rows = append(rows, row{en.Name(), info.Size(), info.ModTime().Unix()})
			}
		}
		sort.Slice(rows, func(i, j int) bool { return rows[i].At > rows[j].At })
		out(w, map[string]any{"backups": rows})
	}))
	mux.HandleFunc("/api/backup", auth(func(w http.ResponseWriter, r *http.Request) {
		name := r.URL.Query().Get("name")
		if !backupName.MatchString(name) {
			http.NotFound(w, r)
			return
		}
		f, err := os.Open(filepath.Join(e.Home, "backups", name))
		if err != nil {
			http.NotFound(w, r)
			return
		}
		defer f.Close()
		w.Header().Set("Content-Type", "application/gzip")
		w.Header().Set("Content-Disposition", `attachment; filename="`+name+`"`)
		io.Copy(w, f)
	}))

	// Написать от её имени.
	mux.HandleFunc("/api/send", auth(func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Chat int64  `json:"chat"`
			Text string `json:"text"`
		}
		if r.Method != http.MethodPost || e.Send == nil || !readBody(w, r, &b) {
			fail(w, http.StatusBadRequest, "отправка недоступна")
			return
		}
		t := strings.TrimSpace(b.Text)
		if b.Chat == 0 || t == "" || len([]rune(t)) > 4000 {
			fail(w, http.StatusBadRequest, "нужны чат и текст")
			return
		}
		if err := e.Send(r.Context(), b.Chat, t); err != nil {
			fail(w, http.StatusBadGateway, err.Error())
			return
		}
		log.Printf("панель: сообщение от её имени в чат %d", b.Chat)
		out(w, map[string]any{"ok": true})
	}))

	// Блок-лист и разрешённые чаты.
	mux.HandleFunc("/api/access", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost || r.Method == http.MethodDelete {
			var b struct {
				List string `json:"list"` // blocked | allowed
				ID   int64  `json:"id"`
			}
			if r.Method == http.MethodDelete {
				b.List = r.URL.Query().Get("list")
				b.ID, _ = strconv.ParseInt(r.URL.Query().Get("id"), 10, 64)
			} else if !readBody(w, r, &b) {
				return
			}
			on := r.Method == http.MethodPost
			switch {
			case b.ID == 0:
				fail(w, http.StatusBadRequest, "нужен id")
				return
			case b.List == "blocked" && e.SetBlocked != nil:
				e.SetBlocked(b.ID, on)
			case b.List == "allowed" && e.SetAllowed != nil:
				e.SetAllowed(b.ID, on)
			default:
				fail(w, http.StatusBadRequest, "неизвестный список")
				return
			}
		}
		res := map[string]any{}
		if e.Blocked != nil {
			res["blocked"] = e.Blocked()
		}
		if e.Allowed != nil {
			res["allowed"] = e.Allowed()
		}
		out(w, res)
	}))

	// Система и возможности.
	mux.HandleFunc("/api/system", auth(func(w http.ResponseWriter, r *http.Request) {
		var ms runtime.MemStats
		runtime.ReadMemStats(&ms)
		out(w, map[string]any{"version": e.Version, "go": runtime.Version(), "os": runtime.GOOS + "/" + runtime.GOARCH, "goroutines": runtime.NumGoroutine(), "mem_mb": ms.Alloc >> 20,
			"uptime_sec": int(time.Since(e.Started).Seconds()), "console": e.Console != nil, "can_restart": e.Restart != nil, "home": e.Home})
	}))
	mux.HandleFunc("/api/console", auth(func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Command string `json:"command"`
		}
		if e.Console == nil {
			fail(w, http.StatusNotFound, `консоль выключена: в config.json поставь "panel": {"console": true} и перезапусти`)
			return
		}
		if r.Method != http.MethodPost || !readBody(w, r, &b) || strings.TrimSpace(b.Command) == "" {
			fail(w, http.StatusBadRequest, "нужна команда")
			return
		}
		log.Printf("панель: консоль: %s", b.Command)
		ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
		defer cancel()
		out(w, map[string]any{"output": e.Console(ctx, b.Command)})
	}))
}
