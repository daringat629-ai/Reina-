package panel

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/memory"
	"reina/internal/supervisor"
	"reina/internal/tools"
)

type dummy struct{ name string }

func (d dummy) Name() string                  { return d.name }
func (d dummy) Run(ctx context.Context) error { <-ctx.Done(); return nil }
func (d dummy) Health() error                 { return nil }

func deps(t *testing.T, token string) (Deps, *supervisor.Supervisor) {
	cfg := config.Default()
	cfg.Home = t.TempDir()
	led, mem := budget.Open(cfg.Home, 0), memory.Open(cfg.Home)
	a := agent.New(cfg, nil, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	sup := supervisor.New()
	return Deps{Token: token, Led: led, Mem: mem, Agent: a, Sup: sup}, sup
}

func do(h http.Handler, method, path, token, ip, body string) *httptest.ResponseRecorder {
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.RemoteAddr = ip + ":5555"
	if token != "" {
		req.Header.Set("X-Token", token)
	}
	h.ServeHTTP(rec, req)
	return rec
}

func TestPanelNeedsTheTokenAndRejectsAnEmptyOne(t *testing.T) {
	d, _ := deps(t, "s3cret")
	h := Handler(d, NewLimiter())
	for _, tc := range []struct {
		token string
		want  int
	}{{"s3cret", 200}, {"bad", 401}, {"", 401}, {"é", 401}} {
		if rec := do(h, "GET", "/api/status", tc.token, "1.1.1.1", ""); rec.Code != tc.want {
			t.Errorf("%q: %d", tc.token, rec.Code)
		}
	}
	d0, _ := deps(t, "")
	if do(Handler(d0, NewLimiter()), "GET", "/api/status", "", "1.1.1.1", "").Code != 401 {
		t.Error("пустой токен в настройках открыл панель")
	}
	if do(h, "GET", "/health", "", "1.1.1.1", "").Code != 200 {
		t.Error("health без токена")
	}
}

func TestTokenGuessingIsBlockedPerAddressAndTheRightTokenResetsTheCount(t *testing.T) {
	d, _ := deps(t, "right")
	now := time.Now()
	lim := NewLimiter()
	lim.Now = func() time.Time { return now }
	h := Handler(d, lim)
	for i := 0; i < 5; i++ {
		do(h, "GET", "/api/status", "wrong"+strings.Repeat("x", i), "9.9.9.9", "")
	}
	if rec := do(h, "GET", "/api/status", "right", "9.9.9.9", ""); rec.Code != 429 {
		t.Fatalf("после 5 неверных даже верный токен должен ждать: %d", rec.Code)
	}
	if rec := do(h, "GET", "/api/status", "right", "8.8.8.8", ""); rec.Code != 200 {
		t.Fatalf("другой адрес не должен страдать: %d", rec.Code)
	}
	now = now.Add(2 * time.Minute)
	if rec := do(h, "GET", "/api/status", "right", "9.9.9.9", ""); rec.Code != 200 {
		t.Fatalf("блокировка не снялась: %d", rec.Code)
	}
	for i := 0; i < 4; i++ {
		do(h, "GET", "/api/status", "bad", "7.7.7.7", "")
	}
	do(h, "GET", "/api/status", "right", "7.7.7.7", "")
	do(h, "GET", "/api/status", "bad", "7.7.7.7", "")
	if rec := do(h, "GET", "/api/status", "right", "7.7.7.7", ""); rec.Code != 200 {
		t.Fatal("верный токен должен обнулять счётчик ошибок")
	}
}

func TestModulesCanBeListedAndSwitchedFromThePanelButNotThePanelItself(t *testing.T) {
	d, sup := deps(t, "t")
	sup.Add(dummy{"voice"}, true)
	ctx, cancel := context.WithCancel(context.Background())
	sup.Start(ctx)
	defer func() { cancel(); sup.Wait() }()
	h := Handler(d, NewLimiter())
	time.Sleep(50 * time.Millisecond)
	if rec := do(h, "GET", "/api/modules", "t", "1.1.1.1", ""); !strings.Contains(rec.Body.String(), `"voice"`) || !strings.Contains(rec.Body.String(), "running") {
		t.Fatal(rec.Body.String())
	}
	if rec := do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"voice","enabled":false}`); !strings.Contains(rec.Body.String(), "stopped") {
		t.Fatal(rec.Body.String())
	}
	if do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"panel","enabled":false}`).Code != 400 {
		t.Fatal("панель не должна выключать сама себя")
	}
	if do(h, "POST", "/api/modules", "t", "1.1.1.1", `{"name":"нет","enabled":true}`).Code != 400 {
		t.Fatal("неизвестный модуль")
	}
}

func TestMemoryCanBeListedAndAFactDeletedThroughThePanel(t *testing.T) {
	d, _ := deps(t, "t")
	id, _ := d.Mem.Add("секретный факт", "user", 0)
	h := Handler(d, NewLimiter())
	if !strings.Contains(do(h, "GET", "/api/memory", "t", "1.1.1.1", "").Body.String(), "секретный факт") {
		t.Fatal("факт не виден")
	}
	if do(h, "DELETE", "/api/memory?id=999", "t", "1.1.1.1", "").Code != 404 {
		t.Fatal("несуществующий факт")
	}
	do(h, "DELETE", "/api/memory?id="+fmt.Sprint(id), "t", "1.1.1.1", "")
	if d.Mem.Len() != 0 {
		t.Fatal("факт не удалён")
	}
}

func TestPasswordHashAndGenerator(t *testing.T) {
	h := HashPassword("секрет-123")
	if !CheckPassword("секрет-123", h) || CheckPassword("секрет-124", h) || CheckPassword("", h) {
		t.Fatal("проверка пароля")
	}
	if strings.Contains(h, "секрет") {
		t.Fatal("пароль не должен лежать в хеше")
	}
	a, b := NewPassword(), NewPassword()
	if a == b || len(a) != 23 {
		t.Fatalf("пароль: %q %q", a, b)
	}
	if CheckPassword("x", "garbage") || CheckPassword("x", "pbkdf2$1$zz$zz") {
		t.Fatal("мусорный хеш должен отклоняться")
	}
}

func TestLoginCookieCSRFAndLockout(t *testing.T) {
	d, _ := deps(t, "tok")
	hash := HashPassword("good-pass")
	d.PassHash = func() string { return hash }
	lim := NewLimiter()
	lim.Max, lim.Lock = 3, time.Minute
	h := Handler(d, lim)
	post := func(path, body, ip string, hdr map[string]string, cookie *http.Cookie) *httptest.ResponseRecorder {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest("POST", path, strings.NewReader(body))
		req.RemoteAddr = ip + ":1"
		for k, v := range hdr {
			req.Header.Set(k, v)
		}
		if cookie != nil {
			req.AddCookie(cookie)
		}
		h.ServeHTTP(rec, req)
		return rec
	}
	x := map[string]string{"X-Requested-With": "reina"}
	if r := post("/login", `{"password":"good-pass"}`, "1.1.1.1", nil, nil); r.Code != 400 {
		t.Fatalf("без заголовка CSRF вход невозможен: %d", r.Code)
	}
	r := post("/login", `{"password":"good-pass"}`, "1.1.1.1", x, nil)
	if r.Code != 200 {
		t.Fatalf("вход: %d %s", r.Code, r.Body.String())
	}
	var ck *http.Cookie
	for _, c := range r.Result().Cookies() {
		if c.Name == "reina_session" {
			ck = c
		}
	}
	if ck == nil || !ck.HttpOnly || ck.SameSite != http.SameSiteStrictMode {
		t.Fatalf("cookie: %+v", ck)
	}
	get := func(path string, c *http.Cookie) int {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest("GET", path, nil)
		req.RemoteAddr = "1.1.1.1:1"
		if c != nil {
			req.AddCookie(c)
		}
		h.ServeHTTP(rec, req)
		return rec.Code
	}
	if get("/api/status", ck) != 200 || get("/api/status", nil) != 401 {
		t.Fatal("API: с сессией да, без нет")
	}
	if r := post("/api/memory", "", "1.1.1.1", nil, ck); r.Code != 401 {
		t.Fatalf("изменение через cookie без заголовка CSRF должно отклоняться: %d", r.Code)
	}
	rec := httptest.NewRecorder()
	req := httptest.NewRequest("GET", "/", nil)
	h.ServeHTTP(rec, req)
	if !strings.Contains(rec.Header().Get("Content-Security-Policy"), "default-src 'none'") || !strings.Contains(rec.Body.String(), "Рейна") {
		t.Fatal("страница и защитные заголовки")
	}
	for i := 0; i < 3; i++ {
		post("/login", `{"password":"bad"}`, "9.9.9.9", x, nil)
	}
	if r := post("/login", `{"password":"good-pass"}`, "9.9.9.9", x, nil); r.Code != 429 {
		t.Fatalf("после неверных попыток адрес блокируется, даже с верным паролем: %d", r.Code)
	}
}

func TestClientIPBehindTunnelUsesHeaderOnlyFromLoopback(t *testing.T) {
	r := httptest.NewRequest("GET", "/", nil)
	r.RemoteAddr = "127.0.0.1:5"
	r.Header.Set("CF-Connecting-IP", "5.6.7.8")
	if clientIP(r) != "5.6.7.8" {
		t.Fatal("за туннелем берём адрес из заголовка")
	}
	r.RemoteAddr = "8.8.8.8:5"
	if clientIP(r) != "8.8.8.8" {
		t.Fatal("с чужого адреса заголовку не верим")
	}
}
