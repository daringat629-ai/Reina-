package panel

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"reina/internal/config"
)

// setting: одна настройка, которую можно менять из панели. Ключей, паролей и токенов тут нет и не будет.
type setting struct {
	Key   string   `json:"key"`   // путь в config.json: agent.think
	Label string   `json:"label"` // подпись
	Group string   `json:"group"` // раздел
	Kind  string   `json:"kind"`  // bool, int, float, text, long, enum, list
	Min   float64  `json:"min,omitempty"`
	Max   float64  `json:"max,omitempty"`
	Opts  []string `json:"opts,omitempty"`
	Def   any      `json:"def,omitempty"` // значение по умолчанию, когда в файле пусто
	Help  string   `json:"help,omitempty"`
}

var settingsTable = []setting{
	{Key: "agent.persona", Label: "Характер (persona)", Group: "Характер", Kind: "long", Help: "Системный промпт Рейны. Меняется после перезапуска."},
	{Key: "agent.owner_note", Label: "Что знает про хозяина", Group: "Характер", Kind: "long"},
	{Key: "agent.temperature", Label: "Живость речи", Group: "Характер", Kind: "float", Min: 0, Max: 1.5, Def: 0.9},
	{Key: "agent.typo_pct", Label: "Шанс опечатки, %", Group: "Характер", Kind: "int", Min: 0, Max: 50, Def: 3},
	{Key: "agent.spont_pct", Label: "Шанс самой поставить реакцию/стикер, %", Group: "Характер", Kind: "int", Min: 0, Max: 100, Def: 25},
	{Key: "agent.voice_pct", Label: "Шанс ответить голосом, когда захотелось, %", Group: "Характер", Kind: "int", Min: 0, Max: 100, Def: 40},

	{Key: "agent.think", Label: "Думать перед ответом (второй проход)", Group: "Мозг", Kind: "bool", Def: true},
	{Key: "agent.think_model", Label: "Модель для мыслей", Group: "Мозг", Kind: "text", Def: "qwen/qwen3-8b"},
	{Key: "llm.fast_model", Label: "Быстрая модель (болтовня)", Group: "Мозг", Kind: "text"},
	{Key: "llm.strong_model", Label: "Сильная модель (дела, инструменты)", Group: "Мозг", Kind: "text"},
	{Key: "llm.vision_model", Label: "Модель для картинок", Group: "Мозг", Kind: "text"},
	{Key: "agent.max_steps", Label: "Шагов «подумала-сделала» за ответ", Group: "Мозг", Kind: "int", Min: 1, Max: 40, Def: 6},
	{Key: "agent.shell_policy", Label: "Команды shell", Group: "Мозг", Kind: "enum", Opts: []string{"ask", "always", "never"}, Def: "ask", Help: "ask: спрашивать, always: без вопросов, never: запретить"},
	{Key: "budget.daily_usd", Label: "Потолок расходов в сутки, $", Group: "Мозг", Kind: "float", Min: 0, Max: 1000, Def: 1, Help: "0: без потолка"},

	{Key: "agent.human_delay", Label: "Человеческая пауза «печатает…»", Group: "Темп", Kind: "bool", Def: true},
	{Key: "agent.chunk_max", Label: "Символов в одном сообщении", Group: "Темп", Kind: "int", Min: -1, Max: 4000, Def: 60, Help: "-1: не резать"},
	{Key: "agent.max_chunks", Label: "Сообщений за один ответ, максимум", Group: "Темп", Kind: "int", Min: 1, Max: 100, Def: 40},

	{Key: "telegram.open_dm", Label: "Отвечать чужим в личке", Group: "Telegram", Kind: "bool", Def: true},
	{Key: "telegram.dm_daily_max", Label: "Сообщений в сутки от одного чужого", Group: "Telegram", Kind: "int", Min: 1, Max: 1000, Def: 40},
	{Key: "telegram.notify_new_dm", Label: "Сообщать мне о новом собеседнике", Group: "Telegram", Kind: "bool", Def: true},
	{Key: "telegram.group_chime_pct", Label: "Шанс вклиниться в группе без зова, %", Group: "Telegram", Kind: "int", Min: -1, Max: 100, Def: 6, Help: "-1: выключить"},
	{Key: "telegram.group_cool_sec", Label: "Пауза между её ответами в группе, сек", Group: "Telegram", Kind: "int", Min: 0, Max: 3600, Def: 15},
	{Key: "telegram.group_names", Label: "Имена, на которые откликается в группе", Group: "Telegram", Kind: "list", Help: "через запятую"},

	{Key: "voice.reply", Label: "Голосовые ответы", Group: "Голос и картинки", Kind: "enum", Opts: []string{"mirror", "always", "never"}, Def: "mirror", Help: "mirror: голосом на голосовое"},
	{Key: "voice.max_chars", Label: "Длиннее этого отвечает текстом", Group: "Голос и картинки", Kind: "int", Min: 50, Max: 5000, Def: 600},
	{Key: "images.max_daily", Label: "Картинок в сутки", Group: "Голос и картинки", Kind: "int", Min: 0, Max: 500, Def: 20},
	{Key: "images.look", Label: "Как она выглядит (для селфи)", Group: "Голос и картинки", Kind: "long"},

	{Key: "initiative.disabled", Label: "Не писать первой (выключить инициативу)", Group: "Инициатива", Kind: "bool", Def: false},
	{Key: "initiative.idle_min", Label: "Тишина до того, как может написать первой, мин", Group: "Инициатива", Kind: "int", Min: 5, Max: 10080, Def: 180},
	{Key: "initiative.check_min", Label: "Как часто взвешивает «написать ли», мин", Group: "Инициатива", Kind: "int", Min: 5, Max: 1440, Def: 45},
	{Key: "initiative.from_hour", Label: "Не пишет раньше (час)", Group: "Инициатива", Kind: "int", Min: 0, Max: 23, Def: 10},
	{Key: "initiative.to_hour", Label: "и позже (час)", Group: "Инициатива", Kind: "int", Min: 0, Max: 24, Def: 23},
	{Key: "initiative.max_per_day", Label: "Писем первой в сутки", Group: "Инициатива", Kind: "int", Min: 0, Max: 50, Def: 3},
	{Key: "initiative.pct", Label: "Шанс на каждой проверке, %", Group: "Инициатива", Kind: "int", Min: 0, Max: 100, Def: 35},
	{Key: "initiative.channels", Label: "Каналы, которые читает для дайджеста", Group: "Инициатива", Kind: "list", Help: "@имя через запятую"},
	{Key: "initiative.digest_hour", Label: "Час дайджеста каналов", Group: "Инициатива", Kind: "int", Min: 0, Max: 23, Def: 12},

	{Key: "panel.no_tunnel", Label: "Не поднимать туннель Cloudflare", Group: "Панель", Kind: "bool", Def: false},
}

func findSetting(key string) *setting {
	for i := range settingsTable {
		if settingsTable[i].Key == key {
			return &settingsTable[i]
		}
	}
	return nil
}

func cfgMap(c config.Config) (map[string]any, error) {
	raw, err := json.Marshal(c)
	if err != nil {
		return nil, err
	}
	m := map[string]any{}
	return m, json.Unmarshal(raw, &m)
}

func lookup(m map[string]any, key string) any {
	var cur any = m
	for _, p := range strings.Split(key, ".") {
		mm, ok := cur.(map[string]any)
		if !ok {
			return nil
		}
		cur = mm[p]
	}
	return cur
}

func assign(m map[string]any, key string, v any) {
	parts := strings.Split(key, ".")
	cur := m
	for _, p := range parts[:len(parts)-1] {
		next, ok := cur[p].(map[string]any)
		if !ok {
			next = map[string]any{}
			cur[p] = next
		}
		cur = next
	}
	cur[parts[len(parts)-1]] = v
}

// settingsView: таблица настроек с текущими значениями из config.json (null: в файле не задано, действует значение по умолчанию).
func settingsView(c config.Config) ([]map[string]any, error) {
	m, err := cfgMap(c)
	if err != nil {
		return nil, err
	}
	out := make([]map[string]any, 0, len(settingsTable))
	for _, s := range settingsTable {
		v := lookup(m, s.Key)
		if l, ok := v.([]any); ok { // списки показываем строкой через запятую
			var parts []string
			for _, x := range l {
				parts = append(parts, fmt.Sprint(x))
			}
			v = strings.Join(parts, ", ")
		}
		out = append(out, map[string]any{"key": s.Key, "label": s.Label, "group": s.Group, "kind": s.Kind, "min": s.Min, "max": s.Max, "opts": s.Opts, "def": s.Def, "help": s.Help, "value": v})
	}
	return out, nil
}

// applySetting проверяет значение по таблице и меняет конфиг. Изменить можно только то, что есть в таблице.
func applySetting(c config.Config, key string, raw any) (config.Config, error) {
	s := findSetting(key)
	if s == nil {
		return c, fmt.Errorf("эту настройку менять из панели нельзя")
	}
	var v any
	switch s.Kind {
	case "bool":
		b, ok := raw.(bool)
		if !ok {
			return c, fmt.Errorf("нужно да/нет")
		}
		v = b
	case "int", "float":
		var f float64
		switch x := raw.(type) {
		case float64:
			f = x
		case string:
			p, err := strconv.ParseFloat(strings.ReplaceAll(strings.TrimSpace(x), ",", "."), 64)
			if err != nil {
				return c, fmt.Errorf("нужно число")
			}
			f = p
		default:
			return c, fmt.Errorf("нужно число")
		}
		if f < s.Min || f > s.Max {
			return c, fmt.Errorf("допустимо от %v до %v", s.Min, s.Max)
		}
		if s.Kind == "int" {
			v = int(f)
		} else {
			v = f
		}
	case "enum":
		str, _ := raw.(string)
		ok := false
		for _, o := range s.Opts {
			ok = ok || o == str
		}
		if !ok {
			return c, fmt.Errorf("допустимо: %s", strings.Join(s.Opts, ", "))
		}
		v = str
	case "list":
		str, _ := raw.(string)
		var l []string
		for _, p := range strings.Split(str, ",") {
			if p = strings.TrimSpace(p); p != "" {
				l = append(l, p)
			}
		}
		v = l
	default: // text, long
		str, ok := raw.(string)
		if !ok {
			return c, fmt.Errorf("нужен текст")
		}
		if len([]rune(str)) > 20000 {
			return c, fmt.Errorf("слишком длинно")
		}
		v = str
	}
	m, err := cfgMap(c)
	if err != nil {
		return c, err
	}
	assign(m, s.Key, v)
	raw2, err := json.Marshal(m)
	if err != nil {
		return c, err
	}
	var out config.Config
	if err := json.Unmarshal(raw2, &out); err != nil {
		return c, fmt.Errorf("значение не подошло: %v", err)
	}
	out.Home = c.Home // каталог данных в json не хранится
	return out, nil
}
