// Package panel: небольшая панель состояния по HTTP (по умолчанию только 127.0.0.1).
// Доступ по токену в заголовке X-Token. Защита от перебора: после нескольких неверных токенов с одного адреса он блокируется на время.
// Для доступа не с этого компьютера нужен https или защищённый туннель (Tailscale и подобные): сама панель токен по сети в открытом виде не защитит.
package panel

import (
	"context"
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/memory"
	"reina/internal/supervisor"
	"reina/internal/tools"
)

//go:embed web/index.html
var indexHTML []byte

// Limiter считает неверные попытки по адресу.
type Limiter struct {
	mu    sync.Mutex
	fails map[string]*rec
	Max   int
	Lock  time.Duration
	Now   func() time.Time
}

type rec struct {
	n     int
	until time.Time
}

func NewLimiter() *Limiter {
	return &Limiter{fails: map[string]*rec{}, Max: 5, Lock: time.Minute, Now: time.Now}
}

// Blocked: адрес сейчас заблокирован.
func (l *Limiter) Blocked(ip string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	r := l.fails[ip]
	return r != nil && l.Now().Before(r.until)
}

func (l *Limiter) Fail(ip string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	r := l.fails[ip]
	if r == nil {
		if len(l.fails) > 1000 { // адресов слишком много: начинаем счёт заново, память не растёт
			l.fails = map[string]*rec{}
		}
		r = &rec{}
		l.fails[ip] = r
	}
	if r.until.Before(l.Now()) && r.n >= l.Max {
		r.n = 0 // блокировка кончилась: счёт с нуля
	}
	r.n++
	if r.n >= l.Max {
		r.until = l.Now().Add(l.Lock)
	}
}

func (l *Limiter) OK(ip string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	delete(l.fails, ip)
}

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	if ip := net.ParseIP(h); ip != nil && ip.IsLoopback() { // за туннелем (cloudflared) настоящий адрес приходит в заголовке
		if v := r.Header.Get("CF-Connecting-IP"); v != "" {
			return v
		}
	}
	return h
}

type Deps struct {
	PassHash func() string         // хеш пароля для входа через сайт (пусто: вход по паролю выключен)
	Rem      *tools.Reminders      // напоминания (для окна «Напоминания»)
	Logs     *LogRing              // последние строки лога
	Info     func() map[string]any // краткая сводка настроек (без секретов)
	Token    string
	Led      *budget.Ledger
	Mem      memory.Store
	Agent    *agent.Agent
	Sup      *supervisor.Supervisor
	Ext      *Ext // расширения: чаты, настройки, галерея, консоль… (nil: только базовые окна)
}

func Handler(d Deps, lim *Limiter) http.Handler {
	mux := http.NewServeMux()
	ses := newSessions()
	fp := func() string {
		if d.PassHash == nil {
			return ""
		}
		h := d.PassHash()
		if len(h) > 40 {
			return h[len(h)-40:]
		}
		return h
	}
	cookieOK := func(r *http.Request) bool {
		c, err := r.Cookie("reina_session")
		if err != nil || !ses.Valid(c.Value, fp()) {
			return false
		}
		// CSRF: запросы, меняющие данные, только со своей страницы (заголовок, который чужой сайт отправить не может)
		return r.Method == http.MethodGet || r.Header.Get("X-Requested-With") == "reina"
	}
	auth := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			ip := clientIP(r)
			if lim.Blocked(ip) {
				w.Header().Set("Retry-After", "60")
				http.Error(w, `{"error":"too many attempts"}`, http.StatusTooManyRequests)
				return
			}
			if !cookieOK(r) && (d.Token == "" || subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Token")), []byte(d.Token)) != 1) {
				lim.Fail(ip)
				http.Error(w, `{"error":"token"}`, http.StatusUnauthorized)
				return
			}
			lim.OK(ip)
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("Cache-Control", "no-store")
			h(w, r)
		}
	}
	mux.HandleFunc("/api/status", auth(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"ok": true, "today": d.Led.Today(), "facts": d.Mem.Len(), "sessions": d.Agent.SessionCount()})
	}))
	mux.HandleFunc("/api/modules", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost { // {"name":"telegram","enabled":false}
			var b struct {
				Name    string `json:"name"`
				Enabled bool   `json:"enabled"`
			}
			if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&b) != nil || b.Name == "" {
				http.Error(w, `{"error":"bad request"}`, http.StatusBadRequest)
				return
			}
			if b.Name == "panel" && !b.Enabled {
				http.Error(w, `{"error":"панель нельзя выключить из самой панели"}`, http.StatusBadRequest)
				return
			}
			var err error
			if b.Enabled {
				err = d.Sup.Enable(b.Name)
			} else {
				err = d.Sup.Disable(b.Name)
			}
			if err != nil {
				http.Error(w, `{"error":`+quote(err.Error())+`}`, http.StatusBadRequest)
				return
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"modules": d.Sup.Status()})
	}))
	mux.HandleFunc("/api/memory", auth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			var id int64
			if _, err := fmt.Sscan(r.URL.Query().Get("id"), &id); err != nil || !d.Mem.Delete(id) {
				http.Error(w, `{"error":"нет такого факта"}`, http.StatusNotFound)
				return
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"facts": d.Mem.List(100)})
	}))
	mux.HandleFunc("/api/pages", auth(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"pages": d.Agent.RecentPages(8), "mood": d.Agent.Mood()})
	}))
	mux.HandleFunc("/api/reminders", auth(func(w http.ResponseWriter, r *http.Request) {
		var out []map[string]any
		if d.Rem != nil {
			for _, x := range d.Rem.List() {
				out = append(out, map[string]any{"id": x.ID, "at": x.At.In(d.Rem.Loc).Format("2006-01-02 15:04"), "text": x.Text})
			}
		}
		json.NewEncoder(w).Encode(map[string]any{"reminders": out})
	}))
	mux.HandleFunc("/api/logs", auth(func(w http.ResponseWriter, r *http.Request) {
		var lines []string
		if d.Logs != nil {
			lines = d.Logs.Last(80)
		}
		json.NewEncoder(w).Encode(map[string]any{"lines": lines})
	}))
	mux.HandleFunc("/api/info", auth(func(w http.ResponseWriter, r *http.Request) {
		var info map[string]any
		if d.Info != nil {
			info = d.Info()
		}
		json.NewEncoder(w).Encode(map[string]any{"info": info})
	}))
	d.registerExt(mux, auth)
	mux.HandleFunc("/api/me", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		c, err := r.Cookie("reina_session")
		json.NewEncoder(w).Encode(map[string]any{"auth": err == nil && ses.Valid(c.Value, fp()), "password_login": d.PassHash != nil && d.PassHash() != ""})
	})
	mux.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		ip := clientIP(r)
		if r.Method != http.MethodPost || r.Header.Get("X-Requested-With") != "reina" {
			http.Error(w, `{"error":"bad request"}`, http.StatusBadRequest)
			return
		}
		if lim.Blocked(ip) {
			w.Header().Set("Retry-After", "600")
			http.Error(w, `{"error":"слишком много попыток, подожди"}`, http.StatusTooManyRequests)
			return
		}
		var b struct {
			Password string `json:"password"`
		}
		hash := ""
		if d.PassHash != nil {
			hash = d.PassHash()
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&b) != nil || hash == "" || !CheckPassword(strings.TrimSpace(b.Password), hash) {
			lim.Fail(ip)
			time.Sleep(700 * time.Millisecond) // перебор не ускоряется
			http.Error(w, `{"error":"неверный пароль"}`, http.StatusUnauthorized)
			return
		}
		lim.OK(ip)
		secure := r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https"
		http.SetCookie(w, &http.Cookie{Name: "reina_session", Value: ses.New(fp()), Path: "/", HttpOnly: true, Secure: secure, SameSite: http.SameSiteStrictMode, MaxAge: 12 * 3600})
		w.Write([]byte(`{"ok":true}`))
	})
	mux.HandleFunc("/logout", func(w http.ResponseWriter, r *http.Request) {
		if c, err := r.Cookie("reina_session"); err == nil {
			ses.Drop(c.Value)
		}
		http.SetCookie(w, &http.Cookie{Name: "reina_session", Value: "", Path: "/", MaxAge: -1, HttpOnly: true})
		w.Write([]byte(`{"ok":true}`))
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Write(indexHTML)
	})
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) { w.Write([]byte("ok")) })
	return secure(mux)
}

// secure добавляет защитные заголовки ко всем ответам.
func secure(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hd := w.Header()
		hd.Set("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
		hd.Set("X-Content-Type-Options", "nosniff")
		hd.Set("X-Frame-Options", "DENY")
		hd.Set("Referrer-Policy", "no-referrer")
		hd.Set("Strict-Transport-Security", "max-age=31536000")
		h.ServeHTTP(w, r)
	})
}

func quote(s string) string { b, _ := json.Marshal(s); return string(b) }

// Module: панель как модуль под присмотром супервизора.
type Module struct {
	Addr string
	H    http.Handler
	mu   sync.Mutex
	srv  *http.Server
}

func (m *Module) Name() string { return "panel" }

func (m *Module) Run(ctx context.Context) error {
	srv := &http.Server{Addr: m.Addr, Handler: m.H, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second}
	ln, err := net.Listen("tcp", m.Addr)
	if err != nil {
		return err
	}
	m.mu.Lock()
	m.srv = srv
	m.mu.Unlock()
	go func() {
		<-ctx.Done()
		sh, c := context.WithTimeout(context.Background(), 3*time.Second)
		defer c()
		srv.Shutdown(sh)
	}()
	if err := srv.Serve(ln); err != nil && err != http.ErrServerClosed {
		return err
	}
	return nil
}

// Health: панель должна отвечать на /health.
func (m *Module) Health() error {
	addr := m.Addr
	if strings.HasPrefix(addr, ":") {
		addr = "127.0.0.1" + addr
	}
	c := http.Client{Timeout: 2 * time.Second}
	resp, err := c.Get("http://" + addr + "/health")
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}
