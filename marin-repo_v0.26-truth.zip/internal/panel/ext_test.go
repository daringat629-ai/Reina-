package panel

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"reina/internal/config"
)

func extDeps(t *testing.T) (http.Handler, Deps, *[]string) {
	d, _ := deps(t, "tok")
	home := d.Agent.Home()
	cfg := config.Default()
	cfg.Home = home
	if err := config.Save(cfg); err != nil {
		t.Fatal(err)
	}
	var calls []string
	d.Ext = &Ext{
		Home: home, Version: "t", Started: time.Now(),
		LoadConfig: func() (config.Config, error) { return config.Load(home) },
		SaveConfig: config.Save,
		Send: func(ctx context.Context, chat int64, text string) error {
			calls = append(calls, "send:"+text)
			return nil
		},
		Blocked:    func() []int64 { return []int64{5} },
		SetBlocked: func(id int64, on bool) { calls = append(calls, "block") },
		BackupNow:  func() (string, error) { return "", nil },
	}
	return Handler(d, NewLimiter()), d, &calls
}

func call(h http.Handler, method, path, body string) *httptest.ResponseRecorder {
	return do(h, method, path, "tok", "1.1.1.1", body)
}

func TestSettingsOnlyFromTheWhitelistAndValidated(t *testing.T) {
	h, d, _ := extDeps(t)
	// видна таблица, а секретов в ней нет
	rec := call(h, "GET", "/api/settings", "")
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), "agent.think") {
		t.Fatalf("%d %s", rec.Code, rec.Body.String())
	}
	for _, secret := range []string{"api_key", "api_hash", "password_hash", `"token"`} {
		if strings.Contains(rec.Body.String(), secret) {
			t.Fatalf("в настройках секрет %s", secret)
		}
	}
	// верное значение пишется в config.json
	if rec := call(h, "POST", "/api/settings", `{"key":"agent.typo_pct","value":7}`); rec.Code != 200 {
		t.Fatalf("%d %s", rec.Code, rec.Body.String())
	}
	c, _ := config.Load(d.Agent.Home())
	if c.Agent.TypoPct == nil || *c.Agent.TypoPct != 7 {
		t.Fatalf("не записалось: %+v", c.Agent.TypoPct)
	}
	// чужой ключ, выход за границы, не тот тип: отказ, файл не тронут
	for _, body := range []string{`{"key":"llm.api_key","value":"x"}`, `{"key":"panel.password_hash","value":"x"}`, `{"key":"agent.typo_pct","value":999}`, `{"key":"agent.think","value":"да"}`, `{"key":"agent.shell_policy","value":"rm -rf"}`} {
		if rec := call(h, "POST", "/api/settings", body); rec.Code != 400 {
			t.Errorf("%s должен быть отклонён: %d", body, rec.Code)
		}
	}
	c, _ = config.Load(d.Agent.Home())
	if c.LLM.APIKey != "" || *c.Agent.TypoPct != 7 {
		t.Fatal("отказанные изменения попали в файл")
	}
	// список и текст
	if rec := call(h, "POST", "/api/settings", `{"key":"telegram.group_names","value":"рейна, рейн ,reina"}`); rec.Code != 200 {
		t.Fatal(rec.Body.String())
	}
	c, _ = config.Load(d.Agent.Home())
	if len(c.Telegram.GroupNames) != 3 || c.Telegram.GroupNames[1] != "рейн" {
		t.Fatalf("%v", c.Telegram.GroupNames)
	}
}

func TestImagesAndBackupsRejectPathTricks(t *testing.T) {
	h, d, _ := extDeps(t)
	home := d.Agent.Home()
	os.MkdirAll(filepath.Join(home, "images"), 0o700)
	os.WriteFile(filepath.Join(home, "images", "a.png"), []byte("PNG"), 0o600)
	os.WriteFile(filepath.Join(home, "config.json.bak"), []byte("secret"), 0o600)
	if rec := call(h, "GET", "/api/image?name=a.png", ""); rec.Code != 200 || rec.Body.String() != "PNG" || rec.Header().Get("Content-Type") != "image/png" {
		t.Fatalf("%d %q %q", rec.Code, rec.Body.String(), rec.Header().Get("Content-Type"))
	}
	for _, bad := range []string{"../config.json", "..%2Fconfig.json", "a.png%00", "config.json", "..", "/etc/passwd"} {
		if rec := call(h, "GET", "/api/image?name="+bad, ""); rec.Code != 404 {
			t.Errorf("image %q: %d", bad, rec.Code)
		}
		if rec := call(h, "GET", "/api/backup?name="+bad, ""); rec.Code != 404 {
			t.Errorf("backup %q: %d", bad, rec.Code)
		}
	}
	if rec := call(h, "GET", "/api/images", ""); !strings.Contains(rec.Body.String(), "a.png") {
		t.Fatal(rec.Body.String())
	}
}

func TestConsoleIsOffByDefaultAndSendIsValidated(t *testing.T) {
	h, d, calls := extDeps(t)
	if rec := call(h, "POST", "/api/console", `{"command":"id"}`); rec.Code != 404 {
		t.Fatalf("консоль должна быть выключена: %d", rec.Code)
	}
	if rec := call(h, "POST", "/api/send", `{"chat":0,"text":"x"}`); rec.Code != 400 {
		t.Fatal(rec.Code)
	}
	if rec := call(h, "POST", "/api/send", `{"chat":5,"text":"  "}`); rec.Code != 400 {
		t.Fatal(rec.Code)
	}
	if rec := call(h, "POST", "/api/send", `{"chat":5,"text":"привет"}`); rec.Code != 200 || len(*calls) != 1 {
		t.Fatalf("%d %v", rec.Code, *calls)
	}
	// консоль включается только функцией, которую даёт ядро
	d.Ext.Console = func(ctx context.Context, c string) string { return "ran:" + c }
	h2 := Handler(d, NewLimiter())
	rec := call(h2, "POST", "/api/console", `{"command":"id"}`)
	var r struct{ Output string }
	json.Unmarshal(rec.Body.Bytes(), &r)
	if rec.Code != 200 || r.Output != "ran:id" {
		t.Fatalf("%d %s", rec.Code, rec.Body.String())
	}
}

func TestExtRequiresAuthAndCSRFForChanges(t *testing.T) {
	h, _, _ := extDeps(t)
	for i, p := range []string{"/api/sessions", "/api/settings", "/api/images", "/api/backups", "/api/access", "/api/usage", "/api/system", "/api/people", "/api/diary"} {
		if rec := do(h, "GET", p, "", "2.2.2."+string(rune('0'+i)), ""); rec.Code != 401 {
			t.Errorf("%s без входа: %d", p, rec.Code)
		}
	}
	if rec := call(h, "GET", "/api/usage?days=3", ""); rec.Code != 200 || !strings.Contains(rec.Body.String(), `"days"`) {
		t.Fatal(rec.Body.String())
	}
}
