package tunnel

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestFindURL(t *testing.T) {
	l := "2026-10-17T10:00:00Z INF |  https://quiet-river-1234.trycloudflare.com                                  |"
	if FindURL(l) != "https://quiet-river-1234.trycloudflare.com" {
		t.Fatal(FindURL(l))
	}
	if FindURL("INF Requesting new quick Tunnel on https://api.trycloudflare.com ...") != "" {
		t.Fatal("api.trycloudflare.com это не панель")
	}
	if FindURL("see https://api.trycloudflare.com and https://real-one-9.trycloudflare.com") != "https://real-one-9.trycloudflare.com" {
		t.Fatal("берём настоящий адрес, а не служебный")
	}
	if FindURL("https://example.com") != "" {
		t.Fatal("чужие адреса не берём")
	}
}

func TestModuleReportsURLFromProcessOutput(t *testing.T) {
	d := t.TempDir()
	bin := filepath.Join(d, "fake-cloudflared")
	os.WriteFile(bin, []byte("#!/bin/sh\necho 'INF https://test-name-77.trycloudflare.com' >&2\nsleep 5\n"), 0o755)
	got := make(chan string, 1)
	m := &Module{Home: d, Local: "127.0.0.1:1", Bin: bin, OnURL: func(u string) { got <- u }}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go m.Run(ctx)
	select {
	case u := <-got:
		if u != "https://test-name-77.trycloudflare.com" || m.URL() != u {
			t.Fatal(u, m.URL())
		}
	case <-time.After(5 * time.Second):
		t.Fatal("ссылка не получена")
	}
}
