package images

import (
	"context"
	"encoding/base64"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestMakeSavesAndAddsSafetyAndLimit(t *testing.T) {
	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		got = string(b)
		w.Write([]byte(`{"data":[{"b64_json":"` + base64.StdEncoding.EncodeToString(make([]byte, 300)) + `","media_type":"image/png"}]}`))
	}))
	defer srv.Close()
	c := New(Config{BaseURL: srv.URL, APIKey: "k", MaxDaily: 1, Dir: t.TempDir()})
	p, err := c.Selfie(context.Background(), "в кафе")
	if err != nil {
		t.Fatal(err)
	}
	if st, e := os.Stat(p); e != nil || st.Size() != 300 || !strings.HasSuffix(p, ".png") {
		t.Fatal("файл не сохранён", e)
	}
	if !strings.Contains(got, "swimwear") || !strings.Contains(got, "в кафе") || !strings.Contains(got, "gemini") || !strings.Contains(got, "input_references") || !strings.Contains(got, "data:image/jpeg") {
		t.Fatalf("запрос: %s", got)
	}
	if _, err := c.Make(context.Background(), "кот"); err == nil || !strings.Contains(err.Error(), "лимит") {
		t.Fatal("лимит не сработал", err)
	}
}

func TestErrorDoesNotSpendTheLimit(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(402) }))
	defer srv.Close()
	c := New(Config{BaseURL: srv.URL, APIKey: "k", MaxDaily: 1, Dir: t.TempDir()})
	for i := 0; i < 3; i++ {
		if _, err := c.Make(context.Background(), "кот"); err == nil || strings.Contains(err.Error(), "лимит") {
			t.Fatal("ошибка сервера не должна тратить лимит", err)
		}
	}
}
