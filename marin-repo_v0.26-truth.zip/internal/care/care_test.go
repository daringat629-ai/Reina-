package care

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

type dg struct{ n int }

func (d *dg) WeeklyDigest(context.Context) bool { d.n++; return true }
func (d *dg) Sleep(context.Context) bool        { return false }

func TestBackupContainsDataSkipsBackupsAndRotates(t *testing.T) {
	home := t.TempDir()
	os.WriteFile(filepath.Join(home, "config.json"), []byte("{}"), 0o600)
	os.MkdirAll(filepath.Join(home, "images"), 0o700)
	os.WriteFile(filepath.Join(home, "images", "big.png"), []byte("x"), 0o600)
	m := &Module{Home: home, Keep: 2}
	day := time.Date(2026, 1, 1, 5, 0, 0, 0, time.UTC)
	var last string
	for i := 0; i < 4; i++ {
		p, err := m.Backup(day.AddDate(0, 0, i))
		if err != nil {
			t.Fatal(err)
		}
		last = p
	}
	l, _ := filepath.Glob(filepath.Join(home, "backups", "*.tar.gz"))
	if len(l) != 2 {
		t.Fatalf("должно остаться 2 копии, есть %d", len(l))
	}
	f, _ := os.Open(last)
	gz, _ := gzip.NewReader(f)
	tr := tar.NewReader(gz)
	names := map[string]bool{}
	for {
		h, err := tr.Next()
		if err != nil {
			break
		}
		names[h.Name] = true
	}
	if !names["home/config.json"] || names["home/images/big.png"] {
		t.Fatalf("состав копии: %v", names)
	}
}

func TestDailyBackupOnceAndWeeklyDigestOnSundayEvening(t *testing.T) {
	home := t.TempDir()
	os.WriteFile(filepath.Join(home, "config.json"), []byte("{}"), 0o600)
	d := &dg{}
	now := time.Date(2026, 1, 4, 21, 0, 0, 0, time.UTC) // воскресенье
	m := &Module{Home: home, Agent: d, Now: func() time.Time { return now }}
	m.Step(context.Background())
	m.Step(context.Background())
	if d.n != 1 {
		t.Fatalf("итог недели один раз, было %d", d.n)
	}
	l, _ := filepath.Glob(filepath.Join(home, "backups", "*.tar.gz"))
	if len(l) != 1 {
		t.Fatal("копия одна в сутки")
	}
	now = now.Add(24 * time.Hour) // понедельник
	m.Step(context.Background())
	if d.n != 1 {
		t.Fatal("в понедельник итога нет")
	}
}
