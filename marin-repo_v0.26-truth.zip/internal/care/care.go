// Package care: уход за собой. Раз в сутки резервная копия данных (config, память, дневник, люди, напоминания, модули)
// и раз в неделю итог недели в дневник. Работает как модуль под присмотром supervisor.
package care

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type Digester interface {
	WeeklyDigest(ctx context.Context) bool
	Sleep(ctx context.Context) bool
}

type Module struct {
	Home   string   // ~/.marin: там config.json, память, дневник
	Extra  []string // дополнительные папки (например ~/.reina/modules)
	Keep   int      // сколько копий хранить (7)
	Agent  Digester
	Loc    *time.Location
	Now    func() time.Time
	Tick   time.Duration
	lastBk string // дата последней копии
	lastWk string // неделя последнего итога
	lastSl string // дата последнего «сна»
}

func (m *Module) Name() string  { return "care" }
func (m *Module) Health() error { return nil }

func (m *Module) Run(ctx context.Context) error {
	if m.Now == nil {
		m.Now = time.Now
	}
	if m.Tick <= 0 {
		m.Tick = 10 * time.Minute
	}
	t := time.NewTicker(m.Tick)
	defer t.Stop()
	m.Step(ctx)
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-t.C:
			m.Step(ctx)
		}
	}
}

// Step: одна проверка (для тестов).
func (m *Module) Step(ctx context.Context) {
	if m.Now == nil {
		m.Now = time.Now
	}
	loc := m.Loc
	if loc == nil {
		loc = time.UTC
	}
	now := m.Now().In(loc)
	if day := now.Format("2006-01-02"); day != m.lastBk && now.Hour() >= 4 {
		if p, err := m.Backup(now); err != nil {
			log.Printf("резервная копия не удалась: %v", err)
		} else {
			log.Printf("резервная копия: %s", p)
		}
		m.lastBk = day
	}
	if day := now.Format("2006-01-02"); day != m.lastSl && now.Hour() >= 4 && m.Agent != nil {
		if m.Agent.Sleep(ctx) {
			log.Printf("сон: старые страницы дневника склеены")
		}
		m.lastSl = day
	}
	y, w := now.ISOWeek()
	wk := fmt.Sprintf("%d-%02d", y, w)
	if now.Weekday() == time.Sunday && now.Hour() >= 20 && wk != m.lastWk && m.Agent != nil {
		if m.Agent.WeeklyDigest(ctx) {
			log.Printf("итог недели записан в дневник")
		}
		m.lastWk = wk
	}
}

// Backup пакует данные в Home/backups/reina-ГГГГ-ММ-ДД.tar.gz и удаляет старые копии.
func (m *Module) Backup(now time.Time) (string, error) {
	dir := filepath.Join(m.Home, "backups")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	out := filepath.Join(dir, "reina-"+now.Format("2006-01-02")+".tar.gz")
	tmp := out + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return "", err
	}
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	roots := append([]string{m.Home}, m.Extra...)
	for i, root := range roots {
		prefix := "home"
		if i > 0 {
			prefix = "extra" + fmt.Sprint(i)
		}
		filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
			if err != nil {
				return nil
			}
			rel, _ := filepath.Rel(root, p)
			top := strings.SplitN(rel, string(filepath.Separator), 2)[0]
			if info.IsDir() {
				if i == 0 && (top == "backups" || top == "images") {
					return filepath.SkipDir
				}
				return nil
			}
			if !info.Mode().IsRegular() || info.Size() > 50<<20 || strings.HasSuffix(p, ".tmp") {
				return nil
			}
			src, err := os.Open(p)
			if err != nil {
				return nil
			}
			defer src.Close()
			h := &tar.Header{Name: prefix + "/" + filepath.ToSlash(rel), Mode: 0o600, Size: info.Size(), ModTime: info.ModTime()}
			if tw.WriteHeader(h) != nil {
				return nil
			}
			io.Copy(tw, io.LimitReader(src, info.Size()))
			return nil
		})
	}
	if err := tw.Close(); err != nil {
		f.Close()
		return "", err
	}
	if err := gz.Close(); err != nil {
		f.Close()
		return "", err
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	if err := os.Rename(tmp, out); err != nil {
		return "", err
	}
	keep := m.Keep
	if keep <= 0 {
		keep = 7
	}
	old, _ := filepath.Glob(filepath.Join(dir, "reina-*.tar.gz"))
	sort.Strings(old)
	for len(old) > keep {
		os.Remove(old[0])
		old = old[1:]
	}
	return out, nil
}
