#!/bin/sh
# аргументы приходят JSON в stdin, ответ это stdout
uptime
