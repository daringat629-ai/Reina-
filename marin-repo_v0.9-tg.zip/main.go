// Reina: ядро бота одним бинарником. Команды: init, run, chat, usage, doctor, models, persona.
package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/panel"
	"reina/internal/supervisor"
	"reina/internal/telegram"
	"reina/internal/tools"
)

func main() {
	cmd := "run"
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}
	home := config.HomeDir()
	switch cmd {
	case "init":
		fatal(initCfg(home))
	case "import-kuni": // reina import-kuni /путь/к/config.toml прежней версии: берёт api_id и api_hash
		if len(os.Args) < 3 {
			fmt.Println("использование: reina import-kuni /путь/к/config.toml")
			os.Exit(1)
		}
		fatal(importKuni(home, os.Args[2]))
	case "persona": // reina persona: записать в config.json стандартную личность Рейны Вейл
		cfg, err := config.Load(home)
		fatal(err)
		cfg.Agent.Persona = config.Default().Agent.Persona
		fatal(config.Save(cfg))
		fmt.Println("Личность Рейны Вейл записана в", config.Path(home), "\nПерезапустите: reina run")
	case "run", "chat", "usage", "doctor", "models":
		cfg, err := config.Load(home)
		if errors.Is(err, os.ErrNotExist) {
			fmt.Println("Настроек ещё нет. Запустите: reina init")
			os.Exit(1)
		}
		fatal(err)
		switch cmd {
		case "run":
			fatal(run(cfg))
		case "chat":
			fatal(chat(cfg))
		case "usage":
			d := budget.Open(cfg.Home, cfg.Budget.DailyUSD).Today()
			fmt.Printf("сегодня: запросов %d, токенов %d/%d, $%.4f, из памяти без запроса %d\n", d.Requests, d.Prompt, d.Completion, d.USD, d.Saved)
		case "doctor":
			doctor(cfg)
		case "models":
			filter := ""
			if len(os.Args) > 2 {
				filter = os.Args[2]
			}
			fatal(models(cfg, filter))
		}
	default:
		fmt.Println("команды: init | import-kuni | run | chat | usage | doctor")
	}
}

func importKuni(home, path string) error {
	id, hash, err := config.ImportKuni(path)
	if err != nil {
		return err
	}
	cfg := config.Default()
	cfg.Home = home
	if old, err := config.Load(home); err == nil {
		cfg = old
	}
	cfg.Telegram.Mode, cfg.Telegram.APIID, cfg.Telegram.APIHash = "account", id, hash
	if err := config.Save(cfg); err != nil {
		return err
	}
	fmt.Println("api_id и api_hash перенесены. Остальное: reina init (номер телефона, ключ модели, ваш user id).")
	return nil
}

func fatal(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "ошибка:", err)
		os.Exit(1)
	}
}

func ask(r *bufio.Reader, q, def string) string {
	if def != "" {
		fmt.Printf("%s [%s]: ", q, def)
	} else {
		fmt.Printf("%s: ", q)
	}
	s, _ := r.ReadString('\n')
	s = strings.TrimSpace(s)
	if s == "" {
		return def
	}
	return s
}

func initCfg(home string) error {
	cfg := config.Default()
	cfg.Home = home
	if old, err := config.Load(home); err == nil {
		cfg = old
	}
	r := bufio.NewReader(os.Stdin)
	cfg.LLM.APIKey = ask(r, "Ключ модели (OpenRouter или другой)", cfg.LLM.APIKey)
	cfg.LLM.FastModel = ask(r, "Быстрая дешёвая модель для болтовни (список: reina models)", cfg.LLM.FastModel)
	cfg.LLM.StrongModel = ask(r, "Сильная модель для сложного и действий (может совпадать с быстрой)", cfg.LLM.StrongModel)
	cfg.LLM.VisionModel = ask(r, "Модель для картинок (vision, например qwen-vl; список: reina models qwen; пусто: картинки не разбирать)", cfg.LLM.VisionModel)
	for {
		cfg.Telegram.Mode = strings.ToLower(ask(r, "Вход в Telegram: напишите account (обычный аккаунт, как раньше) или bot (токен BotFather)", cfg.Telegram.Mode))
		if cfg.Telegram.Mode == "account" || cfg.Telegram.Mode == "bot" {
			break
		}
		fmt.Println("Нужно слово account или bot. Просто нажмите Enter, чтобы оставить account.")
		cfg.Telegram.Mode = "account"
	}
	if cfg.Telegram.Mode == "bot" {
		cfg.Telegram.Token = ask(r, "Токен Telegram-бота", cfg.Telegram.Token)
	} else {
		fmt.Println("api_id и api_hash берутся на https://my.telegram.org (API development tools); те же, что у прежней версии.")
		fmt.Sscan(ask(r, "api_id", fmt.Sprint(cfg.Telegram.APIID)), &cfg.Telegram.APIID)
		cfg.Telegram.APIHash = ask(r, "api_hash", cfg.Telegram.APIHash)
		for {
			ph, ok := config.NormalizePhone(ask(r, "Номер аккаунта Рейны в международном формате, с плюсом и кодом страны (+996...)", cfg.Telegram.Phone))
			if ok {
				cfg.Telegram.Phone = ph
				break
			}
			fmt.Println("Номер должен начинаться с + и кодом страны, например +996770239878.")
		}
		cfg.Telegram.Password = ask(r, "Пароль двухфакторной защиты (если нет, пусто)", cfg.Telegram.Password)
	}
	var id int64
	fmt.Sscan(ask(r, "Ваш user id в Telegram (узнать у @userinfobot): только вы сможете разрешать опасное", fmt.Sprint(cfg.Telegram.OwnerID)), &id)
	cfg.Telegram.OwnerID = id
	if cfg.Panel.Token == "" {
		b := make([]byte, 16)
		rand.Read(b)
		cfg.Panel.Token = hex.EncodeToString(b)
	}
	if err := config.Save(cfg); err != nil {
		return err
	}
	fmt.Println("Готово:", config.Path(home), "\nТокен панели:", cfg.Panel.Token, "\nПроверка: reina doctor")
	return nil
}

func policy(cfg config.Config) tools.Policy {
	p := tools.DefaultPolicy(cfg.Home)
	p.Shell = cfg.Agent.ShellPolicy
	if p.Shell == "" {
		p.Shell = "ask"
	}
	if len(cfg.Agent.AllowedTools) > 0 {
		p.Allowed = map[string]bool{}
		for _, n := range cfg.Agent.AllowedTools {
			p.Allowed[n] = true
		}
	}
	p.ReadRoots = cfg.Agent.ReadRoots
	p.Desktop = cfg.Agent.Desktop == nil || *cfg.Agent.Desktop
	if cfg.Agent.MaxCommand > 0 {
		p.MaxCommand = cfg.Agent.MaxCommand
	}
	if cfg.Agent.MaxDangerous > 0 {
		p.MaxDangerous = cfg.Agent.MaxDangerous
	}
	return p
}

func build(cfg config.Config) (*agent.Agent, *budget.Ledger, memory.Store) {
	led := budget.Open(cfg.Home, cfg.Budget.DailyUSD)
	mem := memory.Open(cfg.Home)
	c := llm.New(cfg.LLM.BaseURL, cfg.LLM.APIKey, cfg.LLM.TimeoutSec)
	ts := tools.Default(mem, policy(cfg))
	a := agent.New(cfg, c, led, mem, ts)
	ts.SetVision(a.Describe)
	return a, led, mem
}

func chat(cfg config.Config) error {
	a, _, _ := build(cfg)
	a.Confirm = func(_, d string) bool {
		fmt.Printf("Выполнить? %s [да/нет]: ", d)
		s, _ := bufio.NewReader(os.Stdin).ReadString('\n')
		return strings.TrimSpace(strings.ToLower(s)) == "да"
	}
	in := bufio.NewScanner(os.Stdin)
	fmt.Print("> ")
	for in.Scan() {
		ans, err := a.Reply(context.Background(), "cli", in.Text())
		if err != nil {
			fmt.Println("ошибка:", err)
		} else {
			fmt.Println(ans)
		}
		fmt.Print("> ")
	}
	return nil
}

func transport(cfg config.Config) (telegram.Transport, error) {
	t := cfg.Telegram
	if t.Mode == "bot" {
		if t.Token == "" {
			return nil, errors.New("режим bot: нужен telegram.token")
		}
		return telegram.NewBotAPI(t.Token), nil
	}
	return telegram.NewUser(telegram.UserConfig{APIID: t.APIID, APIHash: t.APIHash, Phone: t.Phone, Password: t.Password, SessionPath: filepath.Join(cfg.Home, "telegram.session")})
}

func run(cfg config.Config) error {
	if cfg.Telegram.OwnerID == 0 {
		return errors.New("в config.json нужен telegram.owner_id, ваш user id (reina init)")
	}
	a, led, mem := build(cfg)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	sup := supervisor.New()
	tr, err := transport(cfg)
	if err != nil {
		return err
	}
	if m, ok := tr.(tools.Messenger); ok {
		a.Tools().SetMessenger(m) // Telegram-инструменты: написать кому-то, реакции, стикеры
	}
	sup.Add(telegram.NewBot(tr, cfg.Telegram.OwnerID, cfg.Telegram.AllowedIDs, a, led), true)
	h := panel.Handler(panel.Deps{Token: cfg.Panel.Token, Led: led, Mem: mem, Agent: a, Sup: sup}, panel.NewLimiter())
	sup.Add(&panel.Module{Addr: cfg.Panel.Addr, H: h}, true)
	sup.Start(ctx)
	log.Printf("Рейна запущена, панель на %s", cfg.Panel.Addr)
	<-ctx.Done()
	sup.Wait()
	return nil
}

// models печатает id моделей сервера (OpenRouter отдаёт публичный список); filter отбирает по подстроке.
func models(cfg config.Config, filter string) error {
	req, _ := http.NewRequest("GET", strings.TrimRight(cfg.LLM.BaseURL, "/")+"/models", nil)
	if cfg.LLM.APIKey != "" {
		req.Header.Set("Authorization", "Bearer "+cfg.LLM.APIKey)
	}
	resp, err := (&http.Client{Timeout: 30 * time.Second}).Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	var out struct {
		Data []struct {
			ID      string `json:"id"`
			Pricing struct {
				Prompt     string `json:"prompt"`
				Completion string `json:"completion"`
			} `json:"pricing"`
		} `json:"data"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 16<<20)).Decode(&out); err != nil {
		return err
	}
	n := 0
	for _, m := range out.Data {
		if filter != "" && !strings.Contains(strings.ToLower(m.ID), strings.ToLower(filter)) {
			continue
		}
		price := ""
		var p, c float64
		fmt.Sscan(m.Pricing.Prompt, &p)
		fmt.Sscan(m.Pricing.Completion, &c)
		if p > 0 || c > 0 {
			price = fmt.Sprintf("  $%.2f / $%.2f за 1 млн токенов (вход/выход)", p*1e6, c*1e6)
		}
		fmt.Println(m.ID + price)
		n++
	}
	if n == 0 {
		fmt.Println("ничего не найдено")
	}
	return nil
}

func doctor(cfg config.Config) {
	ok := func(c bool, s string) {
		m := "✓"
		if !c {
			m = "✗"
		}
		fmt.Println(m, s)
	}
	ok(cfg.LLM.APIKey != "", "ключ модели задан")
	tg := cfg.Telegram
	ok(tg.OwnerID != 0 && ((tg.Mode == "bot" && tg.Token != "") || (tg.Mode != "bot" && tg.APIID != 0 && tg.APIHash != "" && tg.Phone != "")), "Telegram настроен ("+tg.Mode+")")
	ok(cfg.Panel.Token != "", "токен панели задан")
	ok(cfg.Agent.ShellPolicy != "always", "shell спрашивает разрешения ("+cfg.Agent.ShellPolicy+")")
	if tg.Mode != "bot" {
		_, good := config.NormalizePhone(tg.Phone)
		ok(good, "номер в международном формате: "+tg.Phone)
	}
	for _, m := range []struct{ role, name string }{{"быстрая", cfg.LLM.FastModel}, {"сильная", cfg.LLM.StrongModel}, {"для картинок", cfg.LLM.VisionModel}} {
		if m.name == "" {
			fmt.Println("-", m.role, "модель не задана (необязательно)")
			continue
		}
		_, err := llm.New(cfg.LLM.BaseURL, cfg.LLM.APIKey, 30).Chat(context.Background(), llm.Request{Model: m.name, MaxTokens: 5, Messages: []llm.Message{{Role: "user", Content: "ping"}}})
		if err != nil {
			ok(false, fmt.Sprintf("%s модель %s: %v\n   подобрать другую: reina models, потом поправить fast_model/strong_model в %s", m.role, m.name, err, config.Path(cfg.Home)))
		} else {
			ok(true, fmt.Sprintf("%s модель %s отвечает", m.role, m.name))
		}
	}
}
