// Package telegram: общение с хозяином. Логика (кому отвечать, подтверждения, «занята», /usage, /reset) не зависит от способа входа:
// Transport бывает «бот» (Bot API, токен от BotFather) и «аккаунт» (обычный пользовательский аккаунт по номеру телефона, как у прежней версии на TDLib).
package telegram

import (
	"context"
	"encoding/base64"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/tools"
)

// Transport доставляет входящие сообщения и отправляет ответы.
type Incoming struct {
	Chat  int64
	Text  string // текст или подпись к картинке
	Image []byte // jpeg/png, если пришло фото
	Mime  string
	MsgID int // номер сообщения (для «прочитано» и реакций), 0 если неизвестен
}

// Reader умеют не все транспорты: «прочитано» (две галочки) и «печатает…».
type Reader interface {
	MarkRead(chat int64, msgID int)
	Typing(chat int64)
}

type Transport interface {
	// Run работает до отмены ctx и вызывает in для каждого входящего личного сообщения (не своего).
	Run(ctx context.Context, in func(Incoming)) error
	Send(chat int64, text string) error
	Health() error
}

type Bot struct {
	tr      Transport
	allowed map[int64]bool // кому вообще отвечаем; остальным молчим
	OwnerID int64          // кому задаём вопросы про опасные действия
	Agent   *agent.Agent
	Ledger  *budget.Ledger

	mu      sync.Mutex
	pending chan bool // ждём «да/нет» на опасное действие
	busy    map[int64]bool
}

func NewBot(tr Transport, owner int64, allowed []int64, a *agent.Agent, l *budget.Ledger) *Bot {
	b := &Bot{tr: tr, OwnerID: owner, allowed: map[int64]bool{owner: true}, Agent: a, Ledger: l, busy: map[int64]bool{}}
	for _, id := range allowed {
		b.allowed[id] = true
	}
	a.Confirm = func(session, desc string) bool { return b.ask(desc) }
	return b
}

func (b *Bot) Send(chat int64, text string) {
	r := []rune(text)
	for len(r) > 0 { // лимит Telegram 4096
		n := len(r)
		if n > 4000 {
			n = 4000
		}
		if err := b.tr.Send(chat, string(r[:n])); err != nil {
			log.Printf("telegram: не отправилось: %v", err)
			return
		}
		r = r[n:]
	}
}

// ask спрашивает владельца и ждёт ответ до двух минут. Отвечать «да» может только он сам.
func (b *Bot) ask(desc string) bool {
	ch := make(chan bool, 1)
	b.mu.Lock()
	b.pending = ch
	b.mu.Unlock()
	b.Send(b.OwnerID, "Выполнить? "+desc+"\nОтветьте «да» или «нет».")
	defer func() { b.mu.Lock(); b.pending = nil; b.mu.Unlock() }()
	select {
	case v := <-ch:
		return v
	case <-time.After(2 * time.Minute):
		return false
	}
}

// Handle обрабатывает одно входящее сообщение. Отдельно от транспорта, чтобы тестировать.
func (b *Bot) Handle(ctx context.Context, chat int64, text string) {
	b.HandleIncoming(ctx, Incoming{Chat: chat, Text: text})
}

func (b *Bot) HandleIncoming(ctx context.Context, m Incoming) {
	chat, text := m.Chat, m.Text
	if !b.allowed[chat] {
		return // чужим не отвечаем вообще
	}
	if r, ok := b.tr.(Reader); ok && m.MsgID > 0 {
		go r.MarkRead(chat, m.MsgID) // две галочки только тем, кому она отвечает
	}
	t := strings.ToLower(strings.TrimSpace(text))
	if len(m.Image) > 0 {
		t = "" // подпись к фото не считается командой или ответом «да»
	}
	if chat == b.OwnerID && len(m.Image) == 0 {
		b.mu.Lock()
		p := b.pending
		b.mu.Unlock()
		if p != nil {
			select {
			case p <- (t == "да" || t == "yes" || t == "y" || t == "ок"):
			default:
			}
			return
		}
	}
	session := fmt.Sprintf("tg:%d", chat)
	switch {
	case t == "/start":
		b.Send(chat, "Привет! Я Рейна. Пиши как обычно. /usage покажет расходы.")
		return
	case t == "/reset":
		b.Agent.Reset(session)
		b.Send(chat, "Разговор забыла, долгая память осталась.")
		return
	case t == "/usage":
		d := b.Ledger.Today()
		b.Send(chat, fmt.Sprintf("Сегодня: запросов %d, токенов %d вход / %d выход, $%.4f, ответов из памяти без запроса: %d.", d.Requests, d.Prompt, d.Completion, d.USD, d.Saved))
		return
	}
	b.mu.Lock()
	if b.busy[chat] {
		b.mu.Unlock()
		b.Send(chat, "Секунду, ещё отвечаю на прошлое.")
		return
	}
	b.busy[chat] = true
	b.mu.Unlock()
	go func() {
		defer func() {
			if r := recover(); r != nil { // одна ошибка не роняет бота
				log.Printf("паника в обработчике: %v", r)
				b.Send(chat, "Что-то сломалось внутри, но я жива. Попробуй ещё раз.")
			}
			b.mu.Lock()
			b.busy[chat] = false
			b.mu.Unlock()
		}()
		cctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		defer cancel()
		cctx = tools.WithChat(cctx, chat, m.MsgID)
		if r, ok := b.tr.(Reader); ok {
			r.Typing(chat)
		}
		var ans string
		var err error
		if len(m.Image) > 0 {
			if len(m.Image) > 8<<20 {
				b.Send(chat, "Картинка слишком большая (больше 8 МБ).")
				return
			}
			ans, err = b.Agent.ReplyImage(cctx, session, text, "data:"+m.Mime+";base64,"+base64.StdEncoding.EncodeToString(m.Image))
		} else {
			ans, err = b.Agent.Reply(cctx, session, text)
		}
		if err != nil {
			b.Send(chat, "Не получилось: "+err.Error())
			return
		}
		b.Send(chat, ans)
	}()
}

func (b *Bot) Name() string  { return "telegram" }
func (b *Bot) Health() error { return b.tr.Health() }

func (b *Bot) Run(ctx context.Context) error {
	return b.tr.Run(ctx, func(m Incoming) { b.HandleIncoming(ctx, m) })
}
