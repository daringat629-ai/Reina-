// Package agent: разговор Рейны. Здесь же вся экономия токенов:
//  1. окно из последних N сообщений, старое сжимается в короткий пересказ (раз в несколько сообщений, дешёвой моделью);
//  2. маршрутизатор: короткое бытовое идёт на быструю дешёвую модель без описаний инструментов, сложное и «сделай» на сильную;
//  3. ответ на повторный вопрос берётся из кэша (0 токенов), ключ учитывает сессию, версию памяти и пересказ; зависящее от времени и действий не кэшируется;
//  4. вывод инструментов обрезается, ответы ограничены по длине;
//  5. память подмешивается, только если нашлись совпадения (до 3 фактов);
//  6. дневной потолок: деньги резервируются до запроса, параллельные запросы не могут вместе его превысить.
//
// Каждый собеседник и канал живёт в своей Session (история, пересказ, кэш, замок): контексты не смешиваются,
// а ответы и сжатие внутри одной сессии идут строго по очереди.
package agent

import (
	"context"
	"fmt"
	"hash/fnv"
	"strings"
	"sync"
	"time"

	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/tools"
)

type Chatter interface {
	Chat(ctx context.Context, r llm.Request) (llm.Response, error)
}

// Confirm спрашивает владельца про опасное действие в конкретной сессии.
type Confirm func(session, desc string) bool

type Agent struct {
	cfg   config.Config
	llm   Chatter
	led   *budget.Ledger
	mem   memory.Store
	tools *tools.Set

	mu       sync.Mutex
	sessions map[string]*Session
	Confirm  Confirm
	Now      func() time.Time
}

type Session struct {
	ID    string
	mu    sync.Mutex // один ответ за раз в сессии
	hist  []llm.Message
	sum   string
	cache map[string]cached
}

type cached struct {
	text string
	at   time.Time
}

const maxSessions = 200

func New(cfg config.Config, c Chatter, led *budget.Ledger, mem memory.Store, ts *tools.Set) *Agent {
	return &Agent{cfg: cfg, llm: c, led: led, mem: mem, tools: ts, sessions: map[string]*Session{}, Now: time.Now}
}

func (a *Agent) session(id string) *Session {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.sessions[id]
	if s == nil {
		if len(a.sessions) >= maxSessions { // не копим бесконечно: самую давнюю по порядку выбрасываем
			for k := range a.sessions {
				delete(a.sessions, k)
				break
			}
		}
		s = &Session{ID: id, cache: map[string]cached{}}
		a.sessions[id] = s
	}
	return s
}

var toolWords = []string{"сделай", "запусти", "выполни", "команд", "файл", "папк", "установ", "найди", "покажи", "проверь", "перезапуст", "удали", "создай", "прочитай", "диск", "процесс", "экран", "обои", "мышь", "откро", "нажми", "напечат", "сайт", "браузер", "discord", "дискорд", "зайди", "зарегистр", "стикер", "реакц", "лайк", "отправь", "кинь", "напиши ", "запомни", "вспомни", "забудь", "shell", "bash"}

// words, при которых ответ зависит от текущего момента: из кэша их не отдаём.
var volatile = []string{"время", "час", "сегодня", "сейчас", "завтра", "вчера", "дата", "погод", "курс", "новост"}

func has(l string, list []string) bool {
	for _, w := range list {
		if strings.Contains(l, w) {
			return true
		}
	}
	return false
}

// Route: strong, если сообщение длинное или просит действие; иначе fast.
func Route(text string) (strong bool, needTools bool) {
	l := strings.ToLower(text)
	if has(l, toolWords) {
		return true, true
	}
	return len([]rune(text)) > 240, false
}

func norm(t string) string { return strings.Join(strings.Fields(strings.ToLower(t)), " ") }

func (a *Agent) cacheKey(s *Session, text string) string {
	h := fnv.New64a()
	h.Write([]byte(s.sum))
	return fmt.Sprintf("%s|%d|%x", norm(text), a.mem.Version(), h.Sum64())
}

func (a *Agent) price(strong bool) (in, out float64) {
	b := a.cfg.Budget
	if strong {
		return b.StrongInPerM, b.StrongOutPerM
	}
	return b.FastInPerM, b.FastOutPerM
}

func (a *Agent) cost(strong bool, u llm.Usage) float64 {
	in, out := a.price(strong)
	return float64(u.Prompt)/1e6*in + float64(u.Completion)/1e6*out
}

// estimate: верхняя оценка цены запроса для резерва.
func (a *Agent) estimate(strong bool, msgs []llm.Message, tl []llm.Tool, maxTok int) float64 {
	chars := 0
	for _, m := range msgs {
		chars += len([]rune(m.Content)) + 20
	}
	chars += len(tl) * 300
	in, out := a.price(strong)
	return float64(chars/3+50)/1e6*in + float64(maxTok)/1e6*out
}

// Reply отвечает на сообщение в сессии sessionID. Сессии независимы; внутри сессии ответы идут по очереди.
func (a *Agent) Reply(ctx context.Context, sessionID, text string) (string, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "", nil
	}
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()

	strong, needTools := Route(text)
	cacheable := !needTools && !has(strings.ToLower(text), volatile) && a.cfg.Agent.CacheTTLSec > 0
	key := a.cacheKey(s, text)
	if c, ok := s.cache[key]; ok && cacheable && a.Now().Sub(c.at) < time.Duration(a.cfg.Agent.CacheTTLSec)*time.Second {
		a.led.CacheHit()
		return c.text, nil
	}

	s.hist = append(s.hist, llm.Message{Role: "user", Content: text})
	msgs := []llm.Message{{Role: "system", Content: a.cfg.Agent.Persona}}
	if cb := a.contextBlock(s, text); cb != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: cb})
	}
	msgs = append(msgs, a.window(s)...)

	model, maxTok := a.cfg.LLM.FastModel, a.cfg.Agent.FastMaxTokens
	if strong {
		model, maxTok = a.cfg.LLM.StrongModel, a.cfg.Agent.StrongMaxTok
	}
	var defs []llm.Tool
	if needTools {
		defs = a.tools.Defs()
	}
	turn := &tools.Turn{}
	answer := ""
	steps := a.cfg.Agent.MaxSteps
	if steps <= 0 {
		steps = 6
	}
	for step := 0; step < steps; step++ {
		res, ok := a.led.Reserve(a.estimate(strong, msgs, defs, maxTok))
		if !ok {
			answer = fmt.Sprintf("Дневной потолок расходов $%.2f исчерпан, до завтра молчу. Поднять: budget.daily_usd в config.json.", a.cfg.Budget.DailyUSD)
			break
		}
		resp, err := a.llm.Chat(ctx, llm.Request{Model: model, Messages: msgs, Tools: defs, MaxTokens: maxTok})
		if err != nil {
			a.led.Settle(res, 0, 0, 0)
			s.hist = s.hist[:len(s.hist)-1] // неудавшийся вопрос из истории убираем
			return "", err
		}
		a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(strong, resp.Usage))
		if len(resp.Message.ToolCalls) == 0 {
			answer = strings.TrimSpace(resp.Message.Content)
			break
		}
		msgs = append(msgs, resp.Message)
		for _, tc := range resp.Message.ToolCalls {
			cf := func(desc string) bool { return a.Confirm != nil && a.Confirm(s.ID, desc) }
			out := a.tools.Exec(ctx, turn, tc.Function.Name, tc.Function.Arguments, cf)
			msgs = append(msgs, llm.Message{Role: "tool", ToolCallID: tc.ID, Content: tools.Truncate(out, a.cfg.Agent.ToolOutputMax)})
		}
	}
	if answer == "" {
		answer = "(не вышло ответить, попробуй ещё раз)"
	}
	s.hist = append(s.hist, llm.Message{Role: "assistant", Content: answer})
	if cacheable {
		if len(s.cache) > 100 {
			s.cache = map[string]cached{}
		}
		s.cache[a.cacheKey(s, text)] = cached{answer, a.Now()}
	}
	a.compress(ctx, s)
	return answer, nil
}

func (a *Agent) windowSize() int {
	if n := a.cfg.Agent.WindowMsgs; n > 0 {
		return n
	}
	return 10
}

func (a *Agent) window(s *Session) []llm.Message {
	n := a.windowSize()
	if len(s.hist) <= n {
		return append([]llm.Message(nil), s.hist...)
	}
	return append([]llm.Message(nil), s.hist[len(s.hist)-n:]...)
}

func (a *Agent) contextBlock(s *Session, text string) string {
	var parts []string
	if s.sum != "" {
		parts = append(parts, "Кратко о прошлом разговоре: "+s.sum)
	}
	if f := a.mem.Search(text, 3); len(f) > 0 {
		var t []string
		for _, x := range f {
			t = append(t, x.Text)
		}
		parts = append(parts, "Из памяти: "+strings.Join(t, "; "))
	}
	return strings.Join(parts, "\n")
}

// compress вызывается под замком сессии, поэтому два сжатия одной истории одновременно невозможны.
func (a *Agent) compress(ctx context.Context, s *Session) {
	n := a.windowSize()
	if len(s.hist) < 2*n {
		return
	}
	old := append([]llm.Message(nil), s.hist[:len(s.hist)-n]...)
	var sb strings.Builder
	if s.sum != "" {
		sb.WriteString("Прежний пересказ: " + s.sum + "\n")
	}
	for _, m := range old {
		sb.WriteString(m.Role + ": " + tools.Truncate(m.Content, 300) + "\n")
	}
	max := a.cfg.Agent.SummaryChars
	if max <= 0 {
		max = 700
	}
	sys := fmt.Sprintf("Сожми разговор в короткий пересказ (до %d символов): кто что просил, что решили, важные факты. Только пересказ.", max)
	req := llm.Request{Model: a.cfg.LLM.FastModel, MaxTokens: max / 2, Messages: []llm.Message{{Role: "system", Content: sys}, {Role: "user", Content: sb.String()}}}
	res, ok := a.led.Reserve(a.estimate(false, req.Messages, nil, req.MaxTokens))
	if !ok {
		return
	}
	resp, err := a.llm.Chat(ctx, req)
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return // не вышло: старое остаётся в истории, попробуем в следующий раз
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, a.cost(false, resp.Usage))
	t := strings.TrimSpace(resp.Message.Content)
	if r := []rune(t); len(r) > max {
		t = string(r[:max])
	}
	s.sum = t
	s.hist = append([]llm.Message(nil), s.hist[len(old):]...)
}

// Tools даёт доступ к набору инструментов (транспорт добавляет свои, например Telegram).
func (a *Agent) Tools() *tools.Set { return a.tools }

// Describe: глаза для инструмента screen. Деньги резервируются и учитываются как у обычного запроса с картинкой.
func (a *Agent) Describe(ctx context.Context, dataURL, question string) (string, error) {
	if a.cfg.LLM.VisionModel == "" {
		return "", fmt.Errorf("не задана vision_model")
	}
	b := a.cfg.Budget
	maxTok := 500
	msgs := []llm.Message{{Role: "system", Content: "Ты глаза ассистента. Описывай экран кратко и точно, координаты только из этого снимка."}, {Role: "user", Content: question, Images: []string{dataURL}}}
	res, ok := a.led.Reserve(2000/1e6*b.VisionInPerM + float64(maxTok)/1e6*b.VisionOutPerM)
	if !ok {
		return "", fmt.Errorf("дневной потолок расходов исчерпан")
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.VisionModel, Messages: msgs, MaxTokens: maxTok})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return "", err
	}
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, float64(resp.Usage.Prompt)/1e6*b.VisionInPerM+float64(resp.Usage.Completion)/1e6*b.VisionOutPerM)
	return strings.TrimSpace(resp.Message.Content), nil
}

// Reset забывает разговор сессии (память фактов остаётся).
func (a *Agent) Reset(sessionID string) {
	s := a.session(sessionID)
	s.mu.Lock()
	s.hist, s.sum, s.cache = nil, "", map[string]cached{}
	s.mu.Unlock()
}

func (a *Agent) Summary(sessionID string) string {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.sum
}

func (a *Agent) HistLen(sessionID string) int {
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.hist)
}

func (a *Agent) SessionCount() int { a.mu.Lock(); defer a.mu.Unlock(); return len(a.sessions) }

// ReplyImage отвечает на сообщение с картинкой моделью для картинок. Без инструментов и без кэша; картинка в историю не попадает
// (в ней остаётся только пометка и подпись), чтобы не платить за неё в каждом следующем запросе.
func (a *Agent) ReplyImage(ctx context.Context, sessionID, caption, dataURL string) (string, error) {
	if a.cfg.LLM.VisionModel == "" {
		return "Картинки я пока не разбираю: не задана vision_model в config.json (список моделей: reina models qwen).", nil
	}
	if caption = strings.TrimSpace(caption); caption == "" {
		caption = "Опиши, что на картинке, и ответь по делу."
	}
	s := a.session(sessionID)
	s.mu.Lock()
	defer s.mu.Unlock()
	msgs := []llm.Message{{Role: "system", Content: a.cfg.Agent.Persona}}
	if cb := a.contextBlock(s, caption); cb != "" {
		msgs = append(msgs, llm.Message{Role: "system", Content: cb})
	}
	msgs = append(msgs, a.window(s)...)
	msgs = append(msgs, llm.Message{Role: "user", Content: caption, Images: []string{dataURL}})
	maxTok := a.cfg.Agent.StrongMaxTok
	res, ok := a.led.Reserve(a.estimate(true, msgs, nil, maxTok) + 1500/1e6*a.cfg.Budget.VisionInPerM + float64(maxTok)/1e6*a.cfg.Budget.VisionOutPerM) // картинка стоит ещё около тысячи токенов
	if !ok {
		return fmt.Sprintf("Дневной потолок расходов $%.2f исчерпан.", a.cfg.Budget.DailyUSD), nil
	}
	resp, err := a.llm.Chat(ctx, llm.Request{Model: a.cfg.LLM.VisionModel, Messages: msgs, MaxTokens: maxTok})
	if err != nil {
		a.led.Settle(res, 0, 0, 0)
		return "", err
	}
	b := a.cfg.Budget
	vision := float64(resp.Usage.Prompt)/1e6*b.VisionInPerM + float64(resp.Usage.Completion)/1e6*b.VisionOutPerM
	a.led.Settle(res, resp.Usage.Prompt, resp.Usage.Completion, vision)
	answer := strings.TrimSpace(resp.Message.Content)
	if answer == "" {
		answer = "(не вышло разобрать картинку)"
	}
	s.hist = append(s.hist, llm.Message{Role: "user", Content: "[фото] " + caption}, llm.Message{Role: "assistant", Content: answer})
	a.compress(ctx, s)
	return answer, nil
}
