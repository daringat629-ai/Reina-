package agent

import (
	"context"
	"strings"
	"sync"
	"testing"
	"time"

	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/tools"
)

type fake struct {
	mu    sync.Mutex
	reqs  []llm.Request
	reply func(r llm.Request) llm.Message
}

func (f *fake) Chat(_ context.Context, r llm.Request) (llm.Response, error) {
	f.mu.Lock()
	f.reqs = append(f.reqs, r)
	f.mu.Unlock()
	return llm.Response{Message: f.reply(r), Usage: llm.Usage{Prompt: 1000, Completion: 100}}, nil
}

func setup(t *testing.T, f *fake) (*Agent, *budget.Ledger, memory.Store) {
	cfg := config.Default()
	cfg.Home = t.TempDir()
	cfg.LLM.FastModel, cfg.LLM.StrongModel = "fast", "strong"
	led := budget.Open(cfg.Home, 0)
	mem := memory.Open(cfg.Home)
	return New(cfg, f, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home))), led, mem
}

func say(text string) func(llm.Request) llm.Message {
	return func(llm.Request) llm.Message { return llm.Message{Role: "assistant", Content: text} }
}

func TestRouteSendsCheapChatToTheFastModelWithoutToolDescriptions(t *testing.T) {
	f := &fake{reply: say("привет")}
	a, _, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "привет, как дела?")
	r := f.reqs[0]
	if r.Model != "fast" || len(r.Tools) != 0 {
		t.Fatalf("ожидалась быстрая модель без инструментов: %s, %d", r.Model, len(r.Tools))
	}
	a.Reply(context.Background(), "s1", "запусти проверку диска")
	r = f.reqs[1]
	if r.Model != "strong" || len(r.Tools) == 0 {
		t.Fatalf("действие идёт на сильную модель с инструментами: %s", r.Model)
	}
}

func TestRepeatedQuestionIsAnsweredFromMemoryForZeroTokens(t *testing.T) {
	f := &fake{reply: say("Я Марин.")}
	a, led, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "Ты кто?")
	got, _ := a.Reply(context.Background(), "s1", "  ты   КТО? ")
	if got != "Я Марин." || len(f.reqs) != 1 {
		t.Fatalf("второй раз запроса быть не должно: %d", len(f.reqs))
	}
	if led.Today().Saved != 1 {
		t.Fatal("экономия не записана")
	}
}

func TestActionsAreNeverServedFromTheCache(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, _ := setup(t, f)
	a.Reply(context.Background(), "s1", "покажи время")
	a.Reply(context.Background(), "s1", "покажи время")
	if len(f.reqs) != 2 {
		t.Fatal("действие должно выполняться каждый раз")
	}
}

func TestOldMessagesAreSquashedIntoASummaryAndTheWindowStaysSmall(t *testing.T) {
	f := &fake{reply: func(r llm.Request) llm.Message {
		if strings.Contains(r.Messages[0].Content, "Сожми разговор") {
			return llm.Message{Role: "assistant", Content: "пересказ: обсуждали ткань"}
		}
		return llm.Message{Role: "assistant", Content: "ага"}
	}}
	a, _, _ := setup(t, f)
	for i := 0; i < 14; i++ {
		a.Reply(context.Background(), "s1", "сообщение номер "+strings.Repeat("x", i))
	}
	if a.Summary("s1") == "" {
		t.Fatal("пересказ не появился")
	}
	if a.HistLen("s1") > 2*a.cfg.Agent.WindowMsgs {
		t.Fatalf("история растёт без предела: %d", a.HistLen("s1"))
	}
	last := f.reqs[len(f.reqs)-1]
	n := 0
	for _, m := range last.Messages {
		if m.Role == "user" || m.Role == "assistant" {
			n++
		}
	}
	if n > a.cfg.Agent.WindowMsgs {
		t.Fatalf("в запрос ушло %d сообщений при окне %d", n, a.cfg.Agent.WindowMsgs)
	}
}

func TestMemoryIsInjectedOnlyWhenItMatches(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, mem := setup(t, f)
	mem.Add("Хозяин любит чай с жасмином", "user", 0)
	a.Reply(context.Background(), "s1", "привет")
	for _, m := range f.reqs[0].Messages {
		if strings.Contains(m.Content, "жасмин") {
			t.Fatal("память не относится к вопросу, а ушла в запрос")
		}
	}
	a.Reply(context.Background(), "s1", "какой чай я люблю?")
	found := false
	for _, m := range f.reqs[1].Messages {
		found = found || strings.Contains(m.Content, "жасмин")
	}
	if !found {
		t.Fatal("подходящий факт не подмешан")
	}
}

func TestDailyBudgetStopsTheModel(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, led, _ := setup(t, f)
	led.Cap = 0.0001
	r, _ := led.Reserve(0)
	led.Settle(r, 1000, 100, 0.01)
	got, err := a.Reply(context.Background(), "s1", "привет")
	if err != nil || !strings.Contains(got, "потолок") || len(f.reqs) != 0 {
		t.Fatalf("при исчерпанном бюджете запроса быть не должно: %q %v %d", got, err, len(f.reqs))
	}
}

func toolCall(name, args string) llm.Message {
	var tc llm.ToolCall
	tc.ID, tc.Type = "c1", "function"
	tc.Function.Name, tc.Function.Arguments = name, args
	return llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{tc}}
}

func TestShellAsksTheOwnerAndRespectsTheAnswer(t *testing.T) {
	step := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		step++
		if step == 1 {
			return toolCall("shell", `{"command":"echo привет-из-шелла"}`)
		}
		return llm.Message{Role: "assistant", Content: r.Messages[len(r.Messages)-1].Content}
	}}
	a, _, _ := setup(t, f)
	asked := 0
	a.Confirm = func(string, string) bool { asked++; return false }
	got, _ := a.Reply(context.Background(), "s1", "выполни команду")
	if asked != 1 || !strings.Contains(got, "не разрешил") {
		t.Fatalf("отказ владельца должен дойти до модели: %q", got)
	}
	step = 0
	a.Confirm = func(string, string) bool { return true }
	got, _ = a.Reply(context.Background(), "s1", "выполни команду ещё раз")
	if !strings.Contains(got, "привет-из-шелла") {
		t.Fatalf("разрешённая команда не выполнилась: %q", got)
	}
	step = 0
	a.tools.Policy.Shell = "never"
	got, _ = a.Reply(context.Background(), "s1", "выполни команду третий раз")
	if !strings.Contains(got, "запрещены") {
		t.Fatalf("политика never игнорируется: %q", got)
	}
}

func TestToolOutputIsTruncated(t *testing.T) {
	out := tools.Truncate(strings.Repeat("я", 5000), 1000)
	if len([]rune(out)) > 1100 || !strings.Contains(out, "скрыто") {
		t.Fatalf("вывод не обрезан: %d", len([]rune(out)))
	}
	if tools.Truncate("коротко", 1000) != "коротко" {
		t.Fatal("короткое не должно меняться")
	}
}

// Сравнение с «наивным» ботом, который шлёт всю историю и описания инструментов каждый раз.
func TestTokenSavingsAgainstANaiveBot(t *testing.T) {
	size := func(r llm.Request) int {
		n := 0
		for _, m := range r.Messages {
			n += len([]rune(m.Content))
		}
		for _, d := range r.Tools {
			n += len(d.Function.Name) + len(d.Function.Description) + 150
		}
		return n
	}
	f := &fake{reply: func(r llm.Request) llm.Message {
		if strings.Contains(r.Messages[0].Content, "Сожми разговор") {
			return llm.Message{Role: "assistant", Content: "краткий пересказ разговора"}
		}
		return llm.Message{Role: "assistant", Content: strings.Repeat("Ответ Марин про всякое. ", 12)}
	}}
	a, _, _ := setup(t, f)
	naive, naiveHist := 0, 0
	defs := a.tools.Defs()
	for i := 0; i < 40; i++ {
		q := "расскажи что-нибудь интересное номер " + strings.Repeat("я", i%7)
		if i%8 == 7 {
			q = "проверь диск, пожалуйста"
		}
		a.Reply(context.Background(), "s1", q)
		naiveHist += len([]rune(q)) + 300
		naive += len(a.cfg.Agent.Persona) + naiveHist + 5*(len(defs)*200)
	}
	mine := 0
	for _, r := range f.reqs {
		mine += size(r)
	}
	t.Logf("символов в запросах за 40 реплик: наивный бот ≈ %d, Marin = %d (в %.1f раза меньше)", naive, mine, float64(naive)/float64(mine))
	if mine*3 > naive {
		t.Fatalf("экономия меньше чем втрое: %d против %d", mine, naive)
	}
}

func TestSessionsDoNotShareHistorySummaryOrCache(t *testing.T) {
	f := &fake{reply: say("ок")}
	a, _, _ := setup(t, f)
	ctx := context.Background()
	a.Reply(ctx, "anna", "я люблю ромашки")
	a.Reply(ctx, "boris", "привет")
	for _, m := range f.reqs[1].Messages {
		if strings.Contains(m.Content, "ромашки") {
			t.Fatal("история Анны попала в запрос Бориса")
		}
	}
	a.Reply(ctx, "boris", "я люблю ромашки")
	if len(f.reqs) != 3 {
		t.Fatal("ответ из кэша Анны выдан Борису")
	}
	a.Reset("anna")
	if a.HistLen("anna") != 0 || a.HistLen("boris") != 4 {
		t.Fatalf("сброс одной сессии затронул другую: %d %d", a.HistLen("anna"), a.HistLen("boris"))
	}
}

func TestCacheIsDroppedWhenMemoryChangesAndNeverUsedForTimeDependentQuestions(t *testing.T) {
	f := &fake{reply: say("ответ")}
	a, _, mem := setup(t, f)
	ctx := context.Background()
	a.Reply(ctx, "s", "что я люблю?")
	a.Reply(ctx, "s", "что я люблю?")
	if len(f.reqs) != 1 {
		t.Fatal("повтор должен браться из кэша")
	}
	mem.Add("хозяин любит ромашковый чай", "user", 0)
	a.Reply(ctx, "s", "что я люблю?")
	if len(f.reqs) != 2 {
		t.Fatal("память изменилась, а ответ взят из старого кэша")
	}
	a.Reply(ctx, "s", "какая сегодня погода?")
	a.Reply(ctx, "s", "какая сегодня погода?")
	if len(f.reqs) != 4 {
		t.Fatal("ответ про текущий момент не должен кэшироваться")
	}
}

func TestRepliesInOneSessionRunOneByOneAndDifferentSessionsInParallel(t *testing.T) {
	var inflight, peak int32
	var mu sync.Mutex
	f := &fake{reply: func(r llm.Request) llm.Message {
		mu.Lock()
		inflight++
		if inflight > peak {
			peak = inflight
		}
		mu.Unlock()
		time.Sleep(20 * time.Millisecond)
		mu.Lock()
		inflight--
		mu.Unlock()
		return llm.Message{Role: "assistant", Content: "ок"}
	}}
	a, _, _ := setup(t, f)
	var wg sync.WaitGroup
	for i := 0; i < 6; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "same", "сообщение "+strings.Repeat("я", i))
		}(i)
	}
	wg.Wait()
	if peak != 1 {
		t.Fatalf("в одной сессии параллельно шло %d запросов", peak)
	}
	peak = 0
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "u"+strings.Repeat("x", i), "привет")
		}(i)
	}
	wg.Wait()
	if peak < 2 {
		t.Fatal("разные сессии не работают параллельно")
	}
}

func TestParallelSessionsCannotJointlyBlowTheDailyCap(t *testing.T) {
	f := &fake{reply: func(llm.Request) llm.Message {
		time.Sleep(30 * time.Millisecond)
		return llm.Message{Role: "assistant", Content: "ок"}
	}}
	a, led, _ := setup(t, f)
	a.cfg.Budget.FastInPerM, a.cfg.Budget.FastOutPerM = 1000, 1000 // дорого: запрос ~ $0.4
	led.Cap = 1.0
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			a.Reply(context.Background(), "p"+strings.Repeat("x", i), "привет")
		}(i)
	}
	wg.Wait()
	if n := len(f.reqs); n > 2 {
		t.Fatalf("при потолке на два запроса прошло %d", n)
	}
}

func TestAFailedRequestLeavesNoTraceInHistoryAndReturnsTheReservation(t *testing.T) {
	bad := &failing{}
	cfg := config.Default()
	cfg.Home = t.TempDir()
	led := budget.Open(cfg.Home, 1)
	mem := memory.Open(cfg.Home)
	a := New(cfg, bad, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	if _, err := a.Reply(context.Background(), "s", "привет"); err == nil {
		t.Fatal("ошибка модели должна дойти до вызывающего")
	}
	if a.HistLen("s") != 0 {
		t.Fatal("неудавшийся вопрос остался в истории")
	}
	if r, ok := led.Reserve(0.99); !ok {
		t.Fatal("резерв не вернулся")
	} else {
		led.Settle(r, 0, 0, 0)
	}
}

type failing struct{}

func (failing) Chat(context.Context, llm.Request) (llm.Response, error) {
	return llm.Response{}, context.DeadlineExceeded
}

func TestImageGoesToTheVisionModelWithoutToolsAndIsNotKeptInHistory(t *testing.T) {
	f := &fake{reply: say("На фото кот.")}
	a, _, _ := setup(t, f)
	a.cfg.LLM.VisionModel = "vision"
	got, err := a.ReplyImage(context.Background(), "s", "что это?", "data:image/jpeg;base64,AAAA")
	if err != nil || got != "На фото кот." {
		t.Fatalf("%q %v", got, err)
	}
	r := f.reqs[0]
	last := r.Messages[len(r.Messages)-1]
	if r.Model != "vision" || len(r.Tools) != 0 || len(last.Images) != 1 {
		t.Fatalf("запрос не тот: %s %d %d", r.Model, len(r.Tools), len(last.Images))
	}
	a.Reply(context.Background(), "s", "ясно, спасибо")
	for _, m := range f.reqs[1].Messages {
		if len(m.Images) != 0 {
			t.Fatal("картинка осталась в истории и будет оплачиваться снова")
		}
	}
	if !strings.Contains(f.reqs[1].Messages[len(f.reqs[1].Messages)-3].Content, "[фото]") {
		t.Log("пометка о фото в истории:", f.reqs[1].Messages)
	}
}

func TestImageWithoutAVisionModelExplainsWhatToConfigure(t *testing.T) {
	f := &fake{reply: say("не должно вызываться")}
	a, _, _ := setup(t, f)
	a.cfg.LLM.VisionModel = ""
	got, _ := a.ReplyImage(context.Background(), "s", "", "data:image/jpeg;base64,AAAA")
	if !strings.Contains(got, "vision_model") || len(f.reqs) != 0 {
		t.Fatalf("%q %d", got, len(f.reqs))
	}
}

func TestLongTaskUsesMaxStepsAndDangerLimitFromConfig(t *testing.T) {
	n := 0
	f := &fake{reply: func(r llm.Request) llm.Message {
		n++
		if n <= 9 {
			return toolCall("shell", `{"command":"echo шаг"}`)
		}
		return llm.Message{Role: "assistant", Content: "готово за девять шагов"}
	}}
	a, _, _ := setup(t, f)
	a.Confirm = func(string, string) bool { return true }
	got, _ := a.Reply(context.Background(), "s", "выполни длинную задачу")
	if strings.Contains(got, "готово") {
		t.Fatalf("по умолчанию 6 шагов, девять шагов пройти не должно: %q", got)
	}
	n = 0
	a.cfg.Agent.MaxSteps = 12
	a.tools.Policy.MaxDangerous = 12
	got, _ = a.Reply(context.Background(), "s2", "выполни длинную задачу")
	if !strings.Contains(got, "готово за девять шагов") {
		t.Fatalf("при max_steps=12 задача должна дойти до конца: %q", got)
	}
}
