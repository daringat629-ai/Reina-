package tools

// Управление ПК: глаза (скриншот и описание моделью для картинок), руки (мышь, клавиатура), обои, запуск программ,
// запись файлов и чтение веб-страниц. Все действия «руками» опасные: идут через ту же политику, что и shell
// (спросить владельца, лимит за ход, отказ при shell_policy=never).
// Нужны программы хозяина: xdotool, и одна из scrot/import/grim для снимка, ImageMagick (convert) для сжатия.
// Без дисплея (контейнер, ssh) инструменты честно отвечают, чего не хватает, и ничего не делают.

import (
	"context"
	"encoding/base64"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

// Vision описывает картинку (data URL) по вопросу. Задаётся ядром, у инструментов своей модели нет.
type Vision func(ctx context.Context, dataURL, question string) (string, error)

type desk struct {
	mu         sync.Mutex
	scale      float64 // во сколько раз снимок для модели меньше реального экрана
	w, h       int     // размер снимка, который видит модель
	lastShot   string
	Vision     Vision
	ShotWidth  int
	httpClient *http.Client
	allowWrite []string
}

func run(ctx context.Context, name string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	out, err := exec.CommandContext(ctx, name, args...).CombinedOutput()
	return strings.TrimSpace(string(out)), err
}

func have(n string) bool { _, err := exec.LookPath(n); return err == nil }

func (d *desk) needDisplay() error {
	if os.Getenv("DISPLAY") == "" && os.Getenv("WAYLAND_DISPLAY") == "" {
		return fmt.Errorf("нет графического экрана (DISPLAY/WAYLAND_DISPLAY не заданы): запускай Рейну из сеанса рабочего стола, например DISPLAY=:0 ./reina run")
	}
	return nil
}

func (d *desk) needXdotool() error {
	if err := d.needDisplay(); err != nil {
		return err
	}
	if !have("xdotool") {
		return fmt.Errorf("не установлен xdotool (apt install xdotool); под Wayland нужен ydotool")
	}
	return nil
}

// shot делает снимок экрана, сжимает до ShotWidth и запоминает масштаб для координат.
func (d *desk) shot(ctx context.Context) (string, error) {
	if err := d.needDisplay(); err != nil {
		return "", err
	}
	raw := filepath.Join(os.TempDir(), fmt.Sprintf("reina-shot-%d.png", time.Now().UnixNano()))
	defer os.Remove(raw)
	var err error
	switch {
	case have("scrot"):
		_, err = run(ctx, "scrot", "-o", raw)
	case have("grim"):
		_, err = run(ctx, "grim", raw)
	case have("import"):
		_, err = run(ctx, "import", "-window", "root", raw)
	default:
		return "", fmt.Errorf("нет программы для снимка экрана (apt install scrot)")
	}
	if err != nil {
		return "", fmt.Errorf("снимок не получился: %v", err)
	}
	out := filepath.Join(os.TempDir(), "reina-last-shot.png")
	width := d.ShotWidth
	if width <= 0 {
		width = 1280
	}
	if have("convert") {
		if _, err := run(ctx, "convert", raw, "-resize", fmt.Sprintf("%dx>", width), out); err != nil {
			return "", fmt.Errorf("не вышло сжать снимок: %v", err)
		}
	} else if b, e := os.ReadFile(raw); e == nil {
		os.WriteFile(out, b, 0o600)
	}
	sw, sh := d.realSize(ctx)
	iw, ih := pngSize(out)
	d.mu.Lock()
	d.lastShot, d.w, d.h = out, iw, ih
	d.scale = 1
	if iw > 0 && sw > 0 {
		d.scale = float64(sw) / float64(iw)
	}
	_ = sh
	d.mu.Unlock()
	return out, nil
}

func (d *desk) realSize(ctx context.Context) (int, int) {
	if have("xdotool") {
		if s, err := run(ctx, "xdotool", "getdisplaygeometry"); err == nil {
			var w, h int
			if _, e := fmt.Sscan(s, &w, &h); e == nil {
				return w, h
			}
		}
	}
	return 0, 0
}

func pngSize(path string) (int, int) {
	f, err := os.Open(path)
	if err != nil {
		return 0, 0
	}
	defer f.Close()
	b := make([]byte, 24)
	if _, err := io.ReadFull(f, b); err != nil || string(b[1:4]) != "PNG" {
		return 0, 0
	}
	w := int(b[16])<<24 | int(b[17])<<16 | int(b[18])<<8 | int(b[19])
	h := int(b[20])<<24 | int(b[21])<<16 | int(b[22])<<8 | int(b[23])
	return w, h
}

func (d *desk) toReal(x, y int64) (int, int) {
	d.mu.Lock()
	defer d.mu.Unlock()
	s := d.scale
	if s <= 0 {
		s = 1
	}
	return int(float64(x) * s), int(float64(y) * s)
}

func (d *desk) look(ctx context.Context, question string) (string, error) {
	if err := d.needDisplay(); err != nil {
		return "", err
	}
	if d.Vision == nil {
		return "", fmt.Errorf("модель для картинок не задана (llm.vision_model в config.json)")
	}
	p, err := d.shot(ctx)
	if err != nil {
		return "", err
	}
	b, err := os.ReadFile(p)
	if err != nil {
		return "", err
	}
	if strings.TrimSpace(question) == "" {
		question = "Опиши, что на экране: окна, кнопки, поля ввода. Для каждого важного элемента назови примерные координаты центра (x,y) в пикселях этого снимка."
	} else {
		question += "\nЕсли нужно куда-то нажать, назови координаты центра (x,y) в пикселях этого снимка."
	}
	d.mu.Lock()
	w, h := d.w, d.h
	d.mu.Unlock()
	ans, err := d.Vision(ctx, "data:image/png;base64,"+base64.StdEncoding.EncodeToString(b), fmt.Sprintf("Снимок экрана %dx%d. %s", w, h, question))
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("[снимок %dx%d; координаты для mouse давай в этих пикселях]\n%s", w, h, ans), nil
}

var wallRE = regexp.MustCompile(`^[\w./ ~@+-]+$`)

func (d *desk) wallpaper(ctx context.Context, path string) (string, error) {
	if !wallRE.MatchString(path) {
		return "", fmt.Errorf("странный путь к картинке")
	}
	if strings.HasPrefix(path, "~/") {
		h, _ := os.UserHomeDir()
		path = filepath.Join(h, path[2:])
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	if _, err := os.Stat(abs); err != nil {
		return "", fmt.Errorf("файла нет: %s", abs)
	}
	uri := "file://" + abs
	var tried []string
	try := func(name string, args ...string) bool {
		if !have(name) {
			return false
		}
		if out, err := run(ctx, name, args...); err != nil {
			tried = append(tried, name+": "+out)
			return false
		}
		return true
	}
	desk := strings.ToLower(os.Getenv("XDG_CURRENT_DESKTOP"))
	switch {
	case strings.Contains(desk, "xfce") && have("xfconf-query"):
		if out, _ := run(ctx, "xfconf-query", "-c", "xfce4-desktop", "-l"); out != "" {
			ok := false
			for _, l := range strings.Split(out, "\n") {
				if strings.HasSuffix(l, "/last-image") {
					if try("xfconf-query", "-c", "xfce4-desktop", "-p", l, "-s", abs) {
						ok = true
					}
				}
			}
			if ok {
				return "обои сменены (xfce)", nil
			}
		}
	case strings.Contains(desk, "gnome") || strings.Contains(desk, "unity") || strings.Contains(desk, "cinnamon"):
		if try("gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri) {
			try("gsettings", "set", "org.gnome.desktop.background", "picture-uri-dark", uri)
			return "обои сменены (gnome)", nil
		}
	case strings.Contains(desk, "kde"):
		if try("plasma-apply-wallpaperimage", abs) {
			return "обои сменены (kde)", nil
		}
	}
	if try("feh", "--bg-fill", abs) {
		return "обои сменены (feh)", nil
	}
	if try("swaymsg", "output", "*", "bg", abs, "fill") {
		return "обои сменены (sway)", nil
	}
	if try("gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri) {
		return "обои сменены (gsettings)", nil
	}
	if len(tried) > 0 {
		return "", fmt.Errorf("не вышло: %s", strings.Join(tried, "; "))
	}
	return "", fmt.Errorf("не нашла способа сменить обои: нужны feh, gsettings, xfconf-query или swaymsg")
}

var htmlTag = regexp.MustCompile(`(?s)<(script|style)[^>]*>.*?</(script|style)>|<[^>]+>`)

func (d *desk) fetch(ctx context.Context, raw string) (string, error) {
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return "", fmt.Errorf("нужен адрес http(s)://...")
	}
	ctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "GET", u.String(), nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Reina)")
	c := d.httpClient
	if c == nil {
		c = http.DefaultClient
	}
	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 400_000))
	t := string(b)
	if strings.Contains(resp.Header.Get("Content-Type"), "html") {
		t = htmlTag.ReplaceAllString(t, " ")
		t = strings.Join(strings.Fields(t), " ")
	}
	return fmt.Sprintf("HTTP %d\n%s", resp.StatusCode, t), nil
}

func (d *desk) tools(s *Set) []Tool {
	intp := map[string]any{"type": "integer"}
	return []Tool{
		{Name: "screen", Desc: "Посмотреть на экран: снимок и описание (окна, кнопки, координаты). question: что искать", Params: obj(map[string]any{"question": str("что нужно найти или выяснить на экране (можно пусто)")}),
			Run: func(ctx context.Context, a map[string]any) (string, error) { return d.look(ctx, argStr(a, "question")) }},
		{Name: "mouse", Desc: "Мышь: action=move|click|double|right|scroll_up|scroll_down; x,y в пикселях последнего снимка (screen)", Dangerous: true,
			Params: obj(map[string]any{"action": str("move, click, double, right, scroll_up или scroll_down"), "x": intp, "y": intp}, "action"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				if err := d.needXdotool(); err != nil {
					return "", err
				}
				act := argStr(a, "action")
				if strings.HasPrefix(act, "scroll") {
					btn := "5"
					if act == "scroll_up" {
						btn = "4"
					}
					_, err := run(ctx, "xdotool", "click", "--repeat", "3", btn)
					return "прокрутила", err
				}
				x, y := d.toReal(argInt(a, "x"), argInt(a, "y"))
				if x <= 0 && y <= 0 {
					return "", fmt.Errorf("нужны x и y из последнего снимка (сначала вызови screen)")
				}
				if _, err := run(ctx, "xdotool", "mousemove", fmt.Sprint(x), fmt.Sprint(y)); err != nil {
					return "", err
				}
				switch act {
				case "move":
				case "click":
					_, err := run(ctx, "xdotool", "click", "1")
					return fmt.Sprintf("клик в (%d,%d)", x, y), err
				case "double":
					_, err := run(ctx, "xdotool", "click", "--repeat", "2", "--delay", "80", "1")
					return fmt.Sprintf("двойной клик в (%d,%d)", x, y), err
				case "right":
					_, err := run(ctx, "xdotool", "click", "3")
					return fmt.Sprintf("правый клик в (%d,%d)", x, y), err
				default:
					return "", fmt.Errorf("неизвестное действие %q", act)
				}
				return fmt.Sprintf("курсор в (%d,%d)", x, y), nil
			}},
		{Name: "type", Desc: "Напечатать текст в активном окне (до 500 символов)", Dangerous: true, Params: obj(map[string]any{"text": str("текст")}, "text"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				if err := d.needXdotool(); err != nil {
					return "", err
				}
				t := argStr(a, "text")
				if t == "" || len([]rune(t)) > 500 || strings.ContainsRune(t, 0) {
					return "", fmt.Errorf("текст пустой или длиннее 500 символов")
				}
				_, err := run(ctx, "xdotool", "type", "--delay", "25", "--", t)
				return "напечатала", err
			}},
		{Name: "key", Desc: "Нажать клавишу или сочетание (Return, Escape, ctrl+l, alt+Tab, super)", Dangerous: true, Params: obj(map[string]any{"keys": str("сочетание в формате xdotool")}, "keys"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				if err := d.needXdotool(); err != nil {
					return "", err
				}
				k := argStr(a, "keys")
				if !regexp.MustCompile(`^[A-Za-z0-9_+ ]{1,40}$`).MatchString(k) {
					return "", fmt.Errorf("странное сочетание клавиш")
				}
				_, err := run(ctx, "xdotool", append([]string{"key"}, strings.Fields(k)...)...)
				return "нажала " + k, err
			}},
		{Name: "open_app", Desc: "Запустить программу или открыть адрес/файл (firefox, discord, https://...)", Dangerous: true, Params: obj(map[string]any{"target": str("команда программы или URL/путь")}, "target"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				if err := d.needDisplay(); err != nil {
					return "", err
				}
				t := strings.TrimSpace(argStr(a, "target"))
				if t == "" || len(t) > 300 || strings.ContainsAny(t, "\x00\n;&|`$<>") {
					return "", fmt.Errorf("странная цель запуска")
				}
				var cmd *exec.Cmd
				if strings.Contains(t, "://") || strings.HasPrefix(t, "/") || strings.HasPrefix(t, "~") {
					if !have("xdg-open") {
						return "", fmt.Errorf("нет xdg-open")
					}
					cmd = exec.Command("xdg-open", t)
				} else {
					f := strings.Fields(t)
					if !have(f[0]) {
						return "", fmt.Errorf("программы %q нет в системе", f[0])
					}
					cmd = exec.Command(f[0], f[1:]...)
				}
				cmd.Stdout, cmd.Stderr = nil, nil
				if err := cmd.Start(); err != nil {
					return "", err
				}
				go cmd.Wait()
				return "запустила " + t, nil
			}},
		{Name: "set_wallpaper", Desc: "Сменить обои рабочего стола на картинку", Dangerous: true, Params: obj(map[string]any{"path": str("путь к картинке")}, "path"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				return d.wallpaper(ctx, argStr(a, "path"))
			}},
		{Name: "write_file", Desc: "Записать текстовый файл (до 100 КБ) в домашний каталог владельца", Dangerous: true, Params: obj(map[string]any{"path": str("путь"), "content": str("содержимое")}, "path", "content"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				p, c := argStr(a, "path"), argStr(a, "content")
				if len(c) > 100_000 {
					return "", fmt.Errorf("слишком длинный файл")
				}
				if strings.HasPrefix(p, "~/") {
					h, _ := os.UserHomeDir()
					p = filepath.Join(h, p[2:])
				}
				abs, err := filepath.Abs(p)
				if err != nil {
					return "", err
				}
				for _, dn := range s.Policy.Deny {
					if dn != "" && (abs == dn || strings.HasPrefix(abs, dn+string(filepath.Separator))) {
						return "", fmt.Errorf("каталог закрыт политикой (секреты Рейны)")
					}
				}
				if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
					return "", err
				}
				return "записала " + abs, os.WriteFile(abs, []byte(c), 0o644)
			}},
		{Name: "web", Desc: "Прочитать веб-страницу по адресу (текст, до 400 КБ)", Params: obj(map[string]any{"url": str("http(s)://...")}, "url"),
			Run: func(ctx context.Context, a map[string]any) (string, error) { return d.fetch(ctx, argStr(a, "url")) }},
		{Name: "wait", Desc: "Подождать N секунд (до 10), пока загрузится окно или страница", Params: obj(map[string]any{"seconds": intp}, "seconds"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				n := argInt(a, "seconds")
				if n < 1 {
					n = 1
				}
				if n > 10 {
					n = 10
				}
				select {
				case <-time.After(time.Duration(n) * time.Second):
				case <-ctx.Done():
				}
				return fmt.Sprintf("подождала %d с", n), nil
			}},
	}
}
