package tools

// Модули: независимые способности Рейны. Модуль это папка ~/.reina/modules/<имя>/ с manifest.json и любым исполняемым файлом.
// Ядро подхватывает модули на лету (пересборка и перезапуск не нужны), каждый вызов это отдельный процесс со своим таймаутом.
// Рейна пишет модули себе сама инструментом module_write; новый модуль включается сразу.
//
// Контракт модуля: аргументы приходят JSON-объектом в stdin, результат это stdout (до 50 КБ),
// ненулевой код выхода это ошибка (хвост stderr попадает в ответ). Рабочая папка: папка модуля.
// Переменные окружения: REINA_HOME, REINA_MODULE_DIR.

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"reina/internal/llm"
)

var (
	modName = regexp.MustCompile(`^[a-z][a-z0-9_]{1,30}$`)
	modFile = regexp.MustCompile(`^[A-Za-z0-9_.-]{1,40}$`)
)

const (
	modCodeMax = 60000
	modOutMax  = 50000
)

type modManifest struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Params      map[string]any `json:"params"` // имя параметра -> {"type":"string","description":"..."}
	Required    []string       `json:"required,omitempty"`
	Run         string         `json:"run"` // исполняемый файл внутри папки модуля
	TimeoutSec  int            `json:"timeout_sec,omitempty"`
	Disabled    bool           `json:"disabled,omitempty"`
}

type modules struct {
	dir string
	mu  sync.Mutex // записи в папку модулей по одной
}

func (m *modules) home() string { return filepath.Dir(m.dir) }

func (m *modules) audit(format string, a ...any) {
	f, err := os.OpenFile(filepath.Join(m.dir, "AUDIT.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s %s\n", time.Now().Format("2006-01-02 15:04:05"), fmt.Sprintf(format, a...))
}

func (m *modules) load(name string) (modManifest, error) {
	var mf modManifest
	if !modName.MatchString(name) {
		return mf, errors.New("имя модуля: строчные латинские буквы, цифры и _, начинается с буквы, до 31 символа")
	}
	b, err := os.ReadFile(filepath.Join(m.dir, name, "manifest.json"))
	if err != nil {
		return mf, fmt.Errorf("модуля %q нет", name)
	}
	if err := json.Unmarshal(b, &mf); err != nil {
		return mf, fmt.Errorf("manifest.json модуля %q повреждён: %v", name, err)
	}
	mf.Name = name
	rel := filepath.Clean(mf.Run)
	if mf.Run == "" || filepath.IsAbs(rel) || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return mf, fmt.Errorf("модуль %q: run должен быть файлом внутри папки модуля", name)
	}
	return mf, nil
}

func (m *modules) names() []string {
	ents, _ := os.ReadDir(m.dir)
	var out []string
	for _, e := range ents {
		if e.IsDir() && modName.MatchString(e.Name()) {
			out = append(out, e.Name())
		}
	}
	sort.Strings(out)
	return out
}

func (m *modules) tool(mf modManifest) Tool {
	props := mf.Params
	if props == nil {
		props = map[string]any{}
	}
	return Tool{Name: "m_" + mf.Name, Dangerous: true, Desc: "[модуль] " + mf.Description, Params: obj(props, mf.Required...),
		Run: func(ctx context.Context, args map[string]any) (string, error) { return m.run(ctx, mf.Name, args) }}
}

// get возвращает инструмент включённого модуля по имени вида m_<имя>.
func (m *modules) get(toolName string) (Tool, bool) {
	mf, err := m.load(strings.TrimPrefix(toolName, "m_"))
	if err != nil || mf.Disabled {
		return Tool{}, false
	}
	return m.tool(mf), true
}

func (m *modules) defs() []llm.Tool {
	var out []llm.Tool
	for _, n := range m.names() {
		mf, err := m.load(n)
		if err != nil || mf.Disabled {
			continue
		}
		t := m.tool(mf)
		var d llm.Tool
		d.Type = "function"
		d.Function.Name, d.Function.Description, d.Function.Parameters = t.Name, t.Desc, t.Params
		out = append(out, d)
	}
	return out
}

type capBuf struct {
	b   bytes.Buffer
	max int
}

func (c *capBuf) Write(p []byte) (int, error) {
	if room := c.max - c.b.Len(); room > 0 {
		if len(p) > room {
			c.b.Write(p[:room])
		} else {
			c.b.Write(p)
		}
	}
	return len(p), nil
}

func (m *modules) run(ctx context.Context, name string, args map[string]any) (string, error) {
	mf, err := m.load(name)
	if err != nil {
		return "", err
	}
	dir := filepath.Join(m.dir, name)
	to := time.Duration(mf.TimeoutSec) * time.Second
	if to <= 0 {
		to = 30 * time.Second
	}
	if to > 300*time.Second {
		to = 300 * time.Second
	}
	ctx, cancel := context.WithTimeout(ctx, to)
	defer cancel()
	in, _ := json.Marshal(args)
	cmd := exec.CommandContext(ctx, filepath.Join(dir, filepath.Clean(mf.Run)))
	cmd.Dir = dir
	cmd.Env = append(os.Environ(), "REINA_HOME="+m.home(), "REINA_MODULE_DIR="+dir)
	cmd.Stdin = bytes.NewReader(in)
	out, errb := &capBuf{max: modOutMax}, &capBuf{max: 4000}
	cmd.Stdout, cmd.Stderr = out, errb
	own(cmd)
	cmd.WaitDelay = 2 * time.Second
	m.audit("запуск %s (%d байт аргументов)", name, len(in))
	err = cmd.Run()
	if ctx.Err() == context.DeadlineExceeded {
		return out.b.String(), fmt.Errorf("модуль %s не уложился в %s и остановлен", name, to)
	}
	if err != nil {
		return out.b.String(), fmt.Errorf("модуль %s: %v: %s", name, err, strings.TrimSpace(errb.b.String()))
	}
	return strings.TrimSpace(out.b.String()), nil
}

// tools: инструменты управления модулями (для Рейны).
func (m *modules) tools() []Tool {
	return []Tool{
		{Name: "module_write", Dangerous: true, Desc: "Создать или обновить свой модуль (новую способность). Модуль это исполняемый скрипт: аргументы приходят JSON в stdin, ответ в stdout. Включается сразу, вызывается как инструмент m_<name>. code обязан начинаться с #! (например #!/bin/sh или #!/usr/bin/env python3). test_args: один пробный запуск сразу после записи",
			Params: obj(map[string]any{
				"name":        str("имя: строчные латинские буквы, цифры, _"),
				"description": str("что делает модуль и когда его вызывать (до 300 символов)"),
				"params":      map[string]any{"type": "object", "description": `параметры: {"city":{"type":"string","description":"город"}}`},
				"required":    map[string]any{"type": "array", "items": map[string]any{"type": "string"}},
				"code":        str("полный текст скрипта, начиная с #!"),
				"run_file":    str("имя файла скрипта, по умолчанию run.sh"),
				"timeout_sec": map[string]any{"type": "integer"},
				"test_args":   map[string]any{"type": "object", "description": "аргументы для пробного запуска"},
			}, "name", "description", "code"),
			Run: m.write},
		{Name: "module_list", Desc: "Список своих модулей: имя, включён ли, описание", Params: obj(map[string]any{}),
			Run: func(context.Context, map[string]any) (string, error) {
				var sb strings.Builder
				for _, n := range m.names() {
					mf, err := m.load(n)
					if err != nil {
						fmt.Fprintf(&sb, "%s: ОШИБКА %v\n", n, err)
						continue
					}
					st := "вкл"
					if mf.Disabled {
						st = "выкл"
					}
					fmt.Fprintf(&sb, "m_%s [%s]: %s\n", n, st, mf.Description)
				}
				if sb.Len() == 0 {
					return "модулей пока нет", nil
				}
				return sb.String(), nil
			}},
		{Name: "module_read", Desc: "Прочитать manifest и код своего модуля (чтобы поправить и записать заново через module_write)", Params: obj(map[string]any{"name": str("имя модуля")}, "name"),
			Run: func(_ context.Context, a map[string]any) (string, error) {
				mf, err := m.load(argStr(a, "name"))
				if err != nil {
					return "", err
				}
				code, _ := os.ReadFile(filepath.Join(m.dir, mf.Name, filepath.Clean(mf.Run)))
				b, _ := json.MarshalIndent(mf, "", "  ")
				return string(b) + "\n--- " + mf.Run + " ---\n" + string(code), nil
			}},
		{Name: "module_toggle", Dangerous: true, Desc: "Включить или выключить модуль", Params: obj(map[string]any{"name": str("имя модуля"), "enabled": map[string]any{"type": "boolean"}}, "name", "enabled"),
			Run: func(_ context.Context, a map[string]any) (string, error) {
				m.mu.Lock()
				defer m.mu.Unlock()
				mf, err := m.load(argStr(a, "name"))
				if err != nil {
					return "", err
				}
				en, _ := a["enabled"].(bool)
				mf.Disabled = !en
				if err := m.saveManifest(mf); err != nil {
					return "", err
				}
				m.audit("%s: enabled=%v", mf.Name, en)
				return fmt.Sprintf("модуль %s: включён=%v", mf.Name, en), nil
			}},
		{Name: "module_delete", Dangerous: true, Desc: "Удалить свой модуль целиком", Params: obj(map[string]any{"name": str("имя модуля")}, "name"),
			Run: func(_ context.Context, a map[string]any) (string, error) {
				m.mu.Lock()
				defer m.mu.Unlock()
				n := argStr(a, "name")
				if _, err := m.load(n); err != nil {
					return "", err
				}
				if err := os.RemoveAll(filepath.Join(m.dir, n)); err != nil {
					return "", err
				}
				m.audit("удалён %s", n)
				return "модуль " + n + " удалён", nil
			}},
	}
}

func (m *modules) saveManifest(mf modManifest) error {
	b, _ := json.MarshalIndent(mf, "", "  ")
	return os.WriteFile(filepath.Join(m.dir, mf.Name, "manifest.json"), b, 0o644)
}

func (m *modules) write(ctx context.Context, a map[string]any) (string, error) {
	name, code := argStr(a, "name"), argStr(a, "code")
	if !modName.MatchString(name) {
		return "", errors.New("имя модуля: строчные латинские буквы, цифры и _, начинается с буквы, до 31 символа")
	}
	desc := strings.TrimSpace(argStr(a, "description"))
	if desc == "" || len([]rune(desc)) > 300 {
		return "", errors.New("нужно описание до 300 символов")
	}
	if len(code) > modCodeMax {
		return "", fmt.Errorf("код длиннее %d байт: раздели на несколько модулей", modCodeMax)
	}
	if !strings.HasPrefix(code, "#!") {
		return "", errors.New("первая строка скрипта должна быть #! (например #!/bin/sh или #!/usr/bin/env python3)")
	}
	run := argStr(a, "run_file")
	if run == "" {
		run = "run.sh"
	}
	if !modFile.MatchString(run) || run == "manifest.json" {
		return "", errors.New("run_file: простое имя файла без папок")
	}
	mf := modManifest{Name: name, Description: desc, Run: run, TimeoutSec: int(argInt(a, "timeout_sec"))}
	if p, ok := a["params"].(map[string]any); ok {
		for k, v := range p {
			if pm, ok := v.(map[string]any); !ok || pm["type"] == nil {
				return "", fmt.Errorf("параметр %q: нужен объект с полем type", k)
			}
		}
		mf.Params = p
	}
	if r, ok := a["required"].([]any); ok {
		for _, x := range r {
			s, _ := x.(string)
			if _, ok := mf.Params[s]; !ok {
				return "", fmt.Errorf("required: параметра %q нет в params", s)
			}
			mf.Required = append(mf.Required, s)
		}
	}
	m.mu.Lock()
	dir := filepath.Join(m.dir, name)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		m.mu.Unlock()
		return "", err
	}
	if old, err := os.ReadFile(filepath.Join(dir, run)); err == nil { // предыдущая версия остаётся рядом
		_ = os.WriteFile(filepath.Join(dir, run+".prev"), old, 0o755)
	}
	if err := os.WriteFile(filepath.Join(dir, run), []byte(code), 0o755); err != nil {
		m.mu.Unlock()
		return "", err
	}
	_ = os.Chmod(filepath.Join(dir, run), 0o755)
	err := m.saveManifest(mf)
	m.audit("записан %s (%d байт, run=%s)", name, len(code), run)
	m.mu.Unlock()
	if err != nil {
		return "", err
	}
	res := fmt.Sprintf("модуль %s записан и включён: вызывай инструмент m_%s", name, name)
	if ta, ok := a["test_args"].(map[string]any); ok {
		out, err := m.run(ctx, name, ta)
		if err != nil {
			return res + "\nпробный запуск не удался: " + err.Error() + "\nвывод: " + Truncate(out, 800), nil
		}
		res += "\nпробный запуск: " + Truncate(out, 800)
	}
	return res, nil
}
