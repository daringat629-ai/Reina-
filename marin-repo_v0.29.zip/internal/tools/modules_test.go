package tools

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"reina/internal/memory"
)

func modSet(t *testing.T) (*Set, string) { return modSetPolicy(t, "always") }

// modSetPolicy: модули это исполняемый код, поэтому подчиняются shell_policy; большинство тестов идёт с «always» (как будто владелец разрешил).
func modSetPolicy(t *testing.T, policy string) (*Set, string) {
	t.Helper()
	home := t.TempDir()
	p := DefaultPolicy(home)
	p.Shell = policy
	p.ModulesDir = filepath.Join(home, "modules")
	return Default(memory.Open(home), p), home
}

const echoArgs = `{"name":"echo","description":"повторяет text","params":{"text":{"type":"string","description":"что повторить"}},"required":["text"],"code":"#!/bin/sh\nread j\necho \"got: $j\"","test_args":{"text":"hi"}}`

func TestModuleWrittenByHerselfIsLiveAtOnceAndGetsJSONOnStdin(t *testing.T) {
	s, _ := modSet(t)
	r := call(s, "module_write", echoArgs)
	if !strings.Contains(r, "записан и включён") || !strings.Contains(r, `got: {"text":"hi"}`) {
		t.Fatalf("запись и пробный запуск: %s", r)
	}
	found := false
	for _, d := range s.Defs() {
		if d.Function.Name == "m_echo" && strings.Contains(d.Function.Description, "повторяет") {
			found = true
		}
	}
	if !found {
		t.Fatal("новый модуль должен сразу появиться среди инструментов")
	}
	if r := call(s, "m_echo", `{"text":"привет"}`); !strings.Contains(r, `"text":"привет"`) {
		t.Fatalf("вызов: %s", r)
	}
	if s.Parallel("m_echo") {
		t.Fatal("модуль это опасное действие: параллельно без подтверждения его запускать нельзя")
	}
}

func TestModuleOnDiskIsPickedUpWithoutRestart(t *testing.T) {
	s, home := modSet(t)
	dir := filepath.Join(home, "modules", "hand")
	os.MkdirAll(dir, 0o755)
	os.WriteFile(filepath.Join(dir, "manifest.json"), []byte(`{"description":"ручной","run":"go.sh"}`), 0o644)
	os.WriteFile(filepath.Join(dir, "go.sh"), []byte("#!/bin/sh\necho руками\n"), 0o755)
	if r := call(s, "m_hand", `{}`); r != "руками" {
		t.Fatalf("%q", r)
	}
}

func TestModuleRejectsBadNamesTraversalAndMissingShebang(t *testing.T) {
	s, home := modSet(t)
	for _, a := range []string{
		`{"name":"../evil","description":"x","code":"#!/bin/sh\n"}`,
		`{"name":"Bad","description":"x","code":"#!/bin/sh\n"}`,
		`{"name":"ok","description":"x","code":"echo без шебанга"}`,
		`{"name":"ok","description":"x","code":"#!/bin/sh\n","run_file":"../x.sh"}`,
		`{"name":"ok","description":"x","code":"#!/bin/sh\n","run_file":"manifest.json"}`,
		`{"name":"ok","description":"x","code":"#!/bin/sh\n","params":{"a":"строка"}}`,
		`{"name":"ok","description":"x","code":"#!/bin/sh\n","params":{"a":{"type":"string"}},"required":["b"]}`,
	} {
		if r := call(s, "module_write", a); !strings.HasPrefix(r, "ошибка") {
			t.Errorf("должно быть отклонено: %s -> %s", a, r)
		}
	}
	if _, err := os.Stat(filepath.Join(home, "evil")); err == nil {
		t.Fatal("выход из папки модулей")
	}
	os.MkdirAll(filepath.Join(home, "modules", "esc"), 0o755)
	os.WriteFile(filepath.Join(home, "modules", "esc", "manifest.json"), []byte(`{"description":"x","run":"../../x.sh"}`), 0o644)
	if r := call(s, "m_esc", `{}`); !strings.Contains(r, "нет или он выключен") {
		t.Fatalf("run за пределами папки: %s", r)
	}
}

func TestModuleTimeoutKillsTheWholeProcessGroup(t *testing.T) {
	s, home := modSet(t)
	pid := filepath.Join(home, "child.pid")
	code := "#!/bin/sh\nsleep 30 &\necho $! > " + pid + "\nsleep 30\n"
	args, _ := json.Marshal(map[string]any{"name": "slow", "description": "медленный", "timeout_sec": 1, "code": code})
	call(s, "module_write", string(args))
	t0 := time.Now()
	r := call(s, "m_slow", `{}`)
	if time.Since(t0) > 6*time.Second || !strings.Contains(r, "не уложился") {
		t.Fatalf("таймаут: %v %s", time.Since(t0), r)
	}
	b, _ := os.ReadFile(pid)
	time.Sleep(200 * time.Millisecond)
	if _, err := os.Stat("/proc/" + strings.TrimSpace(string(b))); err == nil {
		if st, _ := os.ReadFile("/proc/" + strings.TrimSpace(string(b)) + "/stat"); !strings.Contains(string(st), ") Z") {
			t.Fatal("дочерний процесс модуля пережил таймаут")
		}
	}
}

func TestModuleErrorsToggleDeleteListAndAudit(t *testing.T) {
	s, home := modSet(t)
	call(s, "module_write", `{"name":"bad","description":"падает","code":"#!/bin/sh\necho oops >&2\nexit 3"}`)
	if r := call(s, "m_bad", `{}`); !strings.Contains(r, "oops") || !strings.Contains(r, "exit status 3") {
		t.Fatalf("ошибка модуля: %s", r)
	}
	if r := call(s, "module_list", `{}`); !strings.Contains(r, "m_bad [вкл]") {
		t.Fatal(r)
	}
	call(s, "module_toggle", `{"name":"bad","enabled":false}`)
	if r := call(s, "m_bad", `{}`); !strings.Contains(r, "нет или он выключен") {
		t.Fatalf("выключенный модуль не вызывается: %s", r)
	}
	for _, d := range s.Defs() {
		if d.Function.Name == "m_bad" {
			t.Fatal("выключенный модуль не должен быть в Defs")
		}
	}
	// обновление оставляет предыдущую версию
	call(s, "module_write", `{"name":"bad","description":"починила","code":"#!/bin/sh\necho ok"}`)
	if _, err := os.Stat(filepath.Join(home, "modules", "bad", "run.sh.prev")); err != nil {
		t.Fatal("нет .prev")
	}
	if r := call(s, "module_read", `{"name":"bad"}`); !strings.Contains(r, "echo ok") {
		t.Fatal(r)
	}
	call(s, "module_delete", `{"name":"bad"}`)
	if _, err := os.Stat(filepath.Join(home, "modules", "bad")); err == nil {
		t.Fatal("не удалён")
	}
	a, _ := os.ReadFile(filepath.Join(home, "modules", "AUDIT.log"))
	if !strings.Contains(string(a), "записан bad") || !strings.Contains(string(a), "удалён bad") || !strings.Contains(string(a), "запуск bad") {
		t.Fatalf("аудит: %s", a)
	}
}

func TestModuleOutputIsCapped(t *testing.T) {
	s, _ := modSet(t)
	call(s, "module_write", `{"name":"big","description":"много","code":"#!/bin/sh\nyes x | head -c 200000"}`)
	if r := call(s, "m_big", `{}`); len(r) > modOutMax+10 {
		t.Fatalf("вывод не ограничен: %d", len(r))
	}
}

func TestModulesOffWhenNoDir(t *testing.T) {
	s, _ := deskSet(t)
	if r := call(s, "module_list", `{}`); !strings.Contains(r, "нет или он выключен") {
		t.Fatal(r)
	}
	_ = context.Background()
}

func TestModulesFollowShellPolicyNever(t *testing.T) {
	s, home := modSetPolicy(t, "never")
	if r := call(s, "module_write", echoArgs); !strings.Contains(r, "отказ") {
		t.Fatalf("запись при never: %s", r)
	}
	if _, err := os.Stat(filepath.Join(home, "modules", "echo")); err == nil {
		t.Fatal("модуль появился на диске при never")
	}
	for _, d := range s.Defs() {
		if strings.HasPrefix(d.Function.Name, "m_") {
			t.Fatal("модели не должны быть видны модули при never")
		}
	}
	// модуль, лежащий на диске, тоже не запускается
	dir := filepath.Join(home, "modules", "hand")
	os.MkdirAll(dir, 0o755)
	os.WriteFile(filepath.Join(dir, "manifest.json"), []byte(`{"description":"ручной","run":"go.sh"}`), 0o644)
	os.WriteFile(filepath.Join(dir, "go.sh"), []byte("#!/bin/sh\necho руками\n"), 0o755)
	if r := call(s, "m_hand", `{}`); !strings.Contains(r, "отказ") {
		t.Fatalf("запуск при never: %s", r)
	}
}

func TestModulesAskNeedsOwnerConfirmation(t *testing.T) {
	s, home := modSetPolicy(t, "ask")
	deny := func(string) bool { return false }
	if r := s.Exec(context.Background(), &Turn{}, "module_write", echoArgs, deny); !strings.Contains(r, "отказ") {
		t.Fatalf("без подтверждения: %s", r)
	}
	if _, err := os.Stat(filepath.Join(home, "modules", "echo")); err == nil {
		t.Fatal("модуль записан без подтверждения")
	}
	yes := func(string) bool { return true }
	if r := s.Exec(context.Background(), &Turn{}, "module_write", echoArgs, yes); !strings.Contains(r, "записан и включён") {
		t.Fatalf("с подтверждением: %s", r)
	}
	if r := s.Exec(context.Background(), &Turn{}, "m_echo", `{"text":"x"}`, deny); !strings.Contains(r, "отказ") {
		t.Fatalf("запуск без подтверждения: %s", r)
	}
	if r := s.Exec(context.Background(), &Turn{}, "m_echo", `{"text":"x"}`, yes); !strings.Contains(r, `"text":"x"`) {
		t.Fatalf("запуск с подтверждением: %s", r)
	}
}
