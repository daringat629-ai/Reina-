package agent

import (
	"regexp"
	"strings"
	"unicode"
)

// Защита ответа (перенесена из старой Марин: output_guard + opener_guard).
// Проверяется устройство текста, а не список фраз: рассуждение модели вместо реплики, утечка внутренних мыслей,
// зацикливание, мусорные слова, мужской род о себе.

var metaRe = regexp.MustCompile(`(?i)\blet me (?:connect|try|check|call|use|run|open|look|think|analy[sz]e|respond|reply|see|figure|start)\b|` +
	`\bi(?:'ll| will| need to| should| must| am going to|'m going to) (?:respond|reply|answer|write|produce|generate|craft|analy[sz]e)\b|` +
	`\b(?:the|this) (?:owner|user|assistant|human)\b[^.\n]{0,60}\b(?:said|asked|asks|wants|sent|replied|wrote|just)\b|` +
	`\bin response to (?:my|the|his|her|their)\b|\bmy previous (?:message|reply|response|answer)s?\b|` +
	`\bas an ai\b|\blanguage model\b|\bsystem prompt\b|\bstay in character\b|` +
	`\bкак (?:ии|ai|языковая модель|нейросеть|ассистент|бот)[,.!\s]|` +
	`\b(?:владелец|пользователь|собеседник) (?:написал|просит|спрашивает|хочет|сказал|прислал)\b|` +
	`\bмне (?:нужно|надо|следует) (?:ответить|сформулировать|сгенерировать|написать ответ)\b|` +
	`\bсистемн(?:ый|ого) промпт|\bв роли рейны\b`)

var thinkLabelRe = regexp.MustCompile(`(?m)^\s*[-*•]?\s*(?:Хочет|Чувствую|План|Не повторять|Запомнить|Дневник|Голос|Эмодзи|Человек|Настроение)\s*:`)
var numberedEnRe = regexp.MustCompile(`(?m)(?:^|\n)\s*[1-9][.)]\s+[A-Za-z]`)
var mascRe = regexp.MustCompile(`(?i)\bя\s+(?:(?:уже|тоже|просто|сейчас|вчера|сегодня|только|вот|же|ведь|не)\s+){0,2}(?:[а-яё]{3,}(?:ал|ял|ил|ел|ёл|ыл|ул))\b`)
var wordRe = regexp.MustCompile(`[\p{L}\p{N}]+`)
var mixedRe = regexp.MustCompile(`[\p{L}]+`)

type verdict struct{ hard, soft []string }

func (v verdict) has(s string) bool {
	for _, x := range append(append([]string{}, v.hard...), v.soft...) {
		if x == s {
			return true
		}
	}
	return false
}

func normWords(t string) []string {
	var out []string
	for _, w := range wordRe.FindAllString(strings.ToLower(strings.ReplaceAll(t, "ё", "е")), -1) {
		out = append(out, w)
	}
	return out
}

// leaksThought: в ответе дословно повторяется кусок из её внутренних мыслей (4 слова подряд).
func leaksThought(answer, thought string) bool {
	tw := normWords(thought)
	aw := normWords(answer)
	if len(tw) < 4 || len(aw) < 4 {
		return false
	}
	seen := map[string]bool{}
	for i := 0; i+4 <= len(tw); i++ {
		seen[strings.Join(tw[i:i+4], " ")] = true
	}
	for i := 0; i+4 <= len(aw); i++ {
		if seen[strings.Join(aw[i:i+4], " ")] {
			return true
		}
	}
	return false
}

func repetitionScore(t string) int {
	var sents []map[string]bool
	for _, s := range regexp.MustCompile(`[.!?…\n]+`).Split(t, -1) {
		w := normWords(s)
		if len(w) >= 3 {
			m := map[string]bool{}
			for _, x := range w {
				m[x] = true
			}
			sents = append(sents, m)
		}
	}
	best := 1
	for i := range sents {
		g := 1
		for j := i + 1; j < len(sents); j++ {
			if wordOverlap(sents[i], sents[j]) >= 0.8 {
				g++
			}
		}
		if g > best {
			best = g
		}
	}
	return best
}

func latinShare(t string) float64 {
	lat, cyr := 0, 0
	for _, r := range t {
		switch {
		case unicode.Is(unicode.Cyrillic, r):
			cyr++
		case r < 128 && unicode.IsLetter(r):
			lat++
		}
	}
	if lat+cyr == 0 {
		return 0
	}
	return float64(lat) / float64(lat+cyr)
}

func garbled(t string) bool {
	for _, w := range mixedRe.FindAllString(t, -1) {
		cyr, lat := false, false
		for _, r := range w {
			if unicode.Is(unicode.Cyrillic, r) {
				cyr = true
			} else if r < 128 {
				lat = true
			}
		}
		if cyr && lat {
			return true
		}
	}
	for _, r := range t {
		if unicode.Is(unicode.Greek, r) {
			return true
		}
	}
	return false
}

// assess: hard: отправлять нельзя; soft: стоит перегенерировать.
func assess(text, thought string) verdict {
	var v verdict
	t := strings.TrimSpace(text)
	if t == "" {
		return v
	}
	if metaRe.MatchString(t) {
		v.hard = append(v.hard, "meta")
	}
	if thinkLabelRe.MatchString(t) || (thought != "" && leaksThought(t, thought)) {
		v.hard = append(v.hard, "leak")
	}
	if repetitionScore(t) >= 3 {
		v.hard = append(v.hard, "repeat")
	}
	if latinShare(t) > 0.6 && len(wordRe.FindAllString(t, -1)) >= 12 && numberedEnRe.MatchString(t) {
		v.hard = append(v.hard, "meta")
	}
	if garbled(t) {
		v.soft = append(v.soft, "garbled")
	}
	if mascRe.MatchString(t) {
		v.soft = append(v.soft, "masc")
	}
	return v
}

func fixHint(v verdict) string {
	var n []string
	if v.has("meta") {
		n = append(n, "Прошлый вариант был рассуждением о задаче, а не репликой. Напиши только саму живую реплику Рейны, по-русски, без анализа и планов.")
	}
	if v.has("leak") {
		n = append(n, "В прошлом варианте были твои внутренние мысли или их формулировки. Собеседник их не видит: ответь своими словами, живо, без цитат из мыслей.")
	}
	if v.has("repeat") {
		n = append(n, "Прошлый вариант зациклился на одной фразе. Скажи мысль один раз, коротко.")
	}
	if v.has("masc") {
		n = append(n, "Рейна девушка: о себе только в женском роде (сделала, написала, сама).")
	}
	if v.has("garbled") {
		n = append(n, "В прошлом варианте были испорченные слова (смесь алфавитов). Пиши обычными русскими словами.")
	}
	return strings.Join(n, " ")
}

// stripLeak выкидывает строки, повторяющие мысли или начинающиеся с меток мыслей.
func stripLeak(text, thought string) string {
	var out []string
	for _, ln := range strings.Split(text, "\n") {
		l := strings.TrimSpace(ln)
		if l == "" {
			continue
		}
		if thinkLabelRe.MatchString(l) || metaRe.MatchString(l) || (thought != "" && leaksThought(l, thought)) {
			continue
		}
		out = append(out, l)
	}
	return strings.TrimSpace(strings.Join(out, "\n"))
}

// ---- антиповтор начал ответов ----

var fillers = map[string]bool{"ну": true, "ой": true, "ох": true, "эх": true, "ух": true, "блин": true, "слушай": true, "короче": true, "лол": true, "кек": true, "ор": true}
var laughRe = regexp.MustCompile(`^[ахеопиуы]{3,}$`)

func isLaugh(w string) bool {
	return fillers[w] && (w == "лол" || w == "кек" || w == "ор") || (laughRe.MatchString(w) && strings.Contains(w, "х"))
}

func opener(text string) (k1, k2 string) {
	w := normWords(text)
	if len(w) == 0 {
		return "", ""
	}
	n := func(s string) string {
		if isLaugh(s) {
			return "ахах"
		}
		return s
	}
	k1 = n(w[0])
	k2 = k1
	if len(w) > 1 {
		k2 += " " + n(w[1])
	}
	return
}

func (a *Agent) openerRecord(text string) {
	k1, k2 := opener(text)
	if k1 == "" {
		return
	}
	a.mu.Lock()
	a.openers = append(a.openers, [2]string{k1, k2})
	if len(a.openers) > 24 {
		a.openers = a.openers[len(a.openers)-24:]
	}
	a.mu.Unlock()
}

func (a *Agent) openerBanned(k1, k2 string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	rec := a.openers
	if len(rec) > 6 {
		rec = rec[len(rec)-6:]
	}
	c1, c2 := 0, 0
	for _, o := range rec {
		if o[0] == k1 {
			c1++
		}
		if o[1] == k2 {
			c2++
		}
	}
	return c1 >= 2 || c2 >= 2
}

// openerHint: подсказка модели, если её последние ответы начинались одинаково.
func (a *Agent) openerHint() string {
	a.mu.Lock()
	rec := a.openers
	a.mu.Unlock()
	if len(rec) > 6 {
		rec = rec[len(rec)-6:]
	}
	cnt := map[string]int{}
	for _, o := range rec {
		cnt[o[0]]++
	}
	var bad []string
	for k, c := range cnt {
		if c >= 2 {
			bad = append(bad, k)
		}
	}
	if len(bad) == 0 {
		return ""
	}
	return "Твои последние ответы начинались одинаково («" + strings.Join(bad, "», «") + "…»). Начни это сообщение по-другому, без этого зачина."
}

// openerFix убирает повторяющееся вводное слово (смех, «ну», «ой»…), оставляя фразу целой.
func (a *Agent) openerFix(text string) string {
	k1, k2 := opener(text)
	if k1 == "" || !a.openerBanned(k1, k2) {
		return text
	}
	first := normWords(text)[0]
	if !(isLaugh(first) || fillers[first]) {
		return text
	}
	loc := wordRe.FindStringIndex(text)
	if loc == nil {
		return text
	}
	rest := strings.TrimLeft(text[loc[1]:], " ,.!?…—-~")
	if len([]rune(rest)) < 3 {
		return text
	}
	r := []rune(rest)
	r[0] = unicode.ToUpper(r[0])
	return string(r)
}
