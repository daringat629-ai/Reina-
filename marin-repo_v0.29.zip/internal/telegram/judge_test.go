package telegram

import (
	"testing"
	"time"
)

func TestJudgeKind(t *testing.T) {
	for in, want := range map[string]string{"Рейна, ахахах": "laugh", "спасибо!": "thanks", "ок": "ack", "как дела?": "question", "расскажи про свой день подробно": "normal"} {
		if got := judgeKind(in); got != want {
			t.Errorf("%q: %s != %s", in, got, want)
		}
	}
}

func TestJudgeFatigueAndQuestion(t *testing.T) {
	var j groupJudge
	now := time.Now()
	for i := 0; i < 3; i++ {
		j.noteReply(1, 2, now)
	}
	if d := j.decide(1, 2, "почему так?", false, now); d.Action != "reply" || !d.Brief {
		t.Fatalf("вопрос: %+v", d)
	}
	if d := j.decide(1, 2, "расскажи про свой день подробно", false, now); d.Action == "reply" && !d.Brief {
		t.Fatalf("усталый диалог должен быть коротким или реакцией: %+v", d)
	}
}
