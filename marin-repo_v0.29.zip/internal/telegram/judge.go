package telegram

import (
	"math/rand"
	"regexp"
	"strings"
	"sync"
	"time"
)

// groupJudge: умнее в группах (перенесено из старой Марин). На обращение решает: ответить, поставить реакцию или промолчать.
// Учитывает тип сообщения, «усталость» диалога с этим человеком и оживлённость чата.

type judgeDecision struct {
	Action string // reply | react | skip
	Emoji  string
	Brief  bool // ответить одной короткой репликой без встречного вопроса
	Reason string
}

type groupJudge struct {
	mu      sync.Mutex
	replies map[string][]time.Time // "chat:sender" -> когда она отвечала
	rate    map[int64][]time.Time  // сообщения в чате (для оживлённости)
	rng     *rand.Rand
}

var (
	jWord  = regexp.MustCompile(`[\p{L}\p{N}]+`)
	jLaugh = regexp.MustCompile(`^(?:[ахеопиуы]{3,}|лол|кек|ор|хд|ржу|ржака|😂|🤣|😁)+$`)
	jName  = regexp.MustCompile(`(?i)@\w+|(?:^|[^\p{L}])(?:рейн\p{L}*|reina\p{L}*)`)
	jThx   = []string{"спасибо", "спс", "благодарю", "сенкс", "thx", "thanks", "мерси"}
	jAck   = map[string]bool{"ок": true, "окей": true, "ага": true, "угу": true, "да": true, "ясно": true, "понял": true, "поняла": true, "понятно": true, "норм": true, "ладно": true, "хорошо": true, "супер": true, "класс": true, "круто": true, "мм": true, "хм": true, "ну": true, "+": true, "лан": true}
	jQ     = []string{"кто", "что", "как", "где", "когда", "почему", "зачем", "сколько", "какой", "какая", "какие", "куда", "откуда", "можешь", "можно", "будешь", "правда"}
)

func judgeKind(text string) string {
	t := strings.TrimSpace(jName.ReplaceAllString(text, " "))
	t = strings.Trim(t, " ,.:;—-")
	if t == "" {
		return "short"
	}
	low := strings.ToLower(t)
	w := jWord.FindAllString(low, -1)
	if strings.Contains(t, "?") || (len(w) > 0 && contains(jQ, w[0])) {
		return "question"
	}
	for _, x := range jThx {
		if strings.Contains(low, x) {
			return "thanks"
		}
	}
	if len(w) > 0 && len(w) <= 3 && all(w, func(s string) bool { return jLaugh.MatchString(s) }) {
		return "laugh"
	}
	if len(w) > 0 && len(w) <= 2 && all(w, func(s string) bool { return jAck[s] }) {
		return "ack"
	}
	if len(w) <= 2 && !regexp.MustCompile(`\p{L}{6,}`).MatchString(low) {
		return "short"
	}
	return "normal"
}

func contains(l []string, s string) bool {
	for _, x := range l {
		if x == s {
			return true
		}
	}
	return false
}

func all(w []string, f func(string) bool) bool {
	for _, x := range w {
		if !f(x) {
			return false
		}
	}
	return true
}

func (j *groupJudge) init() {
	if j.replies == nil {
		j.replies = map[string][]time.Time{}
		j.rate = map[int64][]time.Time{}
		j.rng = rand.New(rand.NewSource(time.Now().UnixNano()))
	}
}

func prune(ts []time.Time, now time.Time, d time.Duration) []time.Time {
	i := 0
	for i < len(ts) && now.Sub(ts[i]) > d {
		i++
	}
	return ts[i:]
}

// seen: учесть входящее сообщение чата (оживлённость).
func (j *groupJudge) seen(chat int64, now time.Time) {
	j.mu.Lock()
	defer j.mu.Unlock()
	j.init()
	j.rate[chat] = append(prune(j.rate[chat], now, time.Minute), now)
}

func (j *groupJudge) noteReply(chat, sender int64, now time.Time) {
	j.mu.Lock()
	defer j.mu.Unlock()
	j.init()
	k := keyOf(chat, sender)
	j.replies[k] = append(prune(j.replies[k], now, 10*time.Minute), now)
}

func keyOf(chat, sender int64) string {
	return strings.Join([]string{itoa(chat), itoa(sender)}, ":")
}

func itoa(n int64) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	if neg {
		b = append([]byte{'-'}, b...)
	}
	return string(b)
}

func (j *groupJudge) decide(chat, sender int64, text string, byName bool, now time.Time) judgeDecision {
	j.mu.Lock()
	defer j.mu.Unlock()
	j.init()
	kind := judgeKind(text)
	k := keyOf(chat, sender)
	j.replies[k] = prune(j.replies[k], now, 10*time.Minute)
	fatigue := len(j.replies[k])
	const limit = 3
	busy := len(prune(j.rate[chat], now, time.Minute)) >= 10
	emoji := func(opts ...string) string { return opts[j.rng.Intn(len(opts))] }
	react := func(reason string, opts ...string) judgeDecision {
		if j.rng.Float64() < 0.85 {
			return judgeDecision{Action: "react", Emoji: emoji(opts...), Reason: reason}
		}
		return judgeDecision{Action: "skip", Reason: reason}
	}
	switch {
	case kind == "question":
		return judgeDecision{Action: "reply", Brief: fatigue >= limit, Reason: "вопрос"}
	case kind == "thanks" || kind == "laugh" || kind == "ack":
		if kind == "thanks" && j.rng.Float64() < 0.25 && fatigue < 2 {
			return judgeDecision{Action: "reply", Brief: true, Reason: "благодарность"}
		}
		switch kind {
		case "laugh":
			return react("смех", "😁", "🤣", "😂")
		case "thanks":
			return react("спасибо", "❤", "🥰")
		}
		return react("ок", "👍", "👌")
	case fatigue >= limit:
		if byName && j.rng.Float64() < 0.5 {
			return judgeDecision{Action: "reply", Brief: true, Reason: "затянулось, но позвали по имени"}
		}
		return react("диалог затянулся", "🔥", "👍")
	case busy && !byName:
		return react("чат оживлён", "🔥", "👍")
	case kind == "short":
		return react("нечего отвечать", "👍", "👌")
	}
	return judgeDecision{Action: "reply", Brief: fatigue >= 2, Reason: "разговор"}
}

const briefHint = "[Вы с этим человеком уже несколько раз обменялись репликами в группе. Ответь ОДНОЙ короткой репликой, без встречного вопроса и без развития темы: разговору можно закругляться] "
