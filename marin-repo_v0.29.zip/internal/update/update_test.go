package update

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"
)

func mk(t *testing.T, files map[string][]byte) []byte {
	var b bytes.Buffer
	w := zip.NewWriter(&b)
	for n, c := range files {
		f, _ := w.Create(n)
		f.Write(c)
	}
	w.Close()
	return b.Bytes()
}

func sum(b []byte) []byte { h := sha256.Sum256(b); return []byte(hex.EncodeToString(h[:]) + "  x\n") }

func elf(n int) []byte { return append([]byte("\x7fELF"), make([]byte, n)...) }

func TestExtractPicksRightArchAndRejectsGarbage(t *testing.T) {
	a, r := elf(2<<20), append(elf(2<<20), 1)
	z := mk(t, map[string][]byte{"marin-linux-amd64": a, "marin-linux-amd64.sha256": sum(a), "marin-linux-arm64": r, "marin-linux-arm64.sha256": sum(r)})
	b, name, err := Extract(z, "arm64")
	if err != nil || name != "marin-linux-arm64" || len(b) != 4+(2<<20)+1 {
		t.Fatal(name, err, len(b))
	}
	if _, _, err := Extract(z, "riscv64"); err == nil {
		t.Fatal("нет такой архитектуры")
	}
	if _, _, err := Extract(mk(t, map[string][]byte{"marin-linux-amd64": []byte("not elf, just text....")}), "amd64"); err == nil {
		t.Fatal("не ELF должен отклоняться")
	}
	if _, _, err := Extract([]byte("not a zip"), "amd64"); err == nil {
		t.Fatal("не zip")
	}
}

func TestInstallKeepsOldCopy(t *testing.T) {
	d := t.TempDir()
	exe := filepath.Join(d, "reina")
	os.WriteFile(exe, []byte("old"), 0o755)
	if err := Install(exe, []byte("new")); err != nil {
		t.Fatal(err)
	}
	if b, _ := os.ReadFile(exe); string(b) != "new" {
		t.Fatal("новый не на месте")
	}
	if b, _ := os.ReadFile(exe + ".old"); string(b) != "old" {
		t.Fatal("старый не сохранён")
	}
}

func TestExtractRequiresMatchingSha256(t *testing.T) {
	a := elf(2 << 20)
	if _, _, err := Extract(mk(t, map[string][]byte{"marin-linux-amd64": a}), "amd64"); err == nil {
		t.Fatal("без .sha256 должен быть отказ")
	}
	bad := mk(t, map[string][]byte{"marin-linux-amd64": a, "marin-linux-amd64.sha256": sum(append(elf(2<<20), 9))})
	if _, _, err := Extract(bad, "amd64"); err == nil {
		t.Fatal("несовпадение суммы должно отклоняться")
	}
}
