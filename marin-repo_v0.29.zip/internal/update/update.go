// Package update: самообновление. Хозяин присылает ей в личку zip из GitHub Actions (marin-linux N.zip) с подписью /update:
// она достаёт бинарник под свою архитектуру, подменяет себя (старый остаётся как reina.old) и перезапускается.
package update

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"strings"
)

const maxBin = 80 << 20

// Extract достаёт из zip бинарник под архитектуру goarch (marin-linux-amd64, marin-linux-arm64 или просто reina).
func Extract(zipBytes []byte, goarch string) ([]byte, string, error) {
	zr, err := zip.NewReader(bytes.NewReader(zipBytes), int64(len(zipBytes)))
	if err != nil {
		return nil, "", errors.New("это не zip")
	}
	var pick *zip.File
	for _, f := range zr.File {
		n := strings.ToLower(path.Base(f.Name))
		if f.FileInfo().IsDir() {
			continue
		}
		if strings.Contains(n, "linux-"+goarch) && !strings.HasSuffix(n, ".sha256") {
			pick = f
			break
		}
		if n == "reina" && pick == nil {
			pick = f
		}
	}
	if pick == nil {
		return nil, "", fmt.Errorf("в архиве нет бинарника под %s", goarch)
	}
	if pick.UncompressedSize64 > maxBin {
		return nil, "", errors.New("бинарник слишком большой")
	}
	rc, err := pick.Open()
	if err != nil {
		return nil, "", err
	}
	defer rc.Close()
	b, err := io.ReadAll(io.LimitReader(rc, maxBin+1))
	if err != nil {
		return nil, "", err
	}
	if len(b) < 1<<20 || len(b) > maxBin || !bytes.HasPrefix(b, []byte("\x7fELF")) {
		return nil, "", errors.New("это не исполняемый файл Linux (ELF) или он подозрительно маленький")
	}
	if err := verifySum(zr, pick.Name, b); err != nil {
		return nil, "", err
	}
	return b, pick.Name, nil
}

// verifySum сверяет бинарник с файлом <имя>.sha256 из того же архива (его делает сборка). Без файла или при несовпадении отказ:
// так отсекаются битая загрузка и случайно подменённый файл.
func verifySum(zr *zip.Reader, name string, bin []byte) error {
	var sf *zip.File
	for _, f := range zr.File {
		if strings.EqualFold(path.Base(f.Name), path.Base(name)+".sha256") {
			sf = f
			break
		}
	}
	if sf == nil {
		return errors.New("в архиве нет файла " + path.Base(name) + ".sha256: такие архивы не принимаю (его создаёт новая сборка)")
	}
	rc, err := sf.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	raw, err := io.ReadAll(io.LimitReader(rc, 4096))
	if err != nil {
		return err
	}
	fields := strings.Fields(string(raw))
	if len(fields) == 0 {
		return errors.New("файл .sha256 пустой")
	}
	want := strings.ToLower(fields[0])
	sum := sha256.Sum256(bin)
	if want != hex.EncodeToString(sum[:]) {
		return errors.New("контрольная сумма SHA-256 не совпала: файл повреждён или подменён")
	}
	return nil
}

// Install кладёт новый бинарник на место exe; прежний сохраняется рядом как exe.old.
func Install(exe string, bin []byte) error {
	tmp := exe + ".new"
	if err := os.WriteFile(tmp, bin, 0o755); err != nil {
		return err
	}
	if old, err := os.ReadFile(exe); err == nil {
		_ = os.WriteFile(exe+".old", old, 0o755)
	}
	if err := os.Rename(tmp, exe); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}
