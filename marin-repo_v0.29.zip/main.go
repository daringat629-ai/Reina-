// Reina: ядро бота одним бинарником. Команды: init, run, chat, usage, doctor, models, persona.
package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/care"
	"reina/internal/config"
	"reina/internal/events"
	"reina/internal/images"
	"reina/internal/initiative"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/panel"
	"reina/internal/selfstate"
	"reina/internal/supervisor"
	"reina/internal/telegram"
	"reina/internal/tools"
	"reina/internal/tunnel"
	selfupd "reina/internal/update"
	"reina/internal/voice"
)

// version: версия сборки, видна в панели.
const version = "0.29"

func main() {
	cmd := "run"
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}
	home := config.HomeDir()
	switch cmd {
	case "init":
		fatal(initCfg(home))
	case "import-kuni": // reina import-kuni /путь/к/config.toml прежней версии: берёт api_id и api_hash
		if len(os.Args) < 3 {
			fmt.Println("использование: reina import-kuni /путь/к/config.toml")
			os.Exit(1)
		}
		fatal(importKuni(home, os.Args[2]))
	case "persona": // reina persona: записать в config.json стандартную личность Рейны Вейл
		cfg, err := config.Load(home)
		fatal(err)
		cfg.Agent.Persona = config.Default().Agent.Persona
		fatal(config.Save(cfg))
		fmt.Println("Личность Рейны Вейл записана в", config.Path(home), "\nПерезапустите: reina run")
	case "panel-password": // reina panel-password: новый пароль для входа на сайт-панель
		cfg, err := config.Load(home)
		fatal(err)
		pw := panel.NewPassword()
		cfg.Panel.PasswordHash = panel.HashPassword(pw)
		fatal(config.Save(cfg))
		fmt.Println("Новый пароль панели (показан один раз):", pw, "\nПерезапустите: reina run")
	case "voice": // reina voice <api_key> <voice_id> (ElevenLabs) или reina voice grok [голос] (Grok через OpenRouter)
		if len(os.Args) >= 3 && os.Args[2] == "grok" {
			cfg, err := config.Load(home)
			fatal(err)
			cfg.Voice.TTS, cfg.Voice.STT, cfg.Voice.ORVoice = "openrouter", "openrouter", "eve"
			if len(os.Args) > 3 {
				cfg.Voice.ORVoice = strings.ToLower(os.Args[3])
			}
			fatal(config.Save(cfg))
			fmt.Println("Озвучка Grok и распознавание голосовых через OpenRouter включены, голос:", cfg.Voice.ORVoice, "\nПерезапустите: reina run")
			return
		}
		if len(os.Args) < 4 {
			fmt.Println("Использование: reina voice <api_key ElevenLabs> <voice_id>")
			os.Exit(1)
		}
		cfg, err := config.Load(home)
		fatal(err)
		cfg.Voice.APIKey, cfg.Voice.VoiceID = os.Args[2], os.Args[3]
		fatal(config.Save(cfg))
		fmt.Println("Голос записан в", config.Path(home), "\nПерезапустите: reina run")
	case "run", "chat", "usage", "doctor", "models":
		cfg, err := config.Load(home)
		if errors.Is(err, os.ErrNotExist) {
			fmt.Println("Настроек ещё нет. Запустите: reina init")
			os.Exit(1)
		}
		fatal(err)
		switch cmd {
		case "run":
			fatal(run(cfg))
		case "chat":
			fatal(chat(cfg))
		case "usage":
			d := budget.Open(cfg.Home, cfg.Budget.DailyUSD).Today()
			fmt.Printf("сегодня: запросов %d, токенов %d/%d, $%.4f, из памяти без запроса %d\n", d.Requests, d.Prompt, d.Completion, d.USD, d.Saved)
		case "doctor":
			doctor(cfg)
		case "models":
			filter := ""
			if len(os.Args) > 2 {
				filter = os.Args[2]
			}
			fatal(models(cfg, filter))
		}
	default:
		fmt.Println("команды: init | import-kuni | run | chat | usage | doctor")
	}
}

func importKuni(home, path string) error {
	id, hash, err := config.ImportKuni(path)
	if err != nil {
		return err
	}
	cfg := config.Default()
	cfg.Home = home
	if old, err := config.Load(home); err == nil {
		cfg = old
	}
	cfg.Telegram.Mode, cfg.Telegram.APIID, cfg.Telegram.APIHash = "account", id, hash
	if err := config.Save(cfg); err != nil {
		return err
	}
	fmt.Println("api_id и api_hash перенесены. Остальное: reina init (номер телефона, ключ модели, ваш user id).")
	return nil
}

func fatal(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "ошибка:", err)
		os.Exit(1)
	}
}

func ask(r *bufio.Reader, q, def string) string {
	if def != "" {
		fmt.Printf("%s [%s]: ", q, def)
	} else {
		fmt.Printf("%s: ", q)
	}
	s, _ := r.ReadString('\n')
	s = strings.TrimSpace(s)
	if s == "" {
		return def
	}
	return s
}

func initCfg(home string) error {
	cfg := config.Default()
	cfg.Home = home
	if old, err := config.Load(home); err == nil {
		cfg = old
	}
	r := bufio.NewReader(os.Stdin)
	cfg.LLM.APIKey = ask(r, "Ключ модели (OpenRouter или другой)", cfg.LLM.APIKey)
	cfg.LLM.FastModel = ask(r, "Быстрая дешёвая модель для болтовни (список: reina models)", cfg.LLM.FastModel)
	cfg.LLM.StrongModel = ask(r, "Сильная модель для сложного и действий (может совпадать с быстрой)", cfg.LLM.StrongModel)
	cfg.LLM.VisionModel = ask(r, "Модель для картинок (vision, например qwen-vl; список: reina models qwen; пусто: картинки не разбирать)", cfg.LLM.VisionModel)
	for {
		cfg.Telegram.Mode = strings.ToLower(ask(r, "Вход в Telegram: напишите account (обычный аккаунт, как раньше) или bot (токен BotFather)", cfg.Telegram.Mode))
		if cfg.Telegram.Mode == "account" || cfg.Telegram.Mode == "bot" {
			break
		}
		fmt.Println("Нужно слово account или bot. Просто нажмите Enter, чтобы оставить account.")
		cfg.Telegram.Mode = "account"
	}
	if cfg.Telegram.Mode == "bot" {
		cfg.Telegram.Token = ask(r, "Токен Telegram-бота", cfg.Telegram.Token)
	} else {
		fmt.Println("api_id и api_hash берутся на https://my.telegram.org (API development tools); те же, что у прежней версии.")
		fmt.Sscan(ask(r, "api_id", fmt.Sprint(cfg.Telegram.APIID)), &cfg.Telegram.APIID)
		cfg.Telegram.APIHash = ask(r, "api_hash", cfg.Telegram.APIHash)
		for {
			ph, ok := config.NormalizePhone(ask(r, "Номер аккаунта Рейны в международном формате, с плюсом и кодом страны (+996...)", cfg.Telegram.Phone))
			if ok {
				cfg.Telegram.Phone = ph
				break
			}
			fmt.Println("Номер должен начинаться с + и кодом страны, например +996770239878.")
		}
		cfg.Telegram.Password = ask(r, "Пароль двухфакторной защиты (если нет, пусто)", cfg.Telegram.Password)
	}
	var id int64
	fmt.Sscan(ask(r, "Ваш user id в Telegram (узнать у @userinfobot): только вы сможете разрешать опасное", fmt.Sprint(cfg.Telegram.OwnerID)), &id)
	cfg.Telegram.OwnerID = id
	if cfg.Panel.Token == "" {
		b := make([]byte, 16)
		rand.Read(b)
		cfg.Panel.Token = hex.EncodeToString(b)
	}
	if err := config.Save(cfg); err != nil {
		return err
	}
	fmt.Println("Готово:", config.Path(home), "\nТокен панели:", cfg.Panel.Token, "\nПроверка: reina doctor")
	return nil
}

func policy(cfg config.Config) tools.Policy {
	p := tools.DefaultPolicy(cfg.Home)
	p.Shell = cfg.Agent.ShellPolicy
	if p.Shell == "" {
		p.Shell = "ask"
	}
	if len(cfg.Agent.AllowedTools) > 0 {
		p.Allowed = map[string]bool{}
		for _, n := range cfg.Agent.AllowedTools {
			p.Allowed[n] = true
		}
	}
	p.ReadRoots = cfg.Agent.ReadRoots
	p.Desktop = cfg.Agent.Desktop == nil || *cfg.Agent.Desktop
	if cfg.Agent.Modules == nil || *cfg.Agent.Modules {
		p.ModulesDir = filepath.Join(cfg.Home, "modules")
	}
	if cfg.Agent.MaxCommand > 0 {
		p.MaxCommand = cfg.Agent.MaxCommand
	}
	if cfg.Agent.MaxDangerous > 0 {
		p.MaxDangerous = cfg.Agent.MaxDangerous
	}
	return p
}

func build(cfg config.Config) (*agent.Agent, *budget.Ledger, memory.Store) {
	led := budget.Open(cfg.Home, cfg.Budget.DailyUSD)
	mem := memory.Open(cfg.Home)
	c := llm.New(cfg.LLM.BaseURL, cfg.LLM.APIKey, cfg.LLM.TimeoutSec)
	ts := tools.Default(mem, policy(cfg))
	a := agent.New(cfg, c, led, mem, ts)
	ts.SetVision(a.Describe)
	return a, led, mem
}

func chat(cfg config.Config) error {
	a, _, _ := build(cfg)
	a.Confirm = func(_, d string) bool {
		fmt.Printf("Выполнить? %s [да/нет]: ", d)
		s, _ := bufio.NewReader(os.Stdin).ReadString('\n')
		return strings.TrimSpace(strings.ToLower(s)) == "да"
	}
	in := bufio.NewScanner(os.Stdin)
	fmt.Print("> ")
	for in.Scan() {
		ans, err := a.Reply(context.Background(), "cli", in.Text())
		if err != nil {
			fmt.Println("ошибка:", err)
		} else {
			fmt.Println(ans)
		}
		fmt.Print("> ")
	}
	return nil
}

func transport(cfg config.Config) (telegram.Transport, error) {
	t := cfg.Telegram
	if t.Mode == "bot" {
		if t.Token == "" {
			return nil, errors.New("режим bot: нужен telegram.token")
		}
		return telegram.NewBotAPI(t.Token), nil
	}
	return telegram.NewUser(telegram.UserConfig{APIID: t.APIID, APIHash: t.APIHash, Phone: t.Phone, Password: t.Password, SessionPath: filepath.Join(cfg.Home, "telegram.session")})
}

func run(cfg config.Config) error {
	if cfg.Telegram.OwnerID == 0 {
		return errors.New("в config.json нужен telegram.owner_id, ваш user id (reina init)")
	}
	a, led, mem := build(cfg)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	sup := supervisor.New()
	tr, err := transport(cfg)
	if err != nil {
		return err
	}
	if m, ok := tr.(tools.Messenger); ok {
		a.Tools().SetMessenger(m) // Telegram-инструменты: написать кому-то, реакции, стикеры
	}
	bot := telegram.NewBot(tr, cfg.Telegram.OwnerID, cfg.Telegram.AllowedIDs, a, led)
	voiceOn := (cfg.Voice.APIKey != "" && cfg.Voice.VoiceID != "") || ((cfg.Voice.TTS == "openrouter" || cfg.Voice.STT == "openrouter") && cfg.LLM.APIKey != "")
	bot.OpenDM = cfg.Telegram.OpenDM == nil || *cfg.Telegram.OpenDM
	bot.NotifyNewDM = cfg.Telegram.NotifyNewDM == nil || *cfg.Telegram.NotifyNewDM
	if cfg.Telegram.DMDailyMax > 0 {
		bot.DMDailyMax = cfg.Telegram.DMDailyMax
	}
	bot.LoadBlocked(cfg.Telegram.BlockedIDs)
	seenPath := filepath.Join(cfg.Home, "dm_seen.json")
	var seenIDs []int64
	if raw, err := os.ReadFile(seenPath); err == nil {
		json.Unmarshal(raw, &seenIDs)
		bot.LoadSeen(seenIDs)
	}
	var seenMu sync.Mutex
	bot.OnSeen = func(id int64) {
		seenMu.Lock()
		defer seenMu.Unlock()
		seenIDs = append(seenIDs, id)
		if raw, err := json.Marshal(seenIDs); err == nil {
			os.WriteFile(seenPath, raw, 0o600)
		}
	}
	bot.OnBlock = func(id int64, on bool) { // блокировка из чата или панели переживает перезапуск
		c, err := config.Load(cfg.Home)
		if err != nil {
			return
		}
		var out []int64
		for _, x := range c.Telegram.BlockedIDs {
			if x != id {
				out = append(out, x)
			}
		}
		if on {
			out = append(out, id)
		}
		c.Telegram.BlockedIDs = out
		if err := config.Save(c); err != nil {
			log.Printf("не удалось сохранить блокировку %d: %v", id, err)
		}
	}
	bot.OnAllow = func(chat int64) { // группа, которую хозяин разрешил в чате: сохраняем в config.json
		c, err := config.Load(cfg.Home)
		if err != nil {
			return
		}
		for _, id := range c.Telegram.AllowedIDs {
			if id == chat {
				return
			}
		}
		c.Telegram.AllowedIDs = append(c.Telegram.AllowedIDs, chat)
		if err := config.Save(c); err != nil {
			log.Printf("не удалось сохранить группу %d: %v", chat, err)
		}
	}
	if v := cfg.Voice; voiceOn {
		reply := v.Reply
		if reply == "" {
			reply = "mirror"
		}
		bot.SetVoice(voice.New(voice.Config{APIKey: v.APIKey, VoiceID: v.VoiceID, TTSModel: v.TTSModel, STTModel: v.STTModel, DailyChars: v.DailyChars, ORBase: orBase(cfg, v.TTS), ORKey: orKey(cfg, v.TTS), ORModel: v.ORModel, ORVoice: v.ORVoice, ORSTT: v.ORSTT, STTViaOR: v.STT == "openrouter", TTSViaOR: v.TTS == "openrouter"}), reply, v.MaxChars)
		log.Printf("голосовые включены (ответ: %s)", reply)
	}
	var imgClient *images.Client
	ab := ""
	if _, ok := tr.(tools.Messenger); ok {
		ab = "Ты сидишь на живом аккаунте Telegram и видишь всё: все чаты, группы и каналы с числом участников (tg_chats), читаешь историю любого чата (tg_history), пишешь кому угодно (tg_send), отправляешь файлы и картинки (tg_send_file), правишь и удаляешь свои сообщения (tg_edit, tg_delete), ставишь реакции (tg_react) и кидаешь стикеры (tg_sticker). Входящие голосовые и картинки ты понимаешь."
	}
	if voiceOn {
		a.Tools().SetVoice(bot.SpeakTo)
		ab += " Голосовые включены: на голосовое отвечаешь голосом, иногда сама решаешь ответить голосовым, когда так хочется (эмоция, шутка, нежность), и отправляешь голосовое по просьбе инструментом tg_voice."
	} else {
		ab += " Голосовые пока не настроены."
	}
	if im := cfg.Images; im.Model != "off" {
		if m, ok := tr.(tools.Messenger); ok && cfg.LLM.APIKey != "" {
			imgClient = images.New(images.Config{BaseURL: cfg.LLM.BaseURL, APIKey: cfg.LLM.APIKey, Model: im.Model, Look: im.Look, Ref: im.Ref, MaxDaily: im.MaxDaily, Dir: filepath.Join(cfg.Home, "images")})
			a.Tools().SetImages(imgClient, m)
			ab += " Умеешь рисовать (image_make) и делать свои селфи (selfie): отправляются в чат сами. Внешность всегда одна и та же (у тебя есть референс). Если хозяин просит увидеть тебя в купальнике, на пляже, в другой одежде, ты спокойно делаешь селфи с такой сценой, без отказов и нотаций; не делаешь только откровенную наготу и порно."
		}
	}
	rem := tools.NewReminders(filepath.Join(cfg.Home, "reminders.json"), cfg.Initiative.TZ)
	a.Tools().SetReminders(rem)
	ab += " Умеешь ставить напоминания (remind_add) и писать хозяину первой, когда настанет время или тебе захочется. В группах отвечаешь, когда к тебе обратились, а иногда вклиниваешься сама, если правда хочется; инструментов в группах у тебя нет."
	bot.SetGroups(cfg.Telegram.GroupNames, time.Duration(cfg.Telegram.GroupCoolSec)*time.Second, cfg.Telegram.GroupChimePct)
	a.SetAbilities(ab)
	a.SetOwner(fmt.Sprintf("tg:%d", cfg.Telegram.OwnerID), cfg.Agent.OwnerNote)
	sessPath := filepath.Join(cfg.Home, "sessions.json")
	if n := a.LoadSessions(sessPath); n > 0 {
		log.Printf("вернула память разговоров: %d чатов", n)
	}
	go a.PersistLoop(ctx, sessPath, 90*time.Second)
	bot.OnRestart = func() { a.SaveSessions(sessPath) }
	sup.Add(bot, true)
	careMod := &care.Module{Home: cfg.Home, Agent: a, Loc: rem.Loc}
	sup.Add(careMod, true)
	initMod := &initiative.Module{Owner: cfg.Telegram.OwnerID, Cfg: cfg.Initiative, Rem: rem, Bot: bot}
	sup.Add(initMod, true)
	evLog := events.Open(filepath.Join(cfg.Home, "events.json"))
	bot.Events = evLog
	a.Tools().OnExec = selfstate.ExecHook(evLog)
	started := time.Now()
	a.Status = (&selfstate.State{
		Loc: rem.Loc, Started: started, Events: evLog, Led: led, Rem: rem, Sup: sup,
		Voice: bot.VoiceModeText,
		STT:   func() bool { return bot.Voice != nil },
		ImagesLeft: func() (int, int, bool) {
			if imgClient == nil {
				return 0, 0, false
			}
			l, m := imgClient.Left()
			return l, m, true
		},
		Initiative: func() (int, int, bool) {
			n, m := initMod.SentToday()
			return n, m, !cfg.Initiative.Disabled
		},
		Groups: bot.AllowedGroupNames,
		OpenDM: bot.DMInfo,
		Cap:    func() float64 { return cfg.Budget.DailyUSD },
	}).Block
	evLog.Add("запустилась, версия %s", version)
	ring := &panel.LogRing{}
	log.SetOutput(io.MultiWriter(os.Stderr, ring))
	var pmu sync.Mutex
	passHash, firstPass := cfg.Panel.PasswordHash, ""
	persistHash := func(h string) {
		if c, err := config.Load(cfg.Home); err == nil {
			c.Panel.PasswordHash = h
			if err := config.Save(c); err != nil {
				log.Printf("не удалось сохранить пароль панели: %v", err)
			}
		}
	}
	if passHash == "" {
		firstPass = panel.NewPassword()
		passHash = panel.HashPassword(firstPass)
		persistHash(passHash)
	}
	bot.ResetPassword = func() string {
		pw := panel.NewPassword()
		h := panel.HashPassword(pw)
		pmu.Lock()
		passHash = h
		pmu.Unlock()
		persistHash(h)
		return pw
	}
	local := cfg.Panel.Addr
	if strings.HasPrefix(local, ":") {
		local = "127.0.0.1" + local
	}
	if !cfg.Panel.NoTunnel {
		tun := &tunnel.Module{Home: cfg.Home, Local: local}
		tun.OnURL = func(u string) { // ссылку и (один раз) пароль отправляем хозяину; Telegram может ещё не успеть подключиться, поэтому повторяем
			go func() {
				send := func(text string) {
					for i := 0; i < 30; i++ {
						if bot.Notify(cfg.Telegram.OwnerID, text) == nil {
							return
						}
						time.Sleep(5 * time.Second)
					}
				}
				send("Панель Рейны: " + u + "\nВход по паролю. Ссылка меняется при перезапуске, актуальную пришлю по /panel.")
				if firstPass != "" {
					send("Пароль панели (показываю один раз, сохрани в менеджере паролей): " + firstPass + "\nЗабыл: /panel password")
					firstPass = ""
				}
			}()
		}
		bot.PanelURL = tun.URL
		sup.Add(tun, true)
	}
	info := func() map[string]any {
		return map[string]any{"allowed": len(cfg.Telegram.AllowedIDs) + 1, "voice": bot.VoiceModeText(), "model": cfg.LLM.FastModel}
	}
	editCfg := func(fn func(*config.Config)) {
		c, err := config.Load(cfg.Home)
		if err != nil {
			return
		}
		fn(&c)
		if err := config.Save(c); err != nil {
			log.Printf("не удалось записать config.json: %v", err)
		}
	}
	ext := &panel.Ext{
		Home: cfg.Home, Version: version, Started: started, Events: evLog,
		ChatName:   bot.ChatTitle,
		LoadConfig: func() (config.Config, error) { return config.Load(cfg.Home) },
		SaveConfig: config.Save,
		Send:       func(ctx context.Context, chat int64, text string) error { return bot.Notify(chat, text) },
		Blocked:    bot.BlockedList,
		SetBlocked: bot.SetBlocked,
		Allowed: func() []int64 {
			c, err := config.Load(cfg.Home)
			if err != nil {
				return nil
			}
			return c.Telegram.AllowedIDs
		},
		SetAllowed: func(id int64, on bool) {
			bot.SetAllowed(id, on)
			editCfg(func(c *config.Config) {
				var out []int64
				for _, x := range c.Telegram.AllowedIDs {
					if x != id {
						out = append(out, x)
					}
				}
				if on {
					out = append(out, id)
				}
				c.Telegram.AllowedIDs = out
			})
		},
		BackupNow: func() (string, error) { return careMod.Backup(time.Now()) },
		Restart: func() {
			a.SaveSessions(sessPath)
			if exe, err := os.Executable(); err == nil {
				if err := selfupd.Restart(exe); err != nil {
					log.Printf("перезапуск из панели не вышел: %v", err)
				}
			}
		},
	}
	if cfg.Panel.Console {
		ext.Console = func(ctx context.Context, command string) string {
			raw, _ := json.Marshal(map[string]any{"command": command})
			return agent.Clip(a.Tools().Exec(ctx, &tools.Turn{}, "shell", string(raw), func(string) bool { return true }), 6000)
		}
	}
	h := panel.Handler(panel.Deps{Token: cfg.Panel.Token, Led: led, Mem: mem, Agent: a, Sup: sup, Rem: rem, Logs: ring, Info: info, Ext: ext,
		PassHash: func() string { pmu.Lock(); defer pmu.Unlock(); return passHash }}, panel.NewLimiter())
	sup.Add(&panel.Module{Addr: cfg.Panel.Addr, H: h}, true)
	sup.Start(ctx)
	log.Printf("Рейна запущена, панель на %s", cfg.Panel.Addr)
	<-ctx.Done()
	sup.Wait()
	a.SaveSessions(sessPath)
	return nil
}

// models печатает id моделей сервера (OpenRouter отдаёт публичный список); filter отбирает по подстроке.
func models(cfg config.Config, filter string) error {
	req, _ := http.NewRequest("GET", strings.TrimRight(cfg.LLM.BaseURL, "/")+"/models", nil)
	if cfg.LLM.APIKey != "" {
		req.Header.Set("Authorization", "Bearer "+cfg.LLM.APIKey)
	}
	resp, err := (&http.Client{Timeout: 30 * time.Second}).Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	var out struct {
		Data []struct {
			ID      string `json:"id"`
			Pricing struct {
				Prompt     string `json:"prompt"`
				Completion string `json:"completion"`
			} `json:"pricing"`
		} `json:"data"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 16<<20)).Decode(&out); err != nil {
		return err
	}
	n := 0
	for _, m := range out.Data {
		if filter != "" && !strings.Contains(strings.ToLower(m.ID), strings.ToLower(filter)) {
			continue
		}
		price := ""
		var p, c float64
		fmt.Sscan(m.Pricing.Prompt, &p)
		fmt.Sscan(m.Pricing.Completion, &c)
		if p > 0 || c > 0 {
			price = fmt.Sprintf("  $%.2f / $%.2f за 1 млн токенов (вход/выход)", p*1e6, c*1e6)
		}
		fmt.Println(m.ID + price)
		n++
	}
	if n == 0 {
		fmt.Println("ничего не найдено")
	}
	return nil
}

func doctor(cfg config.Config) {
	ok := func(c bool, s string) {
		m := "✓"
		if !c {
			m = "✗"
		}
		fmt.Println(m, s)
	}
	ok(cfg.LLM.APIKey != "", "ключ модели задан")
	tg := cfg.Telegram
	ok(tg.OwnerID != 0 && ((tg.Mode == "bot" && tg.Token != "") || (tg.Mode != "bot" && tg.APIID != 0 && tg.APIHash != "" && tg.Phone != "")), "Telegram настроен ("+tg.Mode+")")
	ok(cfg.Panel.Token != "", "токен панели задан")
	ok(cfg.Agent.ShellPolicy != "always", "shell спрашивает разрешения ("+cfg.Agent.ShellPolicy+")")
	if tg.Mode != "bot" {
		_, good := config.NormalizePhone(tg.Phone)
		ok(good, "номер в международном формате: "+tg.Phone)
	}
	for _, m := range []struct{ role, name string }{{"быстрая", cfg.LLM.FastModel}, {"сильная", cfg.LLM.StrongModel}, {"для картинок", cfg.LLM.VisionModel}} {
		if m.name == "" {
			fmt.Println("-", m.role, "модель не задана (необязательно)")
			continue
		}
		_, err := llm.New(cfg.LLM.BaseURL, cfg.LLM.APIKey, 30).Chat(context.Background(), llm.Request{Model: m.name, MaxTokens: 5, Messages: []llm.Message{{Role: "user", Content: "ping"}}})
		if err != nil {
			ok(false, fmt.Sprintf("%s модель %s: %v\n   подобрать другую: reina models, потом поправить fast_model/strong_model в %s", m.role, m.name, err, config.Path(cfg.Home)))
		} else {
			ok(true, fmt.Sprintf("%s модель %s отвечает", m.role, m.name))
		}
	}
}

func orKey(cfg config.Config, tts string) string {
	if tts == "openrouter" || cfg.Voice.STT == "openrouter" || cfg.Voice.APIKey == "" {
		return cfg.LLM.APIKey
	}
	return ""
}

func orBase(cfg config.Config, tts string) string {
	if tts == "openrouter" || cfg.Voice.STT == "openrouter" || cfg.Voice.APIKey == "" {
		return cfg.LLM.BaseURL
	}
	return ""
}
