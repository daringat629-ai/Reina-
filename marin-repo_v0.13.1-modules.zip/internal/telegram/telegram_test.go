package telegram

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"reina/internal/agent"
	"reina/internal/budget"
	"reina/internal/config"
	"reina/internal/llm"
	"reina/internal/memory"
	"reina/internal/tools"
	"reina/internal/voice"
)

type model struct{ step int }

func (m *model) Chat(_ context.Context, r llm.Request) (llm.Response, error) {
	m.step++
	last := r.Messages[len(r.Messages)-1]
	if last.Role == "user" && strings.Contains(last.Content, "выполни") && m.step < 3 {
		var tc llm.ToolCall
		tc.ID, tc.Type = "c", "function"
		tc.Function.Name, tc.Function.Arguments = "shell", `{"command":"echo ok123"}`
		return llm.Response{Message: llm.Message{Role: "assistant", ToolCalls: []llm.ToolCall{tc}}}, nil
	}
	return llm.Response{Message: llm.Message{Role: "assistant", Content: "готово: " + last.Content}}, nil
}

func newBot(t *testing.T) (*Bot, *[]string, func() []string) {
	var mu sync.Mutex
	var sent []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/sendMessage") {
			var p map[string]any
			json.NewDecoder(r.Body).Decode(&p)
			mu.Lock()
			sent = append(sent, p["text"].(string))
			mu.Unlock()
		}
		w.Write([]byte(`{"ok":true,"result":[]}`))
	}))
	t.Cleanup(srv.Close)
	cfg := config.Default()
	off := false
	cfg.Agent.Think, cfg.Agent.HumanDelay = &off, &off
	cfg.Home = t.TempDir()
	led := budget.Open(cfg.Home, 0)
	mem := memory.Open(cfg.Home)
	a := agent.New(cfg, &model{}, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	tr := NewBotAPI("tok")
	tr.API = srv.URL
	b := NewBot(tr, 42, []int64{77}, a, led)
	get := func() []string { mu.Lock(); defer mu.Unlock(); return append([]string(nil), sent...) }
	return b, &sent, get
}

func waitFor(t *testing.T, get func() []string, n int) []string {
	for i := 0; i < 200; i++ {
		if s := get(); len(s) >= n {
			return s
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("ждали %d сообщений, пришло %v", n, get())
	return nil
}

func TestOnlyTheOwnerGetsAnswers(t *testing.T) {
	b, _, get := newBot(t)
	b.Handle(context.Background(), 999, "привет")
	time.Sleep(100 * time.Millisecond)
	if len(get()) != 0 {
		t.Fatal("чужому ответили")
	}
	b.Handle(context.Background(), 42, "привет")
	if s := waitFor(t, get, 1); !strings.Contains(s[0], "готово: привет") {
		t.Fatal(s)
	}
}

func TestDangerousActionWaitsForYesAndRunsAfterIt(t *testing.T) {
	b, _, get := newBot(t)
	b.Handle(context.Background(), 42, "выполни команду")
	s := waitFor(t, get, 1)
	if !strings.Contains(s[0], "Выполнить?") {
		t.Fatalf("не спросила: %v", s)
	}
	b.Handle(context.Background(), 42, "да")
	s = waitFor(t, get, 2)
	if !strings.Contains(s[1], "ok123") {
		t.Fatalf("команда не выполнилась после «да»: %v", s)
	}
}

func TestUsageCommandAndAPanicDoesNotKillTheBot(t *testing.T) {
	b, _, get := newBot(t)
	b.Handle(context.Background(), 42, "/usage")
	if s := waitFor(t, get, 1); !strings.Contains(s[0], "Сегодня") {
		t.Fatal(s)
	}
	b.Agent = nil // следующий ответ упадёт с паникой
	b.Handle(context.Background(), 42, "привет")
	s := waitFor(t, get, 2)
	if !strings.Contains(s[1], "я жива") {
		t.Fatalf("после паники нет ответа: %v", s)
	}
	time.Sleep(50 * time.Millisecond)
	b.mu.Lock()
	busy := b.busy[42]
	b.mu.Unlock()
	if busy {
		t.Fatal("бот остался занятым после паники")
	}
}

// fakeTransport проверяет логику бота независимо от способа входа (бот или аккаунт).
type fakeTransport struct {
	mu   sync.Mutex
	sent map[int64][]string
	in   func(Incoming)
	up   chan struct{}
}

func (f *fakeTransport) Run(ctx context.Context, in func(Incoming)) error {
	f.in = in
	close(f.up)
	<-ctx.Done()
	return nil
}
func (f *fakeTransport) Send(chat int64, text string) error {
	f.mu.Lock()
	f.sent[chat] = append(f.sent[chat], text)
	f.mu.Unlock()
	return nil
}
func (f *fakeTransport) Health() error { return nil }
func (f *fakeTransport) got(chat int64) []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]string(nil), f.sent[chat]...)
}

func accountBot(t *testing.T) (*Bot, *fakeTransport, context.CancelFunc) {
	cfg := config.Default()
	off := false
	cfg.Agent.Think, cfg.Agent.HumanDelay = &off, &off
	cfg.Home = t.TempDir()
	led := budget.Open(cfg.Home, 0)
	mem := memory.Open(cfg.Home)
	a := agent.New(cfg, &model{}, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	ft := &fakeTransport{sent: map[int64][]string{}, up: make(chan struct{})}
	b := NewBot(ft, 42, []int64{77}, a, led)
	ctx, cancel := context.WithCancel(context.Background())
	go b.Run(ctx)
	<-ft.up
	return b, ft, cancel
}

func waitSent(t *testing.T, ft *fakeTransport, chat int64, n int) []string {
	for i := 0; i < 300; i++ {
		if s := ft.got(chat); len(s) >= n {
			return s
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("ждали %d сообщений для %d, пришло %v", n, chat, ft.got(chat))
	return nil
}

func TestAccountTransportAllowlistAndPerChatSessions(t *testing.T) {
	_, ft, cancel := accountBot(t)
	defer cancel()
	ft.in(Incoming{Chat: 999, Text: "привет"}) // чужой: молчим
	ft.in(Incoming{Chat: 77, Text: "привет от второго"})
	if s := waitSent(t, ft, 77, 1); !strings.Contains(s[0], "готово: привет от второго") {
		t.Fatal(s)
	}
	time.Sleep(50 * time.Millisecond)
	if len(ft.got(999)) != 0 || len(ft.got(42)) != 0 {
		t.Fatal("ответ ушёл не туда")
	}
}

func TestOnlyTheOwnerCanApproveADangerousActionNotAnAllowedGuest(t *testing.T) {
	_, ft, cancel := accountBot(t)
	defer cancel()
	ft.in(Incoming{Chat: 42, Text: "выполни команду"})
	if s := waitSent(t, ft, 42, 1); !strings.Contains(s[0], "Выполнить?") {
		t.Fatal(s)
	}
	ft.in(Incoming{Chat: 77, Text: "да"}) // гость отвечает «да»: это обычное сообщение, не разрешение
	time.Sleep(100 * time.Millisecond)
	if n := len(ft.got(42)); n != 1 {
		t.Fatalf("гость разрешил опасное действие: %q", ft.got(42))
	}
	ft.in(Incoming{Chat: 42, Text: "да"})
	if s := waitSent(t, ft, 42, 2); !strings.Contains(s[1], "ok123") {
		t.Fatal(s)
	}
}

func TestUserTransportStubSaysHowToBuild(t *testing.T) {
	if _, err := NewUser(UserConfig{}); err == nil {
		t.Fatal("пустые настройки аккаунта должны давать понятную ошибку")
	}
}

type visionModel struct {
	mu   sync.Mutex
	reqs []llm.Request
}

func (v *visionModel) Chat(_ context.Context, r llm.Request) (llm.Response, error) {
	v.mu.Lock()
	v.reqs = append(v.reqs, r)
	v.mu.Unlock()
	return llm.Response{Message: llm.Message{Role: "assistant", Content: "вижу кота"}}, nil
}

func TestPhotoIsDownloadedAndAnsweredByTheVisionModel(t *testing.T) {
	var mu sync.Mutex
	var sent []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/getFile"):
			w.Write([]byte(`{"ok":true,"result":{"file_path":"photos/a.jpg"}}`))
		case strings.Contains(r.URL.Path, "/file/bot"):
			w.Write([]byte("JPEGBYTES"))
		case strings.HasSuffix(r.URL.Path, "/sendMessage"):
			var p map[string]any
			json.NewDecoder(r.Body).Decode(&p)
			mu.Lock()
			sent = append(sent, p["text"].(string))
			mu.Unlock()
			w.Write([]byte(`{"ok":true}`))
		default:
			w.Write([]byte(`{"ok":true,"result":[]}`))
		}
	}))
	defer srv.Close()
	cfg := config.Default()
	off := false
	cfg.Agent.Think, cfg.Agent.HumanDelay = &off, &off
	cfg.Home = t.TempDir()
	cfg.LLM.VisionModel = "vision"
	led := budget.Open(cfg.Home, 0)
	mem := memory.Open(cfg.Home)
	vm := &visionModel{}
	a := agent.New(cfg, vm, led, mem, tools.Default(mem, tools.DefaultPolicy(cfg.Home)))
	tr := NewBotAPI("tok")
	tr.API = srv.URL
	img, err := tr.download(context.Background(), "FILEID")
	if err != nil || string(img) != "JPEGBYTES" {
		t.Fatalf("скачивание: %q %v", img, err)
	}
	b := NewBot(tr, 42, nil, a, led)
	b.HandleIncoming(context.Background(), Incoming{Chat: 42, Text: "что это?", Image: img, Mime: "image/jpeg"})
	for i := 0; i < 200; i++ {
		mu.Lock()
		n := len(sent)
		mu.Unlock()
		if n > 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	mu.Lock()
	defer mu.Unlock()
	if len(sent) != 1 || sent[0] != "вижу кота" {
		t.Fatalf("ответ: %v", sent)
	}
	last := vm.reqs[0].Messages[len(vm.reqs[0].Messages)-1]
	if vm.reqs[0].Model != "vision" || len(last.Images) != 1 || !strings.HasPrefix(last.Images[0], "data:image/jpeg;base64,") {
		t.Fatalf("в модель ушло не то: %+v", vm.reqs[0].Model)
	}
}

// readerTransport: транспорт, который умеет «прочитано» и «печатает…».
type readerTransport struct {
	*fakeTransport
	mu     sync.Mutex
	reads  []int
	typing int
}

func (r *readerTransport) MarkRead(chat int64, msgID int) {
	r.mu.Lock()
	r.reads = append(r.reads, msgID)
	r.mu.Unlock()
}
func (r *readerTransport) Typing(chat int64) { r.mu.Lock(); r.typing++; r.mu.Unlock() }

func TestReadReceiptAndTypingOnlyForAllowedChats(t *testing.T) {
	b, ft, cancel := accountBot(t)
	defer cancel()
	rt := &readerTransport{fakeTransport: ft}
	b.tr = rt
	b.HandleIncoming(context.Background(), Incoming{Chat: 999, Text: "привет", MsgID: 5}) // чужой: ни галочек, ни ответа
	b.HandleIncoming(context.Background(), Incoming{Chat: b.OwnerID, Text: "привет", MsgID: 7})
	waitSent(t, ft, b.OwnerID, 1)
	time.Sleep(50 * time.Millisecond)
	rt.mu.Lock()
	defer rt.mu.Unlock()
	if len(rt.reads) != 1 || rt.reads[0] != 7 {
		t.Fatalf("прочитанным должно стать только сообщение владельца: %v", rt.reads)
	}
	if rt.typing != 1 {
		t.Fatalf("«печатает» должно быть один раз, а их %d", rt.typing)
	}
}

// voiceTransport: транспорт с отправкой голосовых.
type voiceTransport struct {
	*fakeTransport
	mu     sync.Mutex
	voices [][]byte
	fail   bool
}

func (v *voiceTransport) SendVoice(_ context.Context, _ int64, a []byte, _ string, _ int) error {
	v.mu.Lock()
	defer v.mu.Unlock()
	if v.fail {
		return context.DeadlineExceeded
	}
	v.voices = append(v.voices, a)
	return nil
}

func eleven(t *testing.T) *voice.Client {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/speech-to-text") {
			w.Write([]byte(`{"text":"как дела"}`))
			return
		}
		w.Write([]byte("OPUS"))
	}))
	t.Cleanup(srv.Close)
	c := voice.New(voice.Config{APIKey: "k", VoiceID: "v"})
	c.BaseURL = srv.URL
	return c
}

func TestVoiceInVoiceOutAndTextFallback(t *testing.T) {
	b, ft, cancel := accountBot(t)
	defer cancel()
	vt := &voiceTransport{fakeTransport: ft}
	b.tr = vt
	b.SetVoice(eleven(t), "mirror", 600)
	b.HandleIncoming(context.Background(), Incoming{Chat: b.OwnerID, Voice: []byte("ogg"), VoiceMime: "audio/ogg", MsgID: 1})
	for i := 0; i < 300 && func() bool { vt.mu.Lock(); defer vt.mu.Unlock(); return len(vt.voices) == 0 }(); i++ {
		time.Sleep(10 * time.Millisecond)
	}
	vt.mu.Lock()
	if len(vt.voices) != 1 || string(vt.voices[0]) != "OPUS" || len(ft.got(b.OwnerID)) != 0 {
		t.Fatalf("на голосовое должен прийти голос, без текста: %d %v", len(vt.voices), ft.got(b.OwnerID))
	}
	vt.fail = true
	vt.mu.Unlock()
	time.Sleep(50 * time.Millisecond)
	b.HandleIncoming(context.Background(), Incoming{Chat: b.OwnerID, Voice: []byte("ogg"), MsgID: 2})
	got := waitSent(t, ft, b.OwnerID, 1)
	if !strings.Contains(got[0], "[голосовое сообщение] как дела") {
		t.Fatalf("при сбое отправки ответ идёт текстом, и модель видела расшифровку: %v", got)
	}
}

func TestTextMessageGetsTextAndVoiceWithoutSetupIsExplained(t *testing.T) {
	b, ft, cancel := accountBot(t)
	defer cancel()
	vt := &voiceTransport{fakeTransport: ft}
	b.tr = vt
	b.HandleIncoming(context.Background(), Incoming{Chat: b.OwnerID, Voice: []byte("ogg"), MsgID: 1})
	got := waitSent(t, ft, b.OwnerID, 1)
	if !strings.Contains(got[0], "reina voice") {
		t.Fatalf("без настройки нужно объяснить, что делать: %v", got)
	}
	b.SetVoice(eleven(t), "mirror", 600)
	b.HandleIncoming(context.Background(), Incoming{Chat: b.OwnerID, Text: "привет", MsgID: 3})
	got = waitSent(t, ft, b.OwnerID, 2)
	vt.mu.Lock()
	defer vt.mu.Unlock()
	if len(vt.voices) != 0 || !strings.Contains(got[1], "привет") {
		t.Fatalf("на текст в режиме mirror отвечаем текстом: %v %d", got, len(vt.voices))
	}
}
