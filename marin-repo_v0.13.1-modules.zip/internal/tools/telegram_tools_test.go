package tools

import (
	"context"
	"fmt"
	"strings"
	"testing"

	"reina/internal/memory"
)

type fakeMsgr struct{ log []string }

func (f *fakeMsgr) SendText(_ context.Context, t, x string) error {
	f.log = append(f.log, "send:"+t+":"+x)
	return nil
}
func (f *fakeMsgr) Chats(_ context.Context, q string, _ int) (string, error) {
	return "42 | Аня | @anya\n", nil
}
func (f *fakeMsgr) React(_ context.Context, c int64, id int, e string) error {
	f.log = append(f.log, fmt.Sprintf("react:%d:%d:%s", c, id, e))
	return nil
}
func (f *fakeMsgr) SendSticker(_ context.Context, c int64, e string) error {
	f.log = append(f.log, fmt.Sprintf("sticker:%d:%s", c, e))
	return nil
}
func (f *fakeMsgr) StickerEmojis(context.Context) (string, error) { return "😏×2 ❤×1", nil }

func msgrSet(t *testing.T) (*Set, *fakeMsgr) {
	t.Helper()
	s, _ := deskSet(t)
	s.Policy.Shell = "always"
	f := &fakeMsgr{}
	s.SetMessenger(f)
	s.SetMessenger(f) // повторный вызов не дублирует инструменты
	return s, f
}

func TestTelegramToolsListedOnceAndOnlyWithMessenger(t *testing.T) {
	s, _ := msgrSet(t)
	n := 0
	for _, d := range s.Defs() {
		if d.Function.Name == "tg_send" {
			n++
		}
	}
	if n != 1 {
		t.Fatalf("tg_send должен быть один раз, а их %d", n)
	}
	p := DefaultPolicy("x")
	for _, d := range Default(memory.Open(t.TempDir()), p).Defs() {
		if strings.HasPrefix(d.Function.Name, "tg_") {
			t.Fatalf("без транспорта нет %s", d.Function.Name)
		}
	}
}

func TestReactAndStickerUseTheCurrentChat(t *testing.T) {
	s, f := msgrSet(t)
	ctx := WithChat(context.Background(), 777, 55)
	if r := s.Exec(ctx, &Turn{}, "tg_react", `{"emoji":"👍"}`, nil); !strings.Contains(r, "поставила") {
		t.Fatal(r)
	}
	if r := s.Exec(ctx, &Turn{}, "tg_sticker", `{"emoji":"😏"}`, nil); !strings.Contains(r, "отправлен") {
		t.Fatal(r)
	}
	if got := strings.Join(f.log, ","); got != "react:777:55:👍,sticker:777:😏" {
		t.Fatalf("не то: %s", got)
	}
	if r := s.Exec(context.Background(), &Turn{}, "tg_sticker", `{"emoji":"😏"}`, nil); !strings.Contains(r, "нет чата") {
		t.Errorf("вне чата стикер не должен уйти: %s", r)
	}
}

func TestSendToOthersNeedsOwnerApproval(t *testing.T) {
	s, f := msgrSet(t)
	s.Policy.Shell = "ask"
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"@anya","text":"привет"}`, nil); !strings.Contains(r, "владелец не разрешил") || len(f.log) != 0 {
		t.Fatalf("без разрешения писать другим нельзя: %s %v", r, f.log)
	}
	asked := ""
	ok := func(d string) bool { asked = d; return true }
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"@anya","text":"привет"}`, ok); r != "отправила" || !strings.Contains(asked, "@anya") {
		t.Fatalf("с разрешением должно уйти: %s / %s", r, asked)
	}
	if r := s.Exec(context.Background(), &Turn{}, "tg_send", `{"chat":"","text":"x"}`, ok); !strings.Contains(r, "ошибка") {
		t.Errorf("пустой адресат: %s", r)
	}
}
