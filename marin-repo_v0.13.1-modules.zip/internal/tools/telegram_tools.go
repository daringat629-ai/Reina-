package tools

// Инструменты Telegram (как у прежней Куни): написать кому-то, найти чат, поставить реакцию, отправить стикер.
// Сама работа с Telegram живёт в транспорте (интерфейс Messenger), здесь только описания для модели и проверки аргументов.

import (
	"context"
	"fmt"
	"strings"
)

// Messenger: что умеет транспорт «аккаунт».
type Messenger interface {
	SendText(ctx context.Context, target, text string) error            // target: числовой id, @username или часть имени
	Chats(ctx context.Context, query string, limit int) (string, error) // «id | имя | @username» по строке, по одной на строку
	React(ctx context.Context, chat int64, msgID int, emoji string) error
	SendSticker(ctx context.Context, chat int64, emoji string) error
	StickerEmojis(ctx context.Context) (string, error)
}

type chatKey struct{}
type chatInfo struct {
	chat  int64
	msgID int
}

// WithChat запоминает в контексте, в каком чате идёт разговор и какое сообщение пришло последним (для реакций и стикеров).
func WithChat(ctx context.Context, chat int64, msgID int) context.Context {
	return context.WithValue(ctx, chatKey{}, chatInfo{chat, msgID})
}

func currentChat(ctx context.Context) (chatInfo, bool) {
	c, ok := ctx.Value(chatKey{}).(chatInfo)
	return c, ok && c.chat != 0
}

// SetMessenger подключает инструменты Telegram (вызывается один раз, когда транспорт умеет больше, чем «отправить текст»).
func (s *Set) SetMessenger(m Messenger) {
	for _, t := range s.list {
		if t.Name == "tg_send" {
			return
		}
	}
	intp := map[string]any{"type": "integer"}
	s.list = append(s.list,
		Tool{Name: "tg_chats", Desc: "Найти личные чаты Telegram по имени или @username (id, имя). Без query: последние", Params: obj(map[string]any{"query": str("часть имени или @username (можно пусто)")}),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				out, err := m.Chats(ctx, argStr(a, "query"), 15)
				if err == nil && strings.TrimSpace(out) == "" {
					return "ничего не найдено", nil
				}
				return out, err
			}},
		Tool{Name: "tg_send", Desc: "Написать сообщение в Telegram другому человеку: chat = id, @username или часть имени. Для ответа собеседнику в этом чате не нужен", Dangerous: true,
			Params: obj(map[string]any{"chat": str("id, @username или имя"), "text": str("текст до 1000 символов")}, "chat", "text"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				t, c := strings.TrimSpace(argStr(a, "text")), strings.TrimSpace(argStr(a, "chat"))
				if t == "" || c == "" || len([]rune(t)) > 1000 {
					return "", fmt.Errorf("нужны chat и text (до 1000 символов)")
				}
				if err := m.SendText(ctx, c, t); err != nil {
					return "", err
				}
				return "отправила", nil
			}},
		Tool{Name: "tg_react", Desc: "Поставить реакцию-эмодзи на сообщение собеседника (по умолчанию на последнее)", Params: obj(map[string]any{"emoji": str("одно эмодзи, например 👍 ❤️ 😂"), "message_id": intp}, "emoji"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				c, ok := currentChat(ctx)
				if !ok {
					return "", fmt.Errorf("сейчас нет чата Telegram")
				}
				id := int(argInt(a, "message_id"))
				if id == 0 {
					id = c.msgID
				}
				e := strings.TrimSpace(argStr(a, "emoji"))
				if e == "" || len([]rune(e)) > 8 || id == 0 {
					return "", fmt.Errorf("нужно эмодзи и сообщение")
				}
				return "поставила " + e, m.React(ctx, c.chat, id, e)
			}},
		Tool{Name: "tg_sticker", Desc: "Отправить стикер в текущий чат по эмодзи (из установленных на аккаунте наборов). Список эмодзи: tg_sticker_list", Params: obj(map[string]any{"emoji": str("эмодзи стикера, например 😏")}, "emoji"),
			Run: func(ctx context.Context, a map[string]any) (string, error) {
				c, ok := currentChat(ctx)
				if !ok {
					return "", fmt.Errorf("сейчас нет чата Telegram")
				}
				e := strings.TrimSpace(argStr(a, "emoji"))
				if e == "" || len([]rune(e)) > 8 {
					return "", fmt.Errorf("нужно одно эмодзи")
				}
				if err := m.SendSticker(ctx, c.chat, e); err != nil {
					return "", err
				}
				return "стикер отправлен", nil
			}},
		Tool{Name: "tg_sticker_list", Desc: "Какие эмодзи есть среди стикеров аккаунта", Params: obj(map[string]any{}),
			Run: func(ctx context.Context, a map[string]any) (string, error) { return m.StickerEmojis(ctx) }},
	)
}
