// Package voice: голосовые через ElevenLabs. Распознавание (Scribe) и озвучка (TTS) на одном ключе.
package voice

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

type Config struct {
	APIKey     string
	VoiceID    string
	TTSModel   string // по умолчанию eleven_turbo_v2_5 (быстрая, понимает русский)
	STTModel   string // по умолчанию scribe_v1
	DailyChars int    // потолок озвучки в сутки, символов (по умолчанию 20000)
}

type Client struct {
	cfg     Config
	BaseURL string
	HTTP    *http.Client
	Now     func() time.Time

	mu    sync.Mutex
	day   string
	spent int
}

func New(c Config) *Client {
	if c.TTSModel == "" {
		c.TTSModel = "eleven_turbo_v2_5"
	}
	if c.STTModel == "" {
		c.STTModel = "scribe_v1"
	}
	if c.DailyChars <= 0 {
		c.DailyChars = 20000
	}
	return &Client{cfg: c, BaseURL: "https://api.elevenlabs.io", HTTP: &http.Client{Timeout: 60 * time.Second}, Now: time.Now}
}

func (c *Client) ready() error {
	if c.cfg.APIKey == "" || c.cfg.VoiceID == "" {
		return errors.New("голос не настроен: ./reina voice <api_key> <voice_id>")
	}
	return nil
}

func apiErr(resp *http.Response) error {
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 400))
	return fmt.Errorf("ElevenLabs: HTTP %d %s", resp.StatusCode, strings.TrimSpace(string(b)))
}

// Transcribe: голосовое сообщение в текст.
func (c *Client) Transcribe(ctx context.Context, audio []byte, mime string) (string, error) {
	if err := c.ready(); err != nil {
		return "", err
	}
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	w.WriteField("model_id", c.cfg.STTModel)
	ext := "ogg"
	if strings.Contains(mime, "mpeg") {
		ext = "mp3"
	}
	fw, _ := w.CreateFormFile("file", "voice."+ext)
	fw.Write(audio)
	w.Close()
	req, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/v1/speech-to-text", &body)
	req.Header.Set("xi-api-key", c.cfg.APIKey)
	req.Header.Set("Content-Type", w.FormDataContentType())
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", apiErr(resp)
	}
	var out struct {
		Text string `json:"text"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&out); err != nil {
		return "", err
	}
	return strings.TrimSpace(out.Text), nil
}

func (c *Client) spend(n int) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	d := c.Now().Format("2006-01-02")
	if d != c.day {
		c.day, c.spent = d, 0
	}
	if c.spent+n > c.cfg.DailyChars {
		return false
	}
	c.spent += n
	return true
}

// Speak: текст в голос. Возвращает аудио и MIME: audio/ogg (настоящее голосовое) или audio/mpeg (запасной вариант).
func (c *Client) Speak(ctx context.Context, text string) ([]byte, string, error) {
	if err := c.ready(); err != nil {
		return nil, "", err
	}
	text = strings.TrimSpace(text)
	if text == "" {
		return nil, "", errors.New("пустой текст")
	}
	if !c.spend(len([]rune(text))) {
		return nil, "", errors.New("суточный потолок озвучки исчерпан (voice.daily_chars)")
	}
	payload, _ := json.Marshal(map[string]any{
		"text": text, "model_id": c.cfg.TTSModel,
		"voice_settings": map[string]any{"stability": 0.45, "similarity_boost": 0.8, "style": 0.3, "use_speaker_boost": true},
	})
	var lastErr error
	for _, f := range []struct{ format, mime string }{{"opus_48000_64", "audio/ogg"}, {"mp3_44100_64", "audio/mpeg"}} {
		u := fmt.Sprintf("%s/v1/text-to-speech/%s?output_format=%s", c.BaseURL, url.PathEscape(c.cfg.VoiceID), f.format)
		req, _ := http.NewRequestWithContext(ctx, "POST", u, bytes.NewReader(payload))
		req.Header.Set("xi-api-key", c.cfg.APIKey)
		req.Header.Set("Content-Type", "application/json")
		resp, err := c.HTTP.Do(req)
		if err != nil {
			return nil, "", err
		}
		if resp.StatusCode == 200 {
			b, _ := io.ReadAll(io.LimitReader(resp.Body, 20<<20))
			resp.Body.Close()
			return b, f.mime, nil
		}
		lastErr = apiErr(resp)
		resp.Body.Close()
		if resp.StatusCode != 400 && resp.StatusCode != 422 { // формат не принят: пробуем следующий; остальные ошибки (ключ, лимит) сразу наружу
			break
		}
	}
	return nil, "", lastErr
}

// OggSeconds: длительность ogg/opus по последней странице (granule position при 48 кГц), округление вверх; 0, если не разобрать.
func OggSeconds(b []byte) int {
	i := bytes.LastIndex(b, []byte("OggS"))
	if i < 0 || len(b) < i+14 {
		return 0
	}
	g := binary.LittleEndian.Uint64(b[i+6 : i+14])
	if g == 0 || g > 48000*3600 {
		return 0
	}
	return int((g + 47999) / 48000)
}

// ForSpeech чистит текст перед озвучкой: без разметки и эмодзи, которые голос читает странно.
func ForSpeech(s string) string {
	var sb strings.Builder
	for _, r := range s {
		switch {
		case r >= 0x2190: // эмодзи и значки
		case r == '*' || r == '_' || r == '`' || r == '#':
		default:
			sb.WriteRune(r)
		}
	}
	return strings.Join(strings.Fields(sb.String()), " ")
}
