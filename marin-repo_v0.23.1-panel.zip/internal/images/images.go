// Package images: картинки и селфи через OpenRouter (POST /images, ответ base64).
package images

import (
	"bytes"
	"context"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

//go:embed ref.jpg
var embeddedRef []byte

type Config struct {
	Ref      string // путь к референсу внешности; пусто: встроенный, "none": без референса
	BaseURL  string // https://openrouter.ai/api/v1
	APIKey   string
	Model    string // google/gemini-2.5-flash-image
	Look     string // как она выглядит
	MaxDaily int
	Dir      string // куда складывать готовые файлы
}

type Client struct {
	cfg  Config
	HTTP *http.Client
	Now  func() time.Time
	mu   sync.Mutex
	day  string
	n    int
}

func New(c Config) *Client {
	if c.Model == "" {
		c.Model = "google/gemini-2.5-flash-image"
	}
	if c.MaxDaily <= 0 {
		c.MaxDaily = 20
	}
	if c.Look == "" {
		c.Look = "a 20-year-old woman, long straight hair split red and white, blue eyes, small fangs, piercings, black choker, neon cyberpunk vibe"
	}
	return &Client{cfg: c, HTTP: &http.Client{Timeout: 120 * time.Second}, Now: time.Now}
}

func (c *Client) take() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	d := c.Now().Format("2006-01-02")
	if d != c.day {
		c.day, c.n = d, 0
	}
	if c.n >= c.cfg.MaxDaily {
		return fmt.Errorf("дневной лимит картинок (%d) исчерпан", c.cfg.MaxDaily)
	}
	c.n++
	return nil
}

func (c *Client) give() { c.mu.Lock(); c.n--; c.mu.Unlock() }

const safe = " Tasteful and non-explicit: everyday outfits, swimwear and beachwear are fine; no nudity, no sexual content, no real people, no minors."

// Make рисует картинку по описанию и возвращает путь к файлу.
func (c *Client) Make(ctx context.Context, prompt string) (string, error) {
	return c.gen(ctx, strings.TrimSpace(prompt)+"."+safe, false)
}

// MakeHer рисует картинку с ней (референс внешности прикладывается).
func (c *Client) MakeHer(ctx context.Context, prompt string) (string, error) {
	return c.gen(ctx, "The character from the reference image: "+strings.TrimSpace(prompt)+". Keep her face, hair and style exactly like the reference."+safe, true)
}

// Selfie: она сама в кадре, внешность из config (images.look).
func (c *Client) Selfie(ctx context.Context, scene string) (string, error) {
	return c.gen(ctx, "A casual smartphone selfie of the character from the reference image (keep her face, red and white hair, eyes and style exactly the same). "+c.cfg.Look+". Scene and outfit: "+strings.TrimSpace(scene)+"."+safe, true)
}

// ref отдаёт картинку-референс как data URL (или пусто).
func (c *Client) ref() string {
	if c.cfg.Ref == "none" {
		return ""
	}
	b := embeddedRef
	if c.cfg.Ref != "" {
		if x, err := os.ReadFile(c.cfg.Ref); err == nil {
			b = x
		}
	}
	if len(b) == 0 {
		return ""
	}
	mt := "image/jpeg"
	if len(b) > 4 && b[1] == 'P' && b[2] == 'N' {
		mt = "image/png"
	}
	return "data:" + mt + ";base64," + base64.StdEncoding.EncodeToString(b)
}

func (c *Client) gen(ctx context.Context, prompt string, her bool) (string, error) {
	if c.cfg.APIKey == "" {
		return "", errors.New("нет ключа для картинок")
	}
	if len([]rune(prompt)) > 1500 {
		return "", errors.New("описание слишком длинное")
	}
	if err := c.take(); err != nil {
		return "", err
	}
	req0 := map[string]any{"model": c.cfg.Model, "prompt": prompt}
	if her {
		if r := c.ref(); r != "" {
			req0["input_references"] = []any{map[string]any{"type": "image_url", "image_url": map[string]any{"url": r}}}
		}
	}
	body, _ := json.Marshal(req0)
	req, _ := http.NewRequestWithContext(ctx, "POST", strings.TrimRight(c.cfg.BaseURL, "/")+"/images", bytes.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+c.cfg.APIKey)
	req.Header.Set("Content-Type", "application/json")
	resp, err := c.HTTP.Do(req)
	if err != nil {
		c.give()
		return "", err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 40<<20))
	if resp.StatusCode != 200 {
		c.give()
		return "", fmt.Errorf("картинки: HTTP %d %s", resp.StatusCode, strings.TrimSpace(string(raw[:min(len(raw), 300)])))
	}
	var out struct {
		Data []struct {
			B64  string `json:"b64_json"`
			Mime string `json:"media_type"`
		} `json:"data"`
	}
	if err := json.Unmarshal(raw, &out); err != nil || len(out.Data) == 0 || out.Data[0].B64 == "" {
		c.give()
		return "", errors.New("картинки: модель не вернула изображение (возможно, отклонила запрос)")
	}
	img, err := base64.StdEncoding.DecodeString(out.Data[0].B64)
	if err != nil || len(img) < 100 {
		c.give()
		return "", errors.New("картинки: битый ответ")
	}
	ext := ".png"
	if strings.Contains(out.Data[0].Mime, "jpeg") || strings.Contains(out.Data[0].Mime, "jpg") {
		ext = ".jpg"
	}
	dir := c.cfg.Dir
	if dir == "" {
		dir = os.TempDir()
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	p := filepath.Join(dir, fmt.Sprintf("img-%d%s", c.Now().UnixNano(), ext))
	return p, os.WriteFile(p, img, 0o600)
}
