// Package tunnel: публичная https-ссылка на панель через Cloudflare Quick Tunnel (cloudflared, без аккаунта и открытых портов).
// Ссылка случайная и меняется при каждом запуске; доступ к панели всё равно защищён паролем.
package tunnel

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sync"
	"time"
)

var urlRe = regexp.MustCompile(`https://[a-z0-9-]+\.trycloudflare\.com`)

// FindURL достаёт адрес туннеля из строки вывода cloudflared.
func FindURL(line string) string { return urlRe.FindString(line) }

type Module struct {
	Home  string       // куда скачать cloudflared (Home/bin)
	Local string       // адрес панели, например 127.0.0.1:8767
	Bin   string       // путь к cloudflared (пусто: искать в PATH и Home/bin, иначе скачать)
	OnURL func(string) // получила новую ссылку

	mu  sync.Mutex
	url string
	err string
}

func (m *Module) Name() string { return "tunnel" }

// URL: текущая публичная ссылка (пусто, пока туннель не поднялся).
func (m *Module) URL() string { m.mu.Lock(); defer m.mu.Unlock(); return m.url }

func (m *Module) Health() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.err != "" {
		return errors.New(m.err)
	}
	return nil
}

func (m *Module) setErr(s string) { m.mu.Lock(); m.err = s; m.mu.Unlock() }

func (m *Module) binary(ctx context.Context) (string, error) {
	if m.Bin != "" {
		return m.Bin, nil
	}
	if p, err := exec.LookPath("cloudflared"); err == nil {
		return p, nil
	}
	local := filepath.Join(m.Home, "bin", "cloudflared")
	if st, err := os.Stat(local); err == nil && st.Size() > 1<<20 {
		return local, nil
	}
	arch := runtime.GOARCH
	if arch != "amd64" && arch != "arm64" && arch != "arm" && arch != "386" {
		return "", fmt.Errorf("для %s нет сборки cloudflared", arch)
	}
	u := "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-" + arch
	log.Printf("туннель: скачиваю cloudflared (%s)", u)
	if err := os.MkdirAll(filepath.Dir(local), 0o700); err != nil {
		return "", err
	}
	cctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
	defer cancel()
	req, _ := http.NewRequestWithContext(cctx, "GET", u, nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("скачивание cloudflared: HTTP %d", resp.StatusCode)
	}
	tmp := local + ".part"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return "", err
	}
	n, err := io.Copy(f, io.LimitReader(resp.Body, 80<<20))
	f.Close()
	if err != nil || n < 1<<20 {
		os.Remove(tmp)
		return "", fmt.Errorf("cloudflared скачан не полностью")
	}
	if err := os.Rename(tmp, local); err != nil {
		return "", err
	}
	return local, nil
}

func (m *Module) Run(ctx context.Context) error {
	wait := 10 * time.Second
	for ctx.Err() == nil {
		bin, err := m.binary(ctx)
		if err != nil {
			m.setErr(err.Error())
			log.Printf("туннель: %v", err)
		} else {
			m.setErr("")
			if m.runOnce(ctx, bin) {
				wait = 10 * time.Second // ссылка была, значит работало: быстро пробуем снова
			}
		}
		select {
		case <-ctx.Done():
			return nil
		case <-time.After(wait):
		}
		if wait < time.Minute {
			wait *= 2
		}
	}
	return nil
}

// runOnce запускает cloudflared до его выхода; true, если ссылка успела появиться.
func (m *Module) runOnce(ctx context.Context, bin string) bool {
	cmd := exec.CommandContext(ctx, bin, "tunnel", "--no-autoupdate", "--url", "http://"+m.Local)
	out, err := cmd.StderrPipe()
	if err != nil {
		return false
	}
	if err := cmd.Start(); err != nil {
		m.setErr(err.Error())
		return false
	}
	got := false
	sc := bufio.NewScanner(out)
	sc.Buffer(make([]byte, 64*1024), 256*1024)
	for sc.Scan() {
		if u := FindURL(sc.Text()); u != "" && !got {
			got = true
			m.mu.Lock()
			m.url = u
			m.mu.Unlock()
			log.Printf("туннель поднят: %s", u)
			if m.OnURL != nil {
				m.OnURL(u)
			}
		}
	}
	_ = cmd.Wait()
	m.mu.Lock()
	m.url = ""
	m.mu.Unlock()
	return got
}
