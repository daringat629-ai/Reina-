// Package initiative: она пишет хозяину первой. Два повода: сработало напоминание, либо долго тихо и ей захотелось написать.
// Работает как модуль под присмотром supervisor.
package initiative

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"strings"
	"time"

	"reina/internal/config"
	"reina/internal/tools"
)

// Speaker: кто умеет писать в чат первым (telegram.Bot).
type Speaker interface {
	Initiate(ctx context.Context, chat int64, prompt string) bool
	LastIncoming(chat int64) time.Time
}

type Module struct {
	Owner int64
	Cfg   config.Initiative
	Rem   *tools.Reminders
	Bot   Speaker
	Now   func() time.Time
	Tick  time.Duration // как часто смотреть на часы (30 с)

	today    string
	sentDay  int
	lastTry  time.Time
	lastSend time.Time
	lastDig  string
}

func (m *Module) Name() string  { return "initiative" }
func (m *Module) Health() error { return nil }

func (m *Module) defaults() {
	if m.Now == nil {
		m.Now = time.Now
	}
	if m.Tick <= 0 {
		m.Tick = 30 * time.Second
	}
	c := &m.Cfg
	if c.IdleMin <= 0 {
		c.IdleMin = 180
	}
	if c.CheckMin <= 0 {
		c.CheckMin = 45
	}
	if c.ToHour <= 0 {
		c.ToHour = 23
	}
	if c.FromHour <= 0 {
		c.FromHour = 10
	}
	if c.MaxPerDay <= 0 {
		c.MaxPerDay = 3
	}
	if c.Pct <= 0 {
		c.Pct = 35
	}
}

func (m *Module) Run(ctx context.Context) error {
	m.defaults()
	t := time.NewTicker(m.Tick)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-t.C:
			m.Step(ctx)
		}
	}
}

// Step: одна проверка (вынесена для тестов).
func (m *Module) Step(ctx context.Context) {
	m.defaults()
	for _, r := range m.Rem.Due() {
		p := fmt.Sprintf("[служебное: тебе пора напомнить хозяину: «%s». Скажи ему это сама, по-своему, коротко, как близкому человеку. Не отвечай SKIP]", r.Text)
		if !m.Bot.Initiate(ctx, m.Owner, p) {
			// чат занят: вернём на минуту позже, чтобы не потерять
			m.Rem.Add(m.Now().Add(time.Minute), r.Text)
		}
	}
	if m.Cfg.Disabled {
		return
	}
	now := m.Now().In(m.Rem.Loc)
	day := now.Format("2006-01-02")
	if day != m.today {
		m.today, m.sentDay = day, 0
	}
	if len(m.Cfg.Channels) > 0 {
		dh := m.Cfg.DigestHour
		if dh <= 0 {
			dh = 12
		}
		if now.Hour() >= dh && now.Hour() < m.Cfg.ToHour && m.lastDig != day {
			m.lastDig = day
			p := fmt.Sprintf("[служебное: загляни в каналы %s (tg_chats, затем tg_history по id) и посмотри свежие посты. Если нашла что-то реально интересное хозяину, перескажи по-своему коротко и скажи, откуда. Если ничего стоящего, ответь одним словом SKIP]", strings.Join(m.Cfg.Channels, ", "))
			if m.Bot.Initiate(ctx, m.Owner, p) {
				log.Printf("пересказала каналы")
			}
		}
	}
	if m.sentDay >= m.Cfg.MaxPerDay || now.Hour() < m.Cfg.FromHour || now.Hour() >= m.Cfg.ToHour {
		return
	}
	if idle := now.Sub(m.Bot.LastIncoming(m.Owner)); idle < time.Duration(m.Cfg.IdleMin)*time.Minute {
		return
	}
	if now.Sub(m.lastTry) < time.Duration(m.Cfg.CheckMin)*time.Minute {
		return
	}
	m.lastTry = now
	if rand.Intn(100) >= m.Cfg.Pct {
		return
	}
	p := fmt.Sprintf("[служебное: сейчас %s, хозяин давно не писал. Если тебе правда есть что сказать ему первой (мысль, шутка, вопрос, соскучилась, что-то из дневника или памяти), напиши как в обычной переписке, коротко. Если нечего или не к месту, ответь одним словом SKIP]", now.Format("15:04, Mon"))
	if m.Bot.Initiate(ctx, m.Owner, p) {
		m.sentDay++
		log.Printf("написала первой (%d за сегодня)", m.sentDay)
	}
}
