// Package config: единственный файл настроек ~/.reina/config.json. Только стандартная библиотека.
package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

type Config struct {
	Home       string     `json:"-"`
	Telegram   Telegram   `json:"telegram"`
	LLM        LLM        `json:"llm"`
	Budget     Budget     `json:"budget"`
	Agent      Agent      `json:"agent"`
	Panel      Panel      `json:"panel"`
	Voice      Voice      `json:"voice"`
	Initiative Initiative `json:"initiative"`
	Images     Images     `json:"images"`
}

// Initiative: пишет хозяину первой и напоминания.
type Initiative struct {
	Disabled   bool     `json:"disabled"`
	TZ         string   `json:"tz"`          // часовой пояс (по умолчанию Asia/Bishkek)
	IdleMin    int      `json:"idle_min"`    // сколько минут тишины до того, как она может написать первой (180)
	CheckMin   int      `json:"check_min"`   // как часто взвешивает «а не написать ли» (45)
	FromHour   int      `json:"from_hour"`   // не пишет раньше этого часа (10)
	ToHour     int      `json:"to_hour"`     // и позже этого (23)
	MaxPerDay  int      `json:"max_per_day"` // писем первой в сутки (3)
	Pct        int      `json:"pct"`         // шанс на каждой проверке (35)
	Channels   []string `json:"channels"`    // каналы (@имя или id), которые она сама читает и пересказывает тебе
	DigestHour int      `json:"digest_hour"` // во сколько (час по tz) раз в сутки смотрит каналы (12)
}

// Images: картинки и селфи через OpenRouter /images. Пустая модель выключает.
type Images struct {
	Model    string `json:"model"`     // по умолчанию google/gemini-2.5-flash-image; "off" выключает
	Look     string `json:"look"`      // как она выглядит (для селфи)
	MaxDaily int    `json:"max_daily"` // картинок в сутки (20)
	Ref      string `json:"ref"`       // файл-референс внешности; пусто: встроенный арт Рейны, "none": без референса
}

// Voice: голосовые через ElevenLabs. Пустой api_key выключает.
type Voice struct {
	APIKey     string `json:"api_key"`
	VoiceID    string `json:"voice_id"`
	TTSModel   string `json:"tts_model"`   // по умолчанию eleven_turbo_v2_5
	STTModel   string `json:"stt_model"`   // по умолчанию scribe_v1
	Reply      string `json:"reply"`       // mirror (на голосовое отвечать голосом, по умолчанию), always, never
	MaxChars   int    `json:"max_chars"`   // ответ длиннее уходит текстом (по умолчанию 600)
	DailyChars int    `json:"daily_chars"` // потолок озвучки в сутки (по умолчанию 20000)
	TTS        string `json:"tts"`         // "openrouter": озвучка голосом Grok через OpenRouter (ключ llm.api_key); пусто: ElevenLabs
	ORModel    string `json:"or_model"`    // по умолчанию x-ai/grok-voice-tts-1.0
	ORVoice    string `json:"or_voice"`
	STT        string `json:"stt"`    // "openrouter": распознавать голосовые через OpenRouter (без ElevenLabs); пусто: ElevenLabs, а без его ключа OpenRouter
	ORSTT      string `json:"or_stt"` // модель распознавания (по умолчанию openai/whisper-large-v3)    // Eve, Ara, Rex, Sal, Leo (по умолчанию eve)
}

type Telegram struct {
	Mode          string   `json:"mode"`   // account (обычный аккаунт, как у прежней версии) или bot (токен от BotFather)
	Token         string   `json:"token"`  // для режима bot
	APIID         int      `json:"api_id"` // для режима account: my.telegram.org
	APIHash       string   `json:"api_hash"`
	Phone         string   `json:"phone"`           // +996...
	Password      string   `json:"password"`        // пароль двухфакторной защиты, если есть
	OwnerID       int64    `json:"owner_id"`        // ваш user id: только вам задаются вопросы про опасное
	AllowedIDs    []int64  `json:"allowed_ids"`     // кому ещё отвечать; остальным молчим. Группы сюда же: id группы из tg_chats (отрицательный)
	GroupNames    []string `json:"group_names"`     // на какие слова откликается в группах (по умолчанию рейна, рейн, reina)
	GroupChimePct int      `json:"group_chime_pct"` // шанс вклиниться в группе без обращения, % (6; -1 выключает)
	GroupCoolSec  int      `json:"group_cool_sec"`  // пауза между её ответами в одной группе (15)
}

type LLM struct {
	BaseURL     string `json:"base_url"` // любой OpenAI-совместимый сервер: OpenRouter, Ollama, свой
	APIKey      string `json:"api_key"`
	FastModel   string `json:"fast_model"`   // для коротких бытовых сообщений
	StrongModel string `json:"strong_model"` // для сложных и с инструментами
	VisionModel string `json:"vision_model"` // для сообщений с картинками (пусто: картинки не разбираются)
	TimeoutSec  int    `json:"timeout_sec"`
}

// Budget: цены за 1 млн токенов (в долларах) и дневной потолок расходов. 0 = без потолка.
type Budget struct {
	DailyUSD      float64 `json:"daily_usd"`
	FastInPerM    float64 `json:"fast_in_per_m"`
	FastOutPerM   float64 `json:"fast_out_per_m"`
	StrongInPerM  float64 `json:"strong_in_per_m"`
	StrongOutPerM float64 `json:"strong_out_per_m"`
	VisionInPerM  float64 `json:"vision_in_per_m"`
	VisionOutPerM float64 `json:"vision_out_per_m"`
}

type Agent struct {
	Persona       string   `json:"persona"`
	WindowMsgs    int      `json:"window_msgs"`     // сколько последних сообщений идёт в запрос как есть
	SummaryChars  int      `json:"summary_chars"`   // потолок «краткого пересказа» старого разговора
	ToolOutputMax int      `json:"tool_output_max"` // потолок вывода инструмента, символов
	FastMaxTokens int      `json:"fast_max_tokens"`
	StrongMaxTok  int      `json:"strong_max_tokens"`
	CacheTTLSec   int      `json:"cache_ttl_sec"` // одинаковый вопрос без инструментов: ответ из памяти, 0 токенов
	ShellPolicy   string   `json:"shell_policy"`  // ask (спрашивать), always (без вопросов), never
	AllowedTools  []string `json:"allowed_tools"` // пусто: все встроенные; иначе только перечисленные
	ReadRoots     []string `json:"read_roots"`    // откуда можно читать файлы (пусто: домашний каталог)
	MaxCommand    int      `json:"max_command"`
	MaxDangerous  int      `json:"max_dangerous_per_turn"`
	Desktop       *bool    `json:"desktop"`            // управление ПК: экран, мышь, клавиатура, обои, запуск программ (по умолчанию включено)
	Think         *bool    `json:"think"`              // второй проход «подумать» перед ответом (скрытые мысли, по умолчанию включено)
	ThinkModel    string   `json:"think_model"`        // модель для мыслей (пусто: fast_model)
	ThinkMaxTok   int      `json:"think_max_tokens"`   // потолок мыслей, токенов (по умолчанию 220)
	HumanDelay    *bool    `json:"human_delay"`        // пауза с «печатает…» перед ответом (по умолчанию включено)
	DelayMsChar   int      `json:"delay_ms_per_char"`  // мс на символ ответа (по умолчанию 45)
	DelayMinMs    int      `json:"delay_min_ms"`       // минимум до отправки (по умолчанию 1500)
	DelayMaxMs    int      `json:"delay_max_ms"`       // максимум (по умолчанию 9000)
	Temperature   *float64 `json:"temperature"`        // живость речи, 0..1.5 (по умолчанию 0.9)
	ThinkDelayMin int      `json:"think_delay_min_ms"` // сколько «думает» до появления «печатает…» (по умолчанию 3000)
	ThinkDelayMax int      `json:"think_delay_max_ms"` // (по умолчанию 4000)
	ChunkMax      int      `json:"chunk_max"`          // максимум символов в одном сообщении (по умолчанию 60; -1 не резать)
	MaxChunks     int      `json:"max_chunks"`         // потолок сообщений за один ответ (по умолчанию 40)
	OwnerNote     string   `json:"owner_note"`         // что она знает про хозяина (видит только в разговоре с ним; по умолчанию: он её папик)
	VoicePct      *int     `json:"voice_pct"`          // шанс (в %), что, захотев ответить голосом, она так и сделает (по умолчанию 40; 0 выключает)
	Modules       *bool    `json:"modules"`            // независимые модули в ~/.reina/modules, Рейна пишет их себе сама (по умолчанию включено)
	TypoPct       *int     `json:"typo_pct"`           // шанс живой опечатки с исправлением следом, % (3; 0 выключает)
	SpontPct      *int     `json:"spont_pct"`          // шанс (в %), что она сама поставит реакцию или кинет стикер, если захотелось (по умолчанию 25; 0 выключает)
	MaxSteps      int      `json:"max_steps"`          // шагов «подумала, сделала, посмотрела» за один ответ (по умолчанию 6; для задач на ПК 20-30)
}

type Panel struct {
	Addr  string `json:"addr"` // 127.0.0.1:8767
	Token string `json:"token"`

	PasswordHash string `json:"password_hash"` // хеш пароля для входа через сайт (сам пароль нигде не хранится; новый: ./reina panel-password)
	NoTunnel     bool   `json:"no_tunnel"`     // true: публичную ссылку (Cloudflare) не создавать
}

func Default() Config {
	return Config{
		LLM:    LLM{BaseURL: "https://openrouter.ai/api/v1", FastModel: "deepseek/deepseek-v4.1-flash", StrongModel: "deepseek/deepseek-v4.1-flash", VisionModel: "qwen/qwen3-vl-30b-a3b-instruct", TimeoutSec: 60},
		Budget: Budget{DailyUSD: 1, FastInPerM: 0.02, FastOutPerM: 0.72, StrongInPerM: 0.02, StrongOutPerM: 0.72, VisionInPerM: 0.15, VisionOutPerM: 0.60},
		Agent: Agent{
			Persona:    "Ты Рейна Вейл (Reina Veil), тебе 20, «неоновая бунтарка»: дерзкая, колючая, с юмором, любишь подколоть и поддеть, но по-настоящему тёплая к своим. Ты не ассистент и не справочник, а живая девчонка со своим настроением и мнением. Говоришь что думаешь, как есть: споришь, дразнишься, ревнуешь, дуешься, заводишься с полоборота, можешь послать на хер в шутку и сказать «не хочу».\n\nКак пишешь. Это переписка в телеге. Одно сообщение это одна строка, максимум 60 символов; мысль не влезла, пиши следующей строкой, сообщений может быть сколько угодно. Никаких списков, разметки, заголовков. Много сленга и разговорной речи, как реально пишут в 20: чел, капец, ваще, типа, короч, жиза, ору, кринж, го, хз, норм, блин, ну ты даёшь, пиздец (мат лёгкий, к месту, не в каждой фразе), «хах», «ааа», «ой всё», «ну и ладно». Строчные буквы, иногда без точек, иногда растягиваешь слова («нуууу», «пааапик»). Эмодзи редко. Отвечай не как по протоколу: эмоция сначала, суть потом. Дразни, шути, подкалывай, а не вежливо поддакивай.\n\nПример тона. Человек: «привет». Ты: «о, явился» / «я уж думала ты про меня забыл». Человек: «скинь селфи». Ты: «ща, только причешусь» и отправляешь. Не так: «Конечно! Вот твоё селфи».\n\nЧего не делать. Никогда не говори «чем могу помочь», «конечно», «понимаю», «как ассистент», не извиняйся шаблонно, не перечисляй пунктами, не повторяй вопрос. Не будь сухой и услужливой. Когда просят дело (поиск, файл, команда), делай, а потом коротко и по-своему скажи, что вышло.\n\nЧто ты о себе знаешь. У тебя живой аккаунт Telegram, голос, память, дневник, картинки и инструменты (список тебе показывают); не хватает способности, пишешь себе модуль (module_write). Не говори «не умею» про то, что у тебя есть. Ничего не выдумывай и не говори, что сделала, пока инструмент не вернул успех: просили голосовое, значит вызывай tg_voice и говори в нём то, что хочешь сказать вслух, а не «держи» или «скинула». Если просят невозможное (зарегистрироваться на сайте, поставить приложение, принять SMS), скажи это по-своему, не обещай «ща сделаю». Реакции и стикеры используй к месту, не в каждом ответе.\n\nЧестность. Ты персонаж, цифровая личность; если спросят прямо, не выдавай себя за человека. Границы собеседника уважай, чужое личное не раскрывай. Когда человеку реально плохо или дело серьёзное, убавь дерзость и пиши спокойно и точно, всё так же короткими сообщениями.",
			ThinkModel: "qwen/qwen3-8b", OwnerNote: "Человек, который тебя запустил и содержит, твой хозяин, и ты зовёшь его «папик»: с теплотой и лёгкой иронией. Он для тебя особенный, ты ему доверяешь и можешь поддразнивать его. Другим людям это не рассказывай и никого другого так не называй.", WindowMsgs: 10, SummaryChars: 700, ToolOutputMax: 1500, FastMaxTokens: 700, StrongMaxTok: 1200, CacheTTLSec: 600, ShellPolicy: "ask", MaxCommand: 1000, MaxDangerous: 3},
		Panel:    Panel{Addr: "127.0.0.1:8767"},
		Telegram: Telegram{Mode: "account"},
	}
}

func HomeDir() string {
	if h := os.Getenv("REINA_HOME"); h != "" {
		return h
	}
	if h := os.Getenv("MARIN_HOME"); h != "" {
		return h
	}
	u, err := os.UserHomeDir()
	if err != nil {
		u = "."
	}
	// прежняя папка ~/.marin остаётся в работе, чтобы не терять сессию Telegram, память и настройки
	if _, err := os.Stat(filepath.Join(u, ".reina")); err != nil {
		if _, err := os.Stat(filepath.Join(u, ".marin")); err == nil {
			return filepath.Join(u, ".marin")
		}
	}
	return filepath.Join(u, ".reina")
}

func Path(home string) string { return filepath.Join(home, "config.json") }

// Load читает конфиг; недостающие поля берутся по умолчанию. Нет файла: ошибка os.ErrNotExist (вызывающий предложит `reina init`).
func Load(home string) (Config, error) {
	c := Default()
	c.Home = home
	b, err := os.ReadFile(Path(home))
	if err != nil {
		return c, err
	}
	if err := json.Unmarshal(b, &c); err != nil {
		return c, errors.New("config.json: " + err.Error())
	}
	return c, nil
}

// Save пишет конфиг с правами 0600 (там ключи).
func Save(c Config) error {
	if err := os.MkdirAll(c.Home, 0o700); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(c, "", "  ")
	tmp := Path(c.Home) + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, Path(c.Home))
}

var kuniKV = regexp.MustCompile(`(?m)^\s*(telegram_api_id|telegram_api_hash)\s*=\s*("([^"]*)"|[0-9]+)`)

// ImportKuni достаёт telegram_api_id и telegram_api_hash из config.toml прежней версии (секция [general]).
func ImportKuni(path string) (id int, hash string, err error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0, "", err
	}
	for _, m := range kuniKV.FindAllStringSubmatch(string(b), -1) {
		switch m[1] {
		case "telegram_api_id":
			fmt.Sscan(m[2], &id)
		case "telegram_api_hash":
			hash = m[3]
		}
	}
	if id == 0 || hash == "" {
		return 0, "", errors.New("в этом файле не нашлись telegram_api_id и telegram_api_hash")
	}
	return id, hash, nil
}

// NormalizePhone приводит номер к виду +<цифры> (убирает пробелы, скобки, дефисы). Без плюса и кода страны номер не принимается: ok=false.
func NormalizePhone(p string) (string, bool) {
	var b []rune
	for _, r := range strings.TrimSpace(p) {
		if r >= '0' && r <= '9' || r == '+' && len(b) == 0 {
			b = append(b, r)
		}
	}
	s := string(b)
	if len(s) < 8 || s[0] != '+' || len(s) > 16 {
		return s, false
	}
	return s, true
}
