//go:build tguser

package telegram

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gotd/td/telegram"
	"github.com/gotd/td/telegram/auth"
	"github.com/gotd/td/telegram/downloader"
	"github.com/gotd/td/telegram/message"
	"github.com/gotd/td/tg"
)

// UserConfig: вход как обычный аккаунт (api_id и api_hash берутся на my.telegram.org).
type UserConfig struct {
	APIID       int
	APIHash     string
	Phone       string
	Password    string // пароль двухфакторной защиты, если включена
	SessionPath string
}

// User: транспорт «аккаунт» на чистом Go (gotd/td, MTProto), без C-библиотек. Сессия хранится в файле, вход по номеру и коду один раз.
type User struct {
	cfg    UserConfig
	mu     sync.Mutex
	peers  map[int64]tg.InputPeerClass
	sender *message.Sender
	api    *tg.Client
	runCtx context.Context
	stk    map[string][]*tg.Document
	stkAt  time.Time
	rows   []chatRow // последний список диалогов (все типы чатов)
	ready  bool
	lastOK time.Time
	self   string // @username аккаунта (без @), для распознавания упоминаний
}

func NewUser(cfg UserConfig) (Transport, error) {
	if cfg.APIID == 0 || cfg.APIHash == "" || cfg.Phone == "" {
		return nil, errors.New("нужны telegram.api_id, telegram.api_hash и telegram.phone в config.json (reina init)")
	}
	return &User{cfg: cfg, peers: map[int64]tg.InputPeerClass{}, lastOK: time.Now()}, nil
}

func (u *User) Health() error {
	u.mu.Lock()
	defer u.mu.Unlock()
	if u.ready && time.Since(u.lastOK) > 10*time.Minute {
		return fmt.Errorf("нет связи с Telegram уже %s", time.Since(u.lastOK).Round(time.Second))
	}
	return nil
}

func (u *User) Send(chat int64, text string) error {
	u.mu.Lock()
	peer, sender, ctx := u.peers[chat], u.sender, u.runCtx
	u.mu.Unlock()
	if peer == nil && sender != nil && ctx != nil { // адрес не пришёл вместе с сообщением: берём из списка диалогов
		u.refresh(ctx)
		u.mu.Lock()
		peer = u.peers[chat]
		u.mu.Unlock()
	}
	if peer == nil || sender == nil {
		return fmt.Errorf("собеседник %d ещё не писал в эту сессию, адрес неизвестен", chat)
	}
	_, err := sender.To(peer).Text(ctx, text)
	return err
}

// refresh загружает список диалогов и запоминает адреса собеседников (access hash). Нужен, когда Telegram прислал сообщение без данных о пользователе.
func (u *User) refresh(ctx context.Context) {
	if _, err := u.dialogUsers(ctx); err != nil {
		log.Printf("telegram: список диалогов не получен: %v", err)
	}
}

func (u *User) Run(ctx context.Context, in func(Incoming)) error {
	disp := tg.NewUpdateDispatcher()
	client := telegram.NewClient(u.cfg.APIID, u.cfg.APIHash, telegram.Options{
		SessionStorage: &telegram.FileSessionStorage{Path: u.cfg.SessionPath},
		UpdateHandler:  disp,
	})
	handleMsg := func(ctx context.Context, e tg.Entities, m *tg.Message) error {
		if m.Out {
			return nil
		}
		var chatID int64
		group, from, title := false, "", ""
		switch pe := m.PeerID.(type) {
		case *tg.PeerUser:
			chatID = pe.UserID
			if usr, ok := e.Users[pe.UserID]; ok {
				u.mu.Lock()
				u.peers[pe.UserID] = usr.AsInputPeer()
				u.mu.Unlock()
			} else {
				u.mu.Lock()
				_, known := u.peers[pe.UserID]
				u.mu.Unlock()
				if !known {
					u.refresh(ctx)
				}
			}
		case *tg.PeerChat:
			chatID, group = -pe.ChatID, true
			if c, ok := e.Chats[pe.ChatID]; ok {
				title = c.Title
			}
			u.mu.Lock()
			u.peers[chatID] = &tg.InputPeerChat{ChatID: pe.ChatID}
			u.mu.Unlock()
		case *tg.PeerChannel:
			chatID, group = -1000000000000-pe.ChannelID, true
			ch, ok := e.Channels[pe.ChannelID]
			if ok {
				if !ch.Megagroup { // каналы (не группы) не читаем
					return nil
				}
				title = ch.Title
				u.mu.Lock()
				u.peers[chatID] = ch.AsInputPeer()
				u.mu.Unlock()
			} else {
				u.mu.Lock()
				_, known := u.peers[chatID]
				u.mu.Unlock()
				if !known { // сущности не пришли и диалог неизвестен: обновляем список и пробуем дальше как группу
					u.refresh(ctx)
				}
			}
		default:
			return nil
		}
		u.mu.Lock()
		u.lastOK = time.Now()
		u.mu.Unlock()
		if group {
			if fp, ok := m.FromID.(*tg.PeerUser); ok {
				if usr, ok := e.Users[fp.UserID]; ok {
					from = strings.TrimSpace(usr.FirstName + " " + usr.LastName)
					if usr.Bot {
						return nil // боты в группах не собеседники
					}
				}
			}
		}
		lm := strings.ToLower(m.Message)
		wantMedia := !group || m.Mentioned || u.mentionsMe(m.Message) || strings.Contains(lm, "рейн") || strings.Contains(lm, "reina")
		inc := Incoming{Chat: chatID, Text: m.Message, MsgID: m.ID, Group: group, From: from, Mentioned: m.Mentioned || u.mentionsMe(m.Message), Title: title}
		if md, ok := m.Media.(*tg.MessageMediaDocument); ok && wantMedia { // стикер: модель видит эмодзи стикера
			if d, ok := md.Document.(*tg.Document); ok {
				for _, at := range d.Attributes {
					if fn, ok := at.(*tg.DocumentAttributeFilename); ok && strings.HasPrefix(strings.TrimSpace(m.Message), "/update") && strings.HasSuffix(strings.ToLower(fn.FileName), ".zip") && d.Size <= 80<<20 {
						var buf bytes.Buffer // обновление: хозяин прислал zip со сборкой
						loc := &tg.InputDocumentFileLocation{ID: d.ID, AccessHash: d.AccessHash, FileReference: d.FileReference}
						if _, err := downloader.NewDownloader().Download(u.api, loc).Stream(ctx, &buf); err != nil {
							log.Printf("telegram: архив обновления не скачался: %v", err)
							return nil
						}
						inc.File, inc.FileName = buf.Bytes(), fn.FileName
					}
					if st, ok := at.(*tg.DocumentAttributeSticker); ok {
						inc.Text = strings.TrimSpace(m.Message + " [стикер " + st.Alt + "]")
					}
					if au, ok := at.(*tg.DocumentAttributeAudio); ok && au.Voice && d.Size <= 10<<20 && au.Duration <= 180 { // голосовое: скачиваем для распознавания
						var buf bytes.Buffer
						loc := &tg.InputDocumentFileLocation{ID: d.ID, AccessHash: d.AccessHash, FileReference: d.FileReference}
						if _, err := downloader.NewDownloader().Download(u.api, loc).Stream(ctx, &buf); err != nil {
							log.Printf("telegram: голосовое не скачалось: %v", err)
							return nil
						}
						inc.Voice, inc.VoiceMime = buf.Bytes(), d.MimeType
					}
				}
			}
		}
		if mp, ok := m.Media.(*tg.MessageMediaPhoto); ok && wantMedia { // фото: берём самый большой размер
			if ph, ok := mp.Photo.AsNotEmpty(); ok {
				var best *tg.PhotoSize
				for _, sz := range ph.Sizes {
					if ps, ok := sz.(*tg.PhotoSize); ok && (best == nil || ps.Size > best.Size) {
						best = ps
					}
				}
				if best != nil {
					var buf bytes.Buffer
					loc := &tg.InputPhotoFileLocation{ID: ph.ID, AccessHash: ph.AccessHash, FileReference: ph.FileReference, ThumbSize: best.Type}
					if _, err := downloader.NewDownloader().Download(u.api, loc).Stream(ctx, &buf); err != nil {
						log.Printf("telegram: фото не скачалось: %v", err)
						return nil
					}
					inc.Image, inc.Mime = buf.Bytes(), "image/jpeg"
				}
			}
		}
		if inc.Text == "" && len(inc.Image) == 0 && len(inc.Voice) == 0 && len(inc.File) == 0 {
			return nil
		}
		in(inc)
		return nil
	}
	disp.OnNewMessage(func(ctx context.Context, e tg.Entities, upd *tg.UpdateNewMessage) error {
		m, ok := upd.Message.(*tg.Message)
		if !ok {
			return nil
		}
		return handleMsg(ctx, e, m)
	})
	disp.OnNewChannelMessage(func(ctx context.Context, e tg.Entities, upd *tg.UpdateNewChannelMessage) error {
		m, ok := upd.Message.(*tg.Message)
		if !ok {
			return nil
		}
		return handleMsg(ctx, e, m)
	})
	return client.Run(ctx, func(ctx context.Context) error {
		flow := auth.NewFlow(auth.Constant(u.cfg.Phone, u.cfg.Password, auth.CodeAuthenticatorFunc(
			func(ctx context.Context, _ *tg.AuthSentCode) (string, error) {
				fmt.Print("Код из Telegram (придёт в приложение или SMS): ")
				s, err := bufio.NewReader(os.Stdin).ReadString('\n')
				return strings.TrimSpace(s), err
			})), auth.SendCodeOptions{})
		if err := client.Auth().IfNecessary(ctx, flow); err != nil {
			return fmt.Errorf("вход не удался: %w", err)
		}
		u.mu.Lock()
		u.api = client.API()
		u.sender, u.runCtx, u.ready, u.lastOK = message.NewSender(u.api), ctx, true, time.Now()
		u.mu.Unlock()
		if me, err := client.Self(ctx); err == nil {
			u.mu.Lock()
			u.self = strings.ToLower(me.Username)
			u.mu.Unlock()
		}
		log.Printf("Telegram: аккаунт %s вошёл", u.cfg.Phone)
		u.refresh(ctx)
		<-ctx.Done()
		return nil
	})
}

// mentionsMe: в тексте есть @username этого аккаунта.
func (u *User) mentionsMe(text string) bool {
	u.mu.Lock()
	self := u.self
	u.mu.Unlock()
	return self != "" && strings.Contains(strings.ToLower(text), "@"+self)
}
